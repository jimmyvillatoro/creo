<?php
session_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   

<?php 
include 'dat/cdb/db.php';

date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 

if(!$_SESSION['EmployeeID'])
{
 echo '<a href="index.php" title="" class="round">Inicie sesion</a>';
  exit;
}
$resultado=mysqli_query($db_connection, "SELECT EmployeeName FROM employees WHERE EmployeeID='".$_SESSION['EmployeeID']."'  ");

$cuenta=0;
while ($row =mysqli_fetch_array($resultado)) {
$EmployeeName=$row['EmployeeName'];
   }

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "client/clientser2.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index2.php">Admin</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Last access : <?php echo $dt; ?> &nbsp; <a href="index.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
            <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
        <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
          </li>
        
          
                    <li>
                        <a  href="index2.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
<?php
if($_SESSION['ManagerID']==0)
{
?>
                     <li  >
                        <a  href="tableco.php"><i class="fa fa-table fa-3x"></i>Company</a>
                    </li>                <li  >
                        <a  href="table.php"><i class="fa fa-table fa-3x"></i>Employees</a>
                    </li>
                     <li>
                        <a class="active-menu" href="tablec.php"><i class="fa fa-table fa-3x"></i>Client</a>
                    </li>
                      <li>
                        <a  href="tablep.php"><i class="fa fa-table fa-3x"></i>Project</a>
                    </li>
<?php
}
?>      
                      <li>
                        <a  href="tablet.php"><i class="fa fa-table fa-3x"></i>Task</a>
                    </li>
                      <li>
                        <a  href="tables.php"><i class="fa fa-table fa-3x"></i>SubTask</a>
                    </li>
    
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Client</h2>   
                        <h5>Welcome <?php echo $EmployeeName ?>, Love to see you back. </h5>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">


<h1>Search for <strong class="cur">ClientName</strong></h1>
<form action="tablec.php" method="POST">
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>              
  
 <h1>Add</h1>

<form action="client/clientadd.php" method="POST">
 
 
 <p>ClientName</p>
<div><input type='text' name='ClientName'   placeholder='ClientName'  required> </div>  
 
 
  <p>Address</p>
<div><input type='text' name='Address'   placeholder='Address'  required> </div>  
 
 
 <p>CompanyName</p>
<div class="Reg">
<div class="Regbox">
<SELECT NAME="CompanyID" SIZE=1> 
<OPTION SELECTED ="selected" VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$resulta=mysqli_query($db_connection, "SELECT CompanyID, CompanyName FROM  company ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$CompanyID =$row['CompanyID'];
$CompanyName =$row['CompanyName'];
?>
<OPTION VALUE="<?php echo $CompanyID; ?>"> <?php echo $CompanyName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}

mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>
 
  <p>Email</p>
<div><input type='text' name='Email'  placeholder='Email'  required> </div>  
 
 
 <p>Contact</p> 
<div><input type='text' name='Contact'   placeholder='Contact'  required> </div>  
 
 
<div>
<button type='submit' class='btn btn-success'>Add</button>
             </div>
             </form>  
  
  
<h1>Edit</h1>

<table class="table">
<thead>
<tr>
<th>Edit</th>
<th>ClientName</th> 
<th>Address</th> 
<th>CompanyName</th> 
<th>Email</th> 
<th>Contact</th> 
</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT * FROM client " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$ClientID=$row['ClientID'];
$ClientName=$row['ClientName'];
$Address=$row['Address'];
$CompanyID=$row['CompanyID'];
$Email=$row['Email'];
$Contact=$row['Contact'];
 ?>
<tbody>
<tr class="odd gradeX">
<form action="client/clientupd3.php" method="POST"> 
<input type='hidden' name='ClientID' value='<?php echo $ClientID; ?>'> 

 
<td><button type='submit' class='btn btn-success'>Edit</button> </td> 
 
<td><input type='text' name='ClientName'  class='form-control' placeholder='ClientName' value='<?php echo $ClientName; ?>' class='form-input' required> </td>  
 
<td><input type='text' name='Address'  class='form-control' placeholder='Address' value='<?php echo $Address; ?>' class='form-input' required> </td>  
 
<td>
<SELECT NAME="CompanyID" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo1=  $CompanyID;
$resulta=mysqli_query($db_connection, "SELECT CompanyID, CompanyName FROM  company ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$CompanyID =$row['CompanyID'];
$CompanyName =$row['CompanyName'];
?>
<OPTION VALUE="<?php echo $CompanyID; ?>"> <?php echo $CompanyName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo1) > 0){
$resulta=mysqli_query($db_connection, "SELECT CompanyID, CompanyName  FROM  company  WHERE CompanyID = '".$selCombo1."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$CompanyID =$row['CompanyID'];
$CompanyName =$row['CompanyName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $CompanyID; ?>"> <?php  echo $CompanyName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  

</td>  
 
<td><input type='text' name='Email'  class='form-control' placeholder='Email' value='<?php echo $Email; ?>' class='form-input' required> </td>  
 
<td><input type='text' name='Contact'  class='form-control' placeholder='Contact' value='<?php echo $Contact; ?>' class='form-input' required></td>  
 
</form> 
<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
                        </tbody>
                              </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

 <h3>Delete</h3>
<form action="client/clientdel.php" method="POST"> 
<input type='hidden' name='ClientID' value='<?php echo utf8_decode($_GET['ClientID']); ?>'> 
<input type='hidden' name='ClientID' value='<?php echo utf8_decode($_GET['ClientID']); ?>'> 
 
<div><input type='text' name='Idx'  placeholder='ClientID'   required></div>  
<div> <button type='submit' class='btn btn-success'>Delete</button> </div> 
</form>   
  
              

            </div>
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
