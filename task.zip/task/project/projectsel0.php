<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>project</title> 
  

<?php
include 'db.php'; 
$ClientID= utf8_decode($_GET['ClientID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM project WHERE ClientID LIKE '".$ClientID."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$ProjectID=$row['ProjectID'];
$ClientID=$row['ClientID'];
$EmployeeID=$row['EmployeeID'];
$ProjectName=$row['ProjectName'];
$ProjectDescription=$row['ProjectDescription'];
$ProjectStartDate=$row['ProjectStartDate'];
$ProjectEndDate=$row['ProjectEndDate'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.project.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=7 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>ProjectID</th> 
<th>ClientID</th> 
<th>EmployeeID</th> 
<th>ProjectName</th> 
<th>ProjectDescription</th> 
<th>ProjectStartDate</th> 
<th>ProjectEndDate</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $ProjectID; ?></th> 
<th><?php echo $ClientID; ?></th> 
<th><?php echo $EmployeeID; ?></th> 
<th><?php echo $ProjectName; ?></th> 
<th><?php echo $ProjectDescription; ?></th> 
<th><?php echo $ProjectStartDate; ?></th> 
<th><?php echo $ProjectEndDate; ?></th> 
</tr></table></br></br> 
 
<a href="../usuarios.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
</body> </html>