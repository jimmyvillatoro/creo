<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="dat/css/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript" src="dat/js/tablecloth.js"></script>
        <title>project</title> 
<style>
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style> 
  
 
<?php
include '../dat/cdb/db.php'; 
$ProjectID= utf8_decode($_GET['ProjectID']); 
$ProjectID = utf8_decode($_GET['ProjectID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM project WHERE ProjectID = '".$ProjectID."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$ProjectID=$row['ProjectID'];
$ClientID=$row['ClientID'];
$EmployeeID=$row['EmployeeID'];
$ProjectName=$row['ProjectName'];
$ProjectDescription=$row['ProjectDescription'];
$ProjectStartDate=$row['ProjectStartDate'];
$ProjectEndDate=$row['ProjectEndDate'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

        <div> <h2>project</h2> </div> 
 
<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr><th>ProjectID</th> 
<th>ClientID</th> 
<th>EmployeeID</th> 
<th>ProjectName</th> 
<th>ProjectDescription</th> 
<th>ProjectStartDate</th> 
<th>ProjectEndDate</th> 

<?php
include '../dat/cdb/db.php'; 
$ClientID= utf8_decode($_GET['ClientID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM project " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$ProjectID=$row['ProjectID'];
$ClientID=$row['ClientID'];
$EmployeeID=$row['EmployeeID'];
$ProjectName=$row['ProjectName'];
$ProjectDescription=$row['ProjectDescription'];
$ProjectStartDate=$row['ProjectStartDate'];
$ProjectEndDate=$row['ProjectEndDate'];
 ?>
</tr><tr><td><?php echo $ProjectID; ?></td> 
<td><?php echo $ClientID; ?></td> 
<td><?php echo $EmployeeID; ?></td> 
<td><?php echo $ProjectName; ?></td> 
<td><?php echo $ProjectDescription; ?></td> 
<td><?php echo $ProjectStartDate; ?></td> 
<td><?php echo $ProjectEndDate; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th><th>ProjectID</th> 
<th>ClientID</th> 
<th>EmployeeID</th> 
<th>ProjectName</th> 
<th>ProjectDescription</th> 
<th>ProjectStartDate</th> 
<th>ProjectEndDate</th> 

<?php
include '../dat/cdb/db.php'; 
$ClientID= utf8_decode($_GET['ClientID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM project " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$ProjectID=$row['ProjectID'];
$ClientID=$row['ClientID'];
$EmployeeID=$row['EmployeeID'];
$ProjectName=$row['ProjectName'];
$ProjectDescription=$row['ProjectDescription'];
$ProjectStartDate=$row['ProjectStartDate'];
$ProjectEndDate=$row['ProjectEndDate'];
 ?>
</tr><tr><tr><form action="projectupd3.php" method="POST"> 
<input type='hidden' name='ProjectID' value='<?php echo utf8_decode($_GET['ProjectID']); ?>'> 
<input type='hidden' name='ProjectID' value='<?php echo utf8_decode($_GET['ProjectID']); ?>'> 
 
<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td> 
<td><div><input type='number' name='ProjectID'  class='form-control' placeholder='ProjectID' value='<?php echo $ProjectID; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='ClientID'  class='form-control' placeholder='ClientID' value='<?php echo $ClientID; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='EmployeeID'  class='form-control' placeholder='EmployeeID' value='<?php echo $EmployeeID; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='ProjectName'  class='form-control' placeholder='ProjectName' value='<?php echo $ProjectName; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='ProjectDescription'  class='form-control' placeholder='ProjectDescription' value='<?php echo $ProjectDescription; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='ProjectStartDate'  class='form-control' placeholder='ProjectStartDate' value='<?php echo $ProjectStartDate; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='ProjectEndDate'  class='form-control' placeholder='ProjectEndDate' value='<?php echo $ProjectEndDate; ?>' class='form-input' required> </div></td>  
 
</form> 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th><th>ProjectID</th> 
<th>ClientID</th> 
<th>EmployeeID</th> 
<th>ProjectName</th> 
<th>ProjectDescription</th> 
<th>ProjectStartDate</th> 
<th>ProjectEndDate</th> 

<?php
include '../dat/cdb/db.php'; 
$ClientID= utf8_decode($_GET['ClientID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM project " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$ProjectID=$row['ProjectID'];
$ClientID=$row['ClientID'];
$EmployeeID=$row['EmployeeID'];
$ProjectName=$row['ProjectName'];
$ProjectDescription=$row['ProjectDescription'];
$ProjectStartDate=$row['ProjectStartDate'];
$ProjectEndDate=$row['ProjectEndDate'];
 ?>
</tr><tr><td><a href=projectupd2.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>><?php echo $ProjectID; ?> actualizar</a></td><td><?php echo $ProjectID; ?></td> 
<td><?php echo $ClientID; ?></td> 
<td><?php echo $EmployeeID; ?></td> 
<td><?php echo $ProjectName; ?></td> 
<td><?php echo $ProjectDescription; ?></td> 
<td><?php echo $ProjectStartDate; ?></td> 
<td><?php echo $ProjectEndDate; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br> 
 
<a href="../usuarios.php?ProjectID='".$ProjectID."'&ProjectID='".$ProjectID."'">Regresar</a>
"<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th><th>ProjectID</th> 
<th>ClientID</th> 
<th>EmployeeID</th> 
<th>ProjectName</th> 
<th>ProjectDescription</th> 
<th>ProjectStartDate</th> 
<th>ProjectEndDate</th> 

<?php
include '../dat/cdb/db.php'; 
$ClientID= utf8_decode($_GET['ClientID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM project " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$ProjectID=$row['ProjectID'];
$ClientID=$row['ClientID'];
$EmployeeID=$row['EmployeeID'];
$ProjectName=$row['ProjectName'];
$ProjectDescription=$row['ProjectDescription'];
$ProjectStartDate=$row['ProjectStartDate'];
$ProjectEndDate=$row['ProjectEndDate'];
 ?>
</tr><tr><td><a href=projectdel2.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>><?php echo $ProjectID; ?> borrar</a></td><td><?php echo $ProjectID; ?></td> 
<td><?php echo $ClientID; ?></td> 
<td><?php echo $EmployeeID; ?></td> 
<td><?php echo $ProjectName; ?></td> 
<td><?php echo $ProjectDescription; ?></td> 
<td><?php echo $ProjectStartDate; ?></td> 
<td><?php echo $ProjectEndDate; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?ProjectID=<?php echo $ProjectID; ?>&ProjectID=<?php echo $ProjectID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
