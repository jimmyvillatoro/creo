<?php 
include '../dat/cdb/db.php'; 
$ClientID= $_REQUEST['ClientID'];
$EmployeeID= $_REQUEST['EmployeeID'];
$ProjectName= $_REQUEST['ProjectName'];
$ProjectDescription= $_REQUEST['ProjectDescription'];
$ProjectStartDate= $_REQUEST['ProjectStartDate'];
$ProjectEndDate= $_REQUEST['ProjectEndDate'];
$resultado=mysqli_query($db_connection, "SELECT ProjectID FROM project WHERE ProjectName LIKE '".$ProjectName."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: ../tablep.php"); 
} else {  
$insert_value ="INSERT INTO project(ClientID, EmployeeID, ProjectName, ProjectDescription, ProjectStartDate, ProjectEndDate) VALUES ( '".$ClientID."',  '".$EmployeeID."',  '".$ProjectName."',  '".$ProjectDescription."',  '".$ProjectStartDate."',  '".$ProjectEndDate."')";
$retry_value = mysqli_query($db_connection,$insert_value);
}
header("Location: ../tablep.php"); 
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>