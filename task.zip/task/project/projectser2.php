<?php 
include '../dat/cdb/db.php'; 


 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM project WHERE ProjectName LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$ProjectID=$row['ProjectID'];
$html.= '<p><a href=tablep.php?ProjectID='.$ProjectID.'>'.$ProjectID.'</a></p></b>';
$ProjectName=$row['ProjectName'];
$html.= '<p>'.$ProjectName.'</p></b>'; 
$ProjectDescription=$row['ProjectDescription'];
$html.= '<p>'.$ProjectDescription.'</p></b>'; 
$ProjectStartDate=$row['ProjectStartDate'];
$html.= '<p>'.$ProjectStartDate.'</p></b>'; 
$ProjectEndDate=$row['ProjectEndDate'];
$html.= '<p>'.$ProjectEndDate.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>