<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$ProjectID = $_REQUEST['ProjectID'];
$ProjectID = $_REQUEST['ProjectID']; 
$ProjectID = $_REQUEST['ProjectID'];
 
$ProjectID= $_REQUEST['ProjectID'];
$ClientID= $_REQUEST['ClientID'];
$EmployeeID= $_REQUEST['EmployeeID'];
$ProjectName= $_REQUEST['ProjectName'];
$ProjectDescription= $_REQUEST['ProjectDescription'];
$ProjectStartDate= $_REQUEST['ProjectStartDate'];
$ProjectEndDate= $_REQUEST['ProjectEndDate'];
$Idx= $_REQUEST['Idx'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM project WHERE ProjectID LIKE '".$Idx."'" );  
if (mysqli_num_rows($resultado)>0) {
$delete_value ="DELETE FROM project WHERE ProjectID LIKE '".$Idx."'";  
$retry_value = mysqli_query($db_connection,$delete_value);
 header("Location: ../tablep.php?idusu=$idusu&idses=$idses&ProjectID=$ProjectID&ProjectID=$ProjectID"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../tablep.php?idusu=$idusu&idses=$idses&ProjectID=$ProjectID&ProjectID=$ProjectID"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>