<?php 
include '../dat/cdb/db.php'; 

$ClientID= $_REQUEST['ClientID'];
$ClientName= $_REQUEST['ClientName'];
$Address= $_REQUEST['Address'];
$CompanyID= $_REQUEST['CompanyID'];
$Email= $_REQUEST['Email'];
$Contact= $_REQUEST['Contact'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM client WHERE ClientName LIKE '".$ClientName."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: ../tablec.php"); 
} else {  
$insert_value ="INSERT INTO client(ClientName, Address, CompanyID, Email, Contact) VALUES ( '".$ClientName."',  '".$Address."',  '".$CompanyID."',  '".$Email."',  '".$Contact."')";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT ClientID  FROM  client  WHERE ClientName = '".$ClientName."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $ClientID =$row['ClientID']; 
 header("Location: ../tablec.php"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>