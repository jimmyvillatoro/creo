<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$ClientID = $_REQUEST['ClientID'];
$ClientID = $_REQUEST['ClientID']; 
$ClientID = $_REQUEST['ClientID'];
 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM client WHERE ClientName LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$ClientID=$row['ClientID'];
$html.= '<p><a href=clientupd2.php?ClientID='.$ClientID.'>'.$ClientID.'</a></p></b>';$html.= '<p>'.$ClientID.'</p></b>'; 
$ClientName=$row['ClientName'];
$html.= '<p>'.$ClientName.'</p></b>'; 
$Address=$row['Address'];
$html.= '<p>'.$Address.'</p></b>'; 
$CompanyName=$row['CompanyName'];
$html.= '<p>'.$CompanyName.'</p></b>'; 
$Email=$row['Email'];
$html.= '<p>'.$Email.'</p></b>'; 
$Contact=$row['Contact'];
$html.= '<p>'.$Contact.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>