<?php 
include '../dat/cdb/db.php'; 

 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM client WHERE ClientName LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$ClientID=$row['ClientID'];
$html.= '<p><a href=tablec.php?ClientID='.$ClientID.'>'.$ClientID.'</a></p></b>';
$ClientName=$row['ClientName'];
$html.= '<p>'.$ClientName.'</p></b>'; 
$Address=$row['Address'];
$html.= '<p>'.$Address.'</p></b>'; 
$CompanyID=$row['CompanyID'];
$html.= '<p>'.$CompanyID.'</p></b>'; 
$Email=$row['Email'];
$html.= '<p>'.$Email.'</p></b>'; 
$Contact=$row['Contact'];
$html.= '<p>'.$Contact.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>