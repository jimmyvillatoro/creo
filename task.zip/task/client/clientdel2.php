<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finitos" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>client</title> 
  
 
<?php
include '../dat/cdb/db.php'; 
$ClientID= utf8_decode($_GET['ClientID']); 
$ClientID = utf8_decode($_GET['ClientID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM client WHERE ClientID = '".$ClientID."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$ClientID=$row['ClientID'];
$ClientName=$row['ClientName'];
$Address=$row['Address'];
$CompanyName=$row['CompanyName'];
$Email=$row['Email'];
$Contact=$row['Contact'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

        <div> <h2>client</h2> </div> 
 
<h3>Borrar</h3>
<form action="clientdel.php" method="POST"> 
<input type='hidden' name='ClientID' value='<?php echo utf8_decode($_GET['ClientID']); ?>'> 
<input type='hidden' name='ClientID' value='<?php echo utf8_decode($_GET['ClientID']); ?>'> 
 
<div><input type='text' name='Idx' class='form-control' placeholder='Id a Borrar' class='form-input' value='<?php echo  $ClientID; ?>' required></div>  
<div> <button type='submit' class='btn btn-success'>Borrar</button> </div> 
</form> 
<a href="../usuarios.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
