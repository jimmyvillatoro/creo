<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$ClientID = $_REQUEST['ClientID'];
$ClientID = $_REQUEST['ClientID']; 
$ClientID = $_REQUEST['ClientID'];
 
$ClientID= $_REQUEST['ClientID'];
$ClientName= $_REQUEST['ClientName'];
$Address= $_REQUEST['Address'];
$CompanyName= $_REQUEST['CompanyName'];
$Email= $_REQUEST['Email'];
$Contact= $_REQUEST['Contact'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM client WHERE ClientID = '".$ClientID."'" ); 
if (mysqli_num_rows($resultado)>0) {
$update_value = "UPDATE client SET ClientName= '".$ClientName."', Address= '".$Address."', CompanyName= '".$CompanyName."', Email= '".$Email."', Contact= '".$Contact."'   WHERE   ClientID = '".$ClientID."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&ClientID=$ClientID&ClientID=$ClientID"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&ClientID=$ClientID&ClientID=$ClientID"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>