<?php 
include '../dat/cdb/db.php'; 


$ClientID= $_REQUEST['ClientID'];
$ClientName= $_REQUEST['ClientName'];
$Address= $_REQUEST['Address'];
$CompanyID= $_REQUEST['CompanyID'];
$Email= $_REQUEST['Email'];
$Contact= $_REQUEST['Contact'];
 
$resultado=mysqli_query($db_connection, "SELECT * FROM client WHERE ClientID = '".$ClientID."'" ); 
if (mysqli_num_rows($resultado)>0) {
$update_value = "UPDATE client SET ClientName= '".$ClientName."', Address= '".$Address."', CompanyID= '".$CompanyID."', Email= '".$Email."', Contact= '".$Contact."'   WHERE   ClientID = '".$ClientID."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: ../tablec.php"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../tablec.php"); 
}
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>