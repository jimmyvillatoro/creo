<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>client</title> 
  

<?php
include 'db.php'; 
$ClientName= utf8_decode($_GET['ClientName']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM client WHERE ClientName LIKE '".$ClientName."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$ClientID=$row['ClientID'];
$ClientName=$row['ClientName'];
$Address=$row['Address'];
$CompanyName=$row['CompanyName'];
$Email=$row['Email'];
$Contact=$row['Contact'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.client.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=6 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>ClientID</th> 
<th>ClientName</th> 
<th>Address</th> 
<th>CompanyName</th> 
<th>Email</th> 
<th>Contact</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $ClientID; ?></th> 
<th><?php echo $ClientName; ?></th> 
<th><?php echo $Address; ?></th> 
<th><?php echo $CompanyName; ?></th> 
<th><?php echo $Email; ?></th> 
<th><?php echo $Contact; ?></th> 
</tr></table></br></br> 
 
<a href="../usuarios.php?ClientID=<?php echo $ClientID; ?>&ClientID=<?php echo $ClientID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
</body> </html>