-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 31-07-2021 a las 19:46:05
-- Versión del servidor: 10.4.6-MariaDB
-- Versión de PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `taskdb`
--
CREATE DATABASE IF NOT EXISTS `taskdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci;
USE `taskdb`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `ClientID` int(11) NOT NULL AUTO_INCREMENT,
  `ClientName` varchar(100) DEFAULT NULL,
  `Address` varchar(250) DEFAULT NULL,
  `CompanyID` int(11) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Contact` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ClientID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `client`
--

INSERT INTO `client` (`ClientID`, `ClientName`, `Address`, `CompanyID`, `Email`, `Contact`) VALUES
(1, 'Danara Zenith', 'Portugal', 1, 'dan@hotmail.com', '123456789');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `CompanyID` int(11) NOT NULL AUTO_INCREMENT,
  `CompanyName` varchar(100) DEFAULT NULL,
  `CompanyAddress` varchar(250) DEFAULT NULL,
  `Contact` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CompanyID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `company`
--

INSERT INTO `company` (`CompanyID`, `CompanyName`, `CompanyAddress`, `Contact`, `Email`) VALUES
(1, 'Aranath Zenitram', 'Portugal', '09214657125', 'info@aranathzenitram.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `EmployeeID` int(11) NOT NULL AUTO_INCREMENT,
  `ManagerID` int(11) DEFAULT NULL,
  `CompanyID` int(11) DEFAULT NULL,
  `EmployeeName` varchar(100) DEFAULT NULL,
  `Designation` varchar(100) DEFAULT NULL,
  `Address` varchar(250) DEFAULT NULL,
  `Contact` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Pass` varchar(20) NOT NULL,
  PRIMARY KEY (`EmployeeID`),
  KEY `CompanyID` (`CompanyID`),
  KEY `ManagerID` (`ManagerID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `employees`
--

INSERT INTO `employees` (`EmployeeID`, `ManagerID`, `CompanyID`, `EmployeeName`, `Designation`, `Address`, `Contact`, `Email`, `Pass`) VALUES
(1, 0, 1, 'Jimmy Villatoro ', 'Developer ', 'Chiapas Mexico ', '+52 1 9611772089', 'jimmyvillatoro77@gmail.com', 'é›Û9ørx'),
(2, 1, 1, 'Azka', 'Front End', 'Pakistan', '+52 1 9611772089', 'azka@gmail.com', 'é›Û9ørx');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `project`
--

DROP TABLE IF EXISTS `project`;
CREATE TABLE IF NOT EXISTS `project` (
  `ProjectID` int(11) NOT NULL AUTO_INCREMENT,
  `ClientID` int(11) DEFAULT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectName` varchar(100) DEFAULT NULL,
  `ProjectDescription` text DEFAULT NULL,
  `ProjectStartDate` date DEFAULT NULL,
  `ProjectEndDate` date DEFAULT NULL,
  PRIMARY KEY (`ProjectID`),
  KEY `ClientID` (`ClientID`),
  KEY `EmployeeID` (`EmployeeID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `project`
--

INSERT INTO `project` (`ProjectID`, `ClientID`, `EmployeeID`, `ProjectName`, `ProjectDescription`, `ProjectStartDate`, `ProjectEndDate`) VALUES
(1, 1, 1, 'Developer', 'Developer', '2021-07-08', '2021-08-31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subtask`
--

DROP TABLE IF EXISTS `subtask`;
CREATE TABLE IF NOT EXISTS `subtask` (
  `SubTaskNumber` int(11) NOT NULL AUTO_INCREMENT,
  `TaskNumber` int(11) DEFAULT NULL,
  `SuperVisorEmployeeID` int(11) DEFAULT NULL,
  `SubTaskName` varchar(100) DEFAULT NULL,
  `SubTaskType` varchar(100) DEFAULT NULL,
  `task_status` varchar(20) DEFAULT NULL,
  `IntroductionDate` date DEFAULT NULL,
  `startingDate` date DEFAULT NULL,
  `retouchDate` date DEFAULT NULL,
  `quantityOfRetouch` float DEFAULT NULL,
  `internalDeathLineDate` date DEFAULT NULL,
  `ExternalDeathLineDate` date DEFAULT NULL,
  `DateWaiting` date DEFAULT NULL,
  `DateFinishWork` date DEFAULT NULL,
  `Comments` text DEFAULT NULL,
  `Link` varchar(250) DEFAULT NULL,
  `For1` int(11) NOT NULL,
  `For2` int(11) NOT NULL,
  `SubResponsableExternal` int(11) NOT NULL,
  PRIMARY KEY (`SubTaskNumber`),
  KEY `TaskNumber` (`TaskNumber`),
  KEY `SuperVisorEmployeeID` (`SuperVisorEmployeeID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `subtask`
--

INSERT INTO `subtask` (`SubTaskNumber`, `TaskNumber`, `SuperVisorEmployeeID`, `SubTaskName`, `SubTaskType`, `task_status`, `IntroductionDate`, `startingDate`, `retouchDate`, `quantityOfRetouch`, `internalDeathLineDate`, `ExternalDeathLineDate`, `DateWaiting`, `DateFinishWork`, `Comments`, `Link`, `For1`, `For2`, `SubResponsableExternal`) VALUES
(1, 1, 1, 'back end', 'dev', 'Started', '2021-07-31', '2021-07-31', '2021-08-02', 5, '2021-08-03', '2021-08-03', '2021-08-03', '2021-08-04', 'desarrollo HOY', 'www.yaprendo.com', 2, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `task`
--

DROP TABLE IF EXISTS `task`;
CREATE TABLE IF NOT EXISTS `task` (
  `TaskNumber` int(11) NOT NULL AUTO_INCREMENT,
  `ProjectID` int(11) DEFAULT NULL,
  `SuperVisorEmployeeID` int(11) DEFAULT NULL,
  `TaskName` varchar(100) DEFAULT NULL,
  `TaskType` varchar(100) DEFAULT NULL,
  `task_status` varchar(20) DEFAULT NULL,
  `IntroductionDate` date DEFAULT NULL,
  `startingDate` date DEFAULT NULL,
  `retouchDate` date DEFAULT NULL,
  `quantityOfRetouch` float DEFAULT NULL,
  `internalDeathLineDate` date DEFAULT NULL,
  `ExternalDeathLineDate` date DEFAULT NULL,
  `DateWaiting` date DEFAULT NULL,
  `DateFinishWork` date DEFAULT NULL,
  `For1` int(11) DEFAULT NULL,
  `SubResponsableExternal` int(11) DEFAULT NULL,
  `For2` int(11) DEFAULT NULL,
  `Comments` text DEFAULT NULL,
  `Link` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`TaskNumber`),
  KEY `PojectID` (`ProjectID`),
  KEY `SuperVisorEmployeeID` (`SuperVisorEmployeeID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `task`
--

INSERT INTO `task` (`TaskNumber`, `ProjectID`, `SuperVisorEmployeeID`, `TaskName`, `TaskType`, `task_status`, `IntroductionDate`, `startingDate`, `retouchDate`, `quantityOfRetouch`, `internalDeathLineDate`, `ExternalDeathLineDate`, `DateWaiting`, `DateFinishWork`, `For1`, `SubResponsableExternal`, `For2`, `Comments`, `Link`) VALUES
(1, 1, 1, 'CRM dev', 'dev', 'Started', '2021-07-31', '2021-07-31', '2021-08-02', 1, '2021-08-03', '2021-08-03', '2021-08-03', '2021-08-04', 2, 1, 1, 'desarrollo antes de una semana', 'www.yaprendo.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
