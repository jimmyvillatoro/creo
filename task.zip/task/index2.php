<?php
session_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   

<?php 
include 'dat/cdb/db.php';

date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 

if(!$_SESSION['EmployeeID'])
{
 echo '<a href="index.php" title="" class="round">Inicie sesion</a>';
  exit;
}
$resultado=mysqli_query($db_connection, "SELECT EmployeeName FROM employees WHERE EmployeeID='".$_SESSION['EmployeeID']."'  ");

$cuenta=0;
while ($row =mysqli_fetch_array($resultado)) {
$EmployeeName=$row['EmployeeName'];
   }

$c=mysqli_query($db_connection, "SELECT COUNT(t.Comments) C FROM task t, project p WHERE p.ProjectID=t.ProjectID && LENGTH(t.Comments)>0 && p.EmployeeID='".$_SESSION['EmployeeID']."'");
$row =mysqli_fetch_array($c);
$C=$row['C'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Nte FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && t.DateFinishWork  >= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Nte=$row['Nte'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Nti FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && internalDeathLineDate  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Nti=$row['Nti'];


$numproj=mysqli_query($db_connection, "SELECT COUNT(*) Nump FROM project   ");
//WHERE EmployeeID='".$_SESSION['EmployeeID']."'
$row =mysqli_fetch_array($numproj);
$Nump=$row['Nump'];
   

$numtask=mysqli_query($db_connection, "SELECT COUNT(*) Numt FROM task ");
$row =mysqli_fetch_array($numtask);
$Numt=$row['Numt'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) NtIn FROM task WHERE  IntroductionDate <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$NtIn=$row['NtIn'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Nt FROM task WHERE  startingDate <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Nt=$row['Nt'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Nte FROM task WHERE  DateFinishWork  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Nte=$row['Nte'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Ntr FROM task WHERE  retouchDate  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Ntr=$row['Ntr'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Nti FROM task WHERE  internalDeathLineDate  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Nti=$row['Nti'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) NtE FROM task WHERE  ExternalDeathLineDate  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$NtE=$row['NtE'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) NtD FROM task WHERE  DateWaiting  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$NtD=$row['NtD'];

$numstask=mysqli_query($db_connection, "SELECT COUNT(*) Numst FROM subtask ");
$row =mysqli_fetch_array($numstask);
$Numst=$row['Numst'];

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index2.php">Admin</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Last access : <?php echo $dt; ?> &nbsp; <a href="index.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
            <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                
                    
                    <li>
                        <a class="active-menu" href="index2.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
<?php
if($_SESSION['ManagerID']==0)
{
?>
                       <li  >
                        <a  href="tableco.php"><i class="fa fa-table fa-3x"></i>Company</a>
                    </li>            <li  >
                        <a  href="table.php"><i class="fa fa-table fa-3x"></i>Employees</a>
                    </li>
                     <li>
                        <a  href="tablec.php"><i class="fa fa-table fa-3x"></i>Client</a>
                    </li>
                      <li>
                        <a  href="tablep.php"><i class="fa fa-table fa-3x"></i>Project</a>
                    </li>
<?php
}
?>                  
                    
                      <li>
                        <a  href="tablet.php"><i class="fa fa-table fa-3x"></i>Task</a>
                    </li>
                      <li>
                        <a  href="tables.php"><i class="fa fa-table fa-3x"></i>SubTask</a>
                    </li>
    
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Admin Task Dashboard</h2>   
                        <h5>Welcome <?php echo $EmployeeName ?>, Love to see you back. </h5>
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-red set-icon">
                    <i class="fa fa-envelope-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Nump; ?> Project</p>
                    <p class="text-muted">Today</p>
                </div>
             </div>
		     </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-green set-icon">
                    <i class="fa fa-bars"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Numt; ?> Tasks</p>
                    <p class="text-muted">Remaining</p>
                </div>
             </div>
		     </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Numst; ?> SubTask</p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-brown set-icon">
                    <i class="fa fa-rocket"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Nt; ?> Orders</p>
                    <p class="text-muted">startingDate Pending</p>
                </div>
             </div>
		     </div>
			</div>
                 <!-- /. ROW  -->
                <hr />                
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-xs-12">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue">
                    <i class="fa fa-warning"></i>
                </span>
                <div class="text-box" >
                     <p class="main-text"><?php echo $NtIn; ?> Important to Fix the introduction date has passed</p>
                    <p class="main-text"><?php echo $Nte; ?> Important to Fix the end date has passed</p>
                    <p class="main-text"><?php echo $Ntr; ?> Important to Fix the retouching date has passed</p>
                        <p class="main-text"><?php echo $Nti; ?> Important to Fix the internal death line date has passed </p>
                        
                         <p class="main-text"><?php echo $NtE; ?> Important to Fix the external death line date has passed </p>              <p class="main-text"><?php echo $NtD; ?> Important to Fix the standby date has passed</p> 
                    <p class="text-muted">Please fix these issues to work smooth</p>
                    <p class="text-muted">Time Left: 30 mins</p>
                    <hr />
                
                </div>
             </div>
		     </div>
                    
                    
                    
                    
                 <!-- /. ROW  -->
                <div class="row"> 
                    
                      
                              
                    <div class="col-md-3 col-sm-12 col-xs-12">                       
                    <div class="panel panel-primary text-center no-boder bg-color-green">
                        <div class="panel-body">
                            <i class="fa fa-bar-chart-o fa-5x"></i>
                            <h3><?php echo $Nti ?></h3>
                        </div>
                        <div class="panel-footer back-footer-green">
                           internal Death Line
                        </div>
                    </div>
                    <div class="panel panel-primary text-center no-boder bg-color-red">
                        <div class="panel-body">
                            <i class="fa fa-edit fa-5x"></i>
                            <h3><?php echo $Nte ?> </h3>
                        </div>
                        <div class="panel-footer back-footer-red">
                            Articles Pending
                            
                        </div>
                    </div>                         
                        </div>
                
           </div>
                 <!-- /. ROW  -->
                <div class="row" >
                    <div class="col-md-3 col-sm-12 col-xs-12">
  <div class="panel panel-primary text-center no-boder bg-color-green">
                        <div class="panel-body">
                            <i class="fa fa-comments-o fa-5x"></i>
                            <h4><?php echo $C ?> New Comments </h4>
                             <h4>See All Comments  </h4>
                        </div>
                        <div class="panel-footer back-footer-green">
                             <i class="fa fa-rocket fa-5x"></i>
                             These are the comments that exist within each task
                            
                        </div>
                    </div>
                    </div>
                  
                </div>
                 <!-- /. ROW  -->
                <div class="row">
                  
                    <div class="col-md-6 col-sm-12 col-xs-12">
                         <div class="panel panel-default">
                        <div class="panel-heading">
                           Label Option  </div>
                        <div class="panel-body">
                            <span class="label label-default">Default</span>
<span class="label label-primary">Primary</span>
<span class="label label-success">Success</span>
<span class="label label-info">Info</span>
<span class="label label-warning">Warning</span>
<span class="label label-danger">Danger</span>
                        </div>
                    </div>
                         
             
                      
                    </div>
                </div>     
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
