<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>employees</title> 
  

<?php
include 'db.php'; 
$ManagerID= utf8_decode($_GET['ManagerID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees WHERE ManagerID LIKE '".$ManagerID."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$EmployeeID=$row['EmployeeID'];
$ManagerID=$row['ManagerID'];
$CompanyID=$row['CompanyID'];
$EmployeeName=$row['EmployeeName'];
$Designation=$row['Designation'];
$Address=$row['Address'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.employees.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=8 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>EmployeeID</th> 
<th>ManagerID</th> 
<th>CompanyID</th> 
<th>EmployeeName</th> 
<th>Designation</th> 
<th>Address</th> 
<th>Contact</th> 
<th>Email</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $EmployeeID; ?></th> 
<th><?php echo $ManagerID; ?></th> 
<th><?php echo $CompanyID; ?></th> 
<th><?php echo $EmployeeName; ?></th> 
<th><?php echo $Designation; ?></th> 
<th><?php echo $Address; ?></th> 
<th><?php echo $Contact; ?></th> 
<th><?php echo $Email; ?></th> 
</tr></table></br></br> 
 
<a href="../usuarios.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
</body> </html>