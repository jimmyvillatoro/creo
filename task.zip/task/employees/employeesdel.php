<?php 
include '../dat/cdb/db.php'; 

$EmployeeID = $_REQUEST['EmployeeID'];
$EmployeeID = $_REQUEST['EmployeeID']; 
$EmployeeID = $_REQUEST['EmployeeID'];
 
$EmployeeID= $_REQUEST['EmployeeID'];
$ManagerID= $_REQUEST['ManagerID'];
$CompanyID= $_REQUEST['CompanyID'];
$EmployeeName= $_REQUEST['EmployeeName'];
$Designation= $_REQUEST['Designation'];
$Address= $_REQUEST['Address'];
$Contact= $_REQUEST['Contact'];
$Email= $_REQUEST['Email'];
$Idx= $_REQUEST['Idx'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM employees WHERE EmployeeID LIKE '".$Idx."'" );  
if (mysqli_num_rows($resultado)>0) {
$delete_value ="DELETE FROM employees WHERE EmployeeID LIKE '".$Idx."'";  
$retry_value = mysqli_query($db_connection,$delete_value);
 header("Location: ../table.php?idusu=$idusu&idses=$idses&EmployeeID=$EmployeeID&EmployeeID=$EmployeeID"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../table.php?idusu=$idusu&idses=$idses&EmployeeID=$EmployeeID&EmployeeID=$EmployeeID"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>