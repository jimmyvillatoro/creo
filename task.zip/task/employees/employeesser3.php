<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$EmployeeID = $_REQUEST['EmployeeID'];
$EmployeeID = $_REQUEST['EmployeeID']; 
$EmployeeID = $_REQUEST['EmployeeID'];
 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees WHERE ManagerID LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$EmployeeID=$row['EmployeeID'];
$html.= '<p><a href=employeesupd2.php?EmployeeID='.$EmployeeID.'>'.$EmployeeID.'</a></p></b>';$html.= '<p>'.$EmployeeID.'</p></b>'; 
$ManagerID=$row['ManagerID'];
$html.= '<p>'.$ManagerID.'</p></b>'; 
$CompanyID=$row['CompanyID'];
$html.= '<p>'.$CompanyID.'</p></b>'; 
$EmployeeName=$row['EmployeeName'];
$html.= '<p>'.$EmployeeName.'</p></b>'; 
$Designation=$row['Designation'];
$html.= '<p>'.$Designation.'</p></b>'; 
$Address=$row['Address'];
$html.= '<p>'.$Address.'</p></b>'; 
$Contact=$row['Contact'];
$html.= '<p>'.$Contact.'</p></b>'; 
$Email=$row['Email'];
$html.= '<p>'.$Email.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>