<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finitos" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>employees</title> 
  

<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "employeesser2.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>
 
 
<?php
include '../dat/cdb/db.php'; 
$EmployeeID= utf8_decode($_GET['EmployeeID']); 
$EmployeeID = utf8_decode($_GET['EmployeeID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees WHERE EmployeeID = '".$EmployeeID."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$EmployeeID=$row['EmployeeID'];
$ManagerID=$row['ManagerID'];
$CompanyID=$row['CompanyID'];
$EmployeeName=$row['EmployeeName'];
$Designation=$row['Designation'];
$Address=$row['Address'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
 
 <?php  
$ManagerID = utf8_decode($_GET['ManagerID']); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  
 
<div> <h2>employees</h2> </div> 
 

<h2>busca por <strong class="cur">ManagerID</strong></h2>
<form action="employeesser.php" method="POST">
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $ManagerID; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>  
 
<a href="../usuarios.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
