<?php 
include '../dat/cdb/db.php'; 


$ManagerID= $_REQUEST['ManagerID'];
$CompanyID= $_REQUEST['CompanyID'];
$EmployeeName= $_REQUEST['EmployeeName'];
$Designation= $_REQUEST['Designation'];
$Address= $_REQUEST['Address'];
$Contact= $_REQUEST['Contact'];
$Email= $_REQUEST['Email'];
$Pass= $_REQUEST['Pass'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees WHERE Email LIKE '".$Email."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: ../table.php?idusu=$idusu&idses=$idses&EmployeeID=$EmployeeID&EmployeeID=$EmployeeID"); 
} else {  
$insert_value ="INSERT INTO employees(ManagerID, CompanyID, EmployeeName, Designation, Address, Contact, Email, Pass) VALUES ( '".$ManagerID."',  '".$CompanyID."',  '".$EmployeeName."',  '".$Designation."',  '".$Address."',  '".$Contact."',  '".$Email."',  encode('".$Pass."','us1317mx@'))";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT EmployeeID  FROM  employees  WHERE Email = '".$Email."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $EmployeeID =$row['EmployeeID']; 
 header("Location: ../table.php?idusu=$idusu&idses=$idses&EmployeeID=$EmployeeID&EmployeeID=$EmployeeID"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>