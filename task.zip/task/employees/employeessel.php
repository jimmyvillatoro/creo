<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="dat/css/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript" src="dat/js/tablecloth.js"></script>
        <title>employees</title> 
<style>
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style> 
  
 
<?php
include '../dat/cdb/db.php'; 
$EmployeeID= utf8_decode($_GET['EmployeeID']); 
$EmployeeID = utf8_decode($_GET['EmployeeID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees WHERE EmployeeID = '".$EmployeeID."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$EmployeeID=$row['EmployeeID'];
$ManagerID=$row['ManagerID'];
$CompanyID=$row['CompanyID'];
$EmployeeName=$row['EmployeeName'];
$Designation=$row['Designation'];
$Address=$row['Address'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

        <div> <h2>employees</h2> </div> 
 
<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr><th>EmployeeID</th> 
<th>ManagerID</th> 
<th>CompanyID</th> 
<th>EmployeeName</th> 
<th>Designation</th> 
<th>Address</th> 
<th>Contact</th> 
<th>Email</th> 

<?php
include '../dat/cdb/db.php'; 
$ManagerID= utf8_decode($_GET['ManagerID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$EmployeeID=$row['EmployeeID'];
$ManagerID=$row['ManagerID'];
$CompanyID=$row['CompanyID'];
$EmployeeName=$row['EmployeeName'];
$Designation=$row['Designation'];
$Address=$row['Address'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 ?>
</tr><tr><td><?php echo $EmployeeID; ?></td> 
<td><?php echo $ManagerID; ?></td> 
<td><?php echo $CompanyID; ?></td> 
<td><?php echo $EmployeeName; ?></td> 
<td><?php echo $Designation; ?></td> 
<td><?php echo $Address; ?></td> 
<td><?php echo $Contact; ?></td> 
<td><?php echo $Email; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th><th>EmployeeID</th> 
<th>ManagerID</th> 
<th>CompanyID</th> 
<th>EmployeeName</th> 
<th>Designation</th> 
<th>Address</th> 
<th>Contact</th> 
<th>Email</th> 

<?php
include '../dat/cdb/db.php'; 
$ManagerID= utf8_decode($_GET['ManagerID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$EmployeeID=$row['EmployeeID'];
$ManagerID=$row['ManagerID'];
$CompanyID=$row['CompanyID'];
$EmployeeName=$row['EmployeeName'];
$Designation=$row['Designation'];
$Address=$row['Address'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 ?>
</tr><tr><tr><form action="employeesupd3.php" method="POST"> 
<input type='hidden' name='EmployeeID' value='<?php echo utf8_decode($_GET['EmployeeID']); ?>'> 
<input type='hidden' name='EmployeeID' value='<?php echo utf8_decode($_GET['EmployeeID']); ?>'> 
 
<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td> 
<td><div><input type='number' name='EmployeeID'  class='form-control' placeholder='EmployeeID' value='<?php echo $EmployeeID; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='ManagerID'  class='form-control' placeholder='ManagerID' value='<?php echo $ManagerID; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='CompanyID'  class='form-control' placeholder='CompanyID' value='<?php echo $CompanyID; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='EmployeeName'  class='form-control' placeholder='EmployeeName' value='<?php echo $EmployeeName; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Designation'  class='form-control' placeholder='Designation' value='<?php echo $Designation; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Address'  class='form-control' placeholder='Address' value='<?php echo $Address; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Contact'  class='form-control' placeholder='Contact' value='<?php echo $Contact; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Email'  class='form-control' placeholder='Email' value='<?php echo $Email; ?>' class='form-input' required> </div></td>  
 
</form> 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th><th>EmployeeID</th> 
<th>ManagerID</th> 
<th>CompanyID</th> 
<th>EmployeeName</th> 
<th>Designation</th> 
<th>Address</th> 
<th>Contact</th> 
<th>Email</th> 

<?php
include '../dat/cdb/db.php'; 
$ManagerID= utf8_decode($_GET['ManagerID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$EmployeeID=$row['EmployeeID'];
$ManagerID=$row['ManagerID'];
$CompanyID=$row['CompanyID'];
$EmployeeName=$row['EmployeeName'];
$Designation=$row['Designation'];
$Address=$row['Address'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 ?>
</tr><tr><td><a href=employeesupd2.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>><?php echo $EmployeeID; ?> actualizar</a></td><td><?php echo $EmployeeID; ?></td> 
<td><?php echo $ManagerID; ?></td> 
<td><?php echo $CompanyID; ?></td> 
<td><?php echo $EmployeeName; ?></td> 
<td><?php echo $Designation; ?></td> 
<td><?php echo $Address; ?></td> 
<td><?php echo $Contact; ?></td> 
<td><?php echo $Email; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br> 
 
<a href="../usuarios.php?EmployeeID='".$EmployeeID."'&EmployeeID='".$EmployeeID."'">Regresar</a>
"<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th><th>EmployeeID</th> 
<th>ManagerID</th> 
<th>CompanyID</th> 
<th>EmployeeName</th> 
<th>Designation</th> 
<th>Address</th> 
<th>Contact</th> 
<th>Email</th> 

<?php
include '../dat/cdb/db.php'; 
$ManagerID= utf8_decode($_GET['ManagerID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM employees " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$EmployeeID=$row['EmployeeID'];
$ManagerID=$row['ManagerID'];
$CompanyID=$row['CompanyID'];
$EmployeeName=$row['EmployeeName'];
$Designation=$row['Designation'];
$Address=$row['Address'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 ?>
</tr><tr><td><a href=employeesdel2.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>><?php echo $EmployeeID; ?> borrar</a></td><td><?php echo $EmployeeID; ?></td> 
<td><?php echo $ManagerID; ?></td> 
<td><?php echo $CompanyID; ?></td> 
<td><?php echo $EmployeeName; ?></td> 
<td><?php echo $Designation; ?></td> 
<td><?php echo $Address; ?></td> 
<td><?php echo $Contact; ?></td> 
<td><?php echo $Email; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?EmployeeID=<?php echo $EmployeeID; ?>&EmployeeID=<?php echo $EmployeeID; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
