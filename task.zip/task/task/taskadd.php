<?php 
include '../dat/cdb/db.php'; 

$TaskNumber= $_REQUEST['TaskNumber'];
$ProjectID= $_REQUEST['ProjectID'];
$SuperVisorEmployeeID= $_REQUEST['SuperVisorEmployeeID'];
$TaskName= $_REQUEST['TaskName'];
$TaskType= $_REQUEST['TaskType'];
$task_status= $_REQUEST['task_status'];
$IntroductionDate= $_REQUEST['IntroductionDate'];
$startingDate= $_REQUEST['startingDate'];
$retouchDate= $_REQUEST['retouchDate'];
$quantityOfRetouch= $_REQUEST['quantityOfRetouch'];
$internalDeathLineDate= $_REQUEST['internalDeathLineDate'];
$ExternalDeathLineDate= $_REQUEST['ExternalDeathLineDate'];
$DateWaiting= $_REQUEST['DateWaiting'];
$DateFinishWork= $_REQUEST['DateFinishWork'];
$For1= $_REQUEST['For1'];
$SubResponsableExternal= $_REQUEST['SubResponsableExternal'];
$For2= $_REQUEST['For2'];
$Comments= $_REQUEST['Comments'];
$Link= $_REQUEST['Link'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM task WHERE TaskName LIKE '".$TaskName."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: ../tablet.php"); 
} else {  
$insert_value ="INSERT INTO task(ProjectID, SuperVisorEmployeeID, TaskName, TaskType, task_status, IntroductionDate, startingDate, retouchDate, quantityOfRetouch, internalDeathLineDate, ExternalDeathLineDate, DateWaiting, DateFinishWork, For1, SubResponsableExternal, For2, Comments, Link) VALUES ( '".$ProjectID."',  '".$SuperVisorEmployeeID."',  '".$TaskName."',  '".$TaskType."',  '".$task_status."',  '".$IntroductionDate."',  '".$startingDate."',  '".$retouchDate."',  '".$quantityOfRetouch."',  '".$internalDeathLineDate."',  '".$ExternalDeathLineDate."',  '".$DateWaiting."',  '".$DateFinishWork."',  '".$For1."',  '".$SubResponsableExternal."',  '".$For2."',  '".$Comments."',  '".$Link."')";

$retry_value = mysqli_query($db_connection,$insert_value);

  
$resultado=mysqli_query($db_connection, "SELECT Email, EmployeeName  FROM  employees  WHERE EmployeeID = '".$For1."'" ); 
 while ($row =mysqli_fetch_array($resultado))
 {
 $Email =$row['Email']; 
 $EmployeeName1 =$row['EmployeeName']; 
 }
  
  
$resultado=mysqli_query($db_connection, "SELECT Email, EmployeeName  FROM  employees  WHERE EmployeeID = '".$For2."'" ); 
 while ($row =mysqli_fetch_array($resultado))
 {
 $Email2 =$row['Email']; 
 $EmployeeName2 =$row['EmployeeName']; 
 }
 
 $resultado=mysqli_query($db_connection, "SELECT Email, EmployeeName  FROM  employees  WHERE EmployeeID = '".$SubResponsableExternal."'" ); 
 while ($row =mysqli_fetch_array($resultado))
 {
 $Email3 =$row['Email']; 
 $EmployeeName3 =$row['EmployeeName']; 
 }
 
 $cuerpo='Hello '.$EmployeeName1.', you have been assigned the task: "'.$TaskName.'" along with  '.$EmployeeName2.' which starts '.$startingDate.'  and ends '.$DateFinishWork.' with the following status '.$task_status.' as comment says: "'.$Comments.'" the external supervisor is: '.$EmployeeName3.', it is a pleasure to be of service, have a nice day.';
mail($Email1,'New Task ->',$cuerpo,$TaskName);

 $cuerpo='Hello '.$EmployeeName2.', you have been assigned the task: '.$TaskName.' together with '.$EmployeeName1.'  which starts  '.$startingDate.' and ends '.$DateFinishWork.' with the following status '.$task_status.' as comment says: "'.$Comments.'" the external supervisor is: '.$EmployeeName3.', it is a pleasure to be of service, have a nice day.';
mail($Email2,'New Task ->',$cuerpo,$TaskName);

 $cuerpo='Hello '.$EmployeeName3.', You have been assigned as an external supervisor the task: "'.$TaskName.'" which starts  '.$startingDate.' and ends  '.$DateFinishWork.' with the following status '.$task_status.' as comment says: "'.$Comments.'" the team is: '.$EmployeeName1.' and '.$EmployeeName2.', it is a pleasure to be of service, have a nice day.';
mail($Email3,'New Task ->',$cuerpo,$TaskName);

$resultado=mysqli_query($db_connection, "SELECT Email, EmployeeName  FROM  employees  WHERE EmployeeID = '".$SuperVisorEmployeeID."'" ); 
 while ($row =mysqli_fetch_array($resultado))
 {
 $Email =$row['Email']; 
 $EmployeeName =$row['EmployeeName']; 
 }
  
 $cuerpo='Hello '.$EmployeeName.', you have been assigned the task: "'.$TaskName.'" as SuperVisor that starts  '.$startingDate.' and ends '.$DateFinishWork.' with status '.$task_status.' as comment says: "'.$Comments.'" the team is: '.$EmployeeName1.' and '.$EmployeeName2.' the external supervisor is: '.$EmployeeName3.', it is a pleasure to be of service, have a nice day.';
mail($Email,'New Task ->',$cuerpo,$TaskName); 

}
$resultado=mysqli_query($db_connection, "SELECT TaskNumber  FROM  task  WHERE ProjectID = '".$ProjectID."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $TaskNumber =$row['TaskNumber']; 
 header("Location: ../tablet.php"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>