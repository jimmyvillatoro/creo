<?php 
include '../dat/cdb/db.php'; 

 
$TaskNumber= $_REQUEST['TaskNumber'];
$ProjectID= $_REQUEST['ProjectID'];
$SuperVisorEmployeeID= $_REQUEST['SuperVisorEmployeeID'];
$TaskName= $_REQUEST['TaskName'];
$TaskType= $_REQUEST['TaskType'];
$task_status= $_REQUEST['task_status'];
$IntroductionDate= $_REQUEST['IntroductionDate'];
$startingDate= $_REQUEST['startingDate'];
$retouchDate= $_REQUEST['retouchDate'];
$quantityOfRetouch= $_REQUEST['quantityOfRetouch'];
$internalDeathLineDate= $_REQUEST['internalDeathLineDate'];
$ExternalDeathLineDate= $_REQUEST['ExternalDeathLineDate'];
$DateWaiting= $_REQUEST['DateWaiting'];
$DateFinishWork= $_REQUEST['DateFinishWork'];
$For1= $_REQUEST['For1'];
$SubResponsableExternal= $_REQUEST['SubResponsableExternal'];
$For2= $_REQUEST['For2'];
$Comments= $_REQUEST['Comments'];
$Link= $_REQUEST['Link'];
$Idx= $_REQUEST['Idx'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM task WHERE TaskNumber LIKE '".$Idx."'" );  
if (mysqli_num_rows($resultado)>0) {
$delete_value ="DELETE FROM task WHERE TaskNumber LIKE '".$Idx."'";  
$retry_value = mysqli_query($db_connection,$delete_value);
 header("Location: ../tablet.php"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../tablet.php"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>