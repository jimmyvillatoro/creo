<?php 
include '../dat/cdb/db.php'; 

 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM task WHERE TaskName LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$TaskNumber=$row['TaskNumber'];
$html.= '<p><a href=tablet.php?TaskNumber='.$TaskNumber.'>'.$TaskNumber.'</a></p></b>';
$ProjectID=$row['ProjectID'];
$html.= '<p>'.$ProjectID.'</p></b>'; 
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$html.= '<p>'.$SuperVisorEmployeeID.'</p></b>'; 
$TaskName=$row['TaskName'];
$html.= '<p>'.$TaskName.'</p></b>'; 
$TaskType=$row['TaskType'];
$html.= '<p>'.$TaskType.'</p></b>'; 
$task_status=$row['task_status'];
$html.= '<p>'.$task_status.'</p></b>'; 
$IntroductionDate=$row['IntroductionDate'];
$html.= '<p>'.$IntroductionDate.'</p></b>'; 
$startingDate=$row['startingDate'];
$html.= '<p>'.$startingDate.'</p></b>'; 
$retouchDate=$row['retouchDate'];
$html.= '<p>'.$retouchDate.'</p></b>'; 
$quantityOfRetouch=$row['quantityOfRetouch'];
$html.= '<p>'.$quantityOfRetouch.'</p></b>'; 
$internalDeathLineDate=$row['internalDeathLineDate'];
$html.= '<p>'.$internalDeathLineDate.'</p></b>'; 
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$html.= '<p>'.$ExternalDeathLineDate.'</p></b>'; 
$DateWaiting=$row['DateWaiting'];
$html.= '<p>'.$DateWaiting.'</p></b>'; 
$DateFinishWork=$row['DateFinishWork'];
$html.= '<p>'.$DateFinishWork.'</p></b>'; 
$For1=$row['For1'];
$html.= '<p>'.$For1.'</p></b>'; 
$SubResponsableExternal=$row['SubResponsableExternal'];
$html.= '<p>'.$SubResponsableExternal.'</p></b>'; 
$For2=$row['For2'];
$html.= '<p>'.$For2.'</p></b>'; 
$Comments=$row['Comments'];
$html.= '<p>'.$Comments.'</p></b>'; 
$Link=$row['Link'];
$html.= '<p>'.$Link.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>