<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$TaskNumber = $_REQUEST['TaskNumber'];
$TaskNumber = $_REQUEST['TaskNumber']; 
$TaskNumber = $_REQUEST['TaskNumber'];
 
$TaskNumber= $_REQUEST['TaskNumber'];
$ProjectID= $_REQUEST['ProjectID'];
$SuperVisorEmployeeID= $_REQUEST['SuperVisorEmployeeID'];
$TaskName= $_REQUEST['TaskName'];
$TaskType= $_REQUEST['TaskType'];
$task_status= $_REQUEST['task_status'];
$IntroductionDate= $_REQUEST['IntroductionDate'];
$startingDate= $_REQUEST['startingDate'];
$retouchDate= $_REQUEST['retouchDate'];
$quantityOfRetouch= $_REQUEST['quantityOfRetouch'];
$internalDeathLineDate= $_REQUEST['internalDeathLineDate'];
$ExternalDeathLineDate= $_REQUEST['ExternalDeathLineDate'];
$DateWaiting= $_REQUEST['DateWaiting'];
$DateFinishWork= $_REQUEST['DateFinishWork'];
$For1= $_REQUEST['For1'];
$SubResponsableExternal= $_REQUEST['SubResponsableExternal'];
$For2= $_REQUEST['For2'];
$Comments= $_REQUEST['Comments'];
$Link= $_REQUEST['Link'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM task WHERE TaskNumber = '".$TaskNumber."'" ); 
if (mysqli_num_rows($resultado)>0) {
$update_value = "UPDATE task SET ProjectID= '".$ProjectID."', SuperVisorEmployeeID= '".$SuperVisorEmployeeID."', TaskName= '".$TaskName."', TaskType= '".$TaskType."', task_status= '".$task_status."', IntroductionDate= '".$IntroductionDate."', startingDate= '".$startingDate."', retouchDate= '".$retouchDate."', quantityOfRetouch= '".$quantityOfRetouch."', internalDeathLineDate= '".$internalDeathLineDate."', ExternalDeathLineDate= '".$ExternalDeathLineDate."', DateWaiting= '".$DateWaiting."', DateFinishWork= '".$DateFinishWork."', For1= '".$For1."', SubResponsableExternal= '".$SubResponsableExternal."', For2= '".$For2."', Comments= '".$Comments."', Link= '".$Link."'   WHERE   TaskNumber = '".$TaskNumber."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&TaskNumber=$TaskNumber&TaskNumber=$TaskNumber"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&TaskNumber=$TaskNumber&TaskNumber=$TaskNumber"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>