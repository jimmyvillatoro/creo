<?php
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>company</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../css/style.css">
   <link rel="stylesheet" type="text/css" href="../css/registration.css">
     <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
<style>
.ocultar {
    display: none;
}
.mostrar {
    display: block;
}
</style> 
<script>
function verificarPasswords() {
 
    // Ontenemos los valores de los campos de contraseñas 
    pass1 = document.getElementById("pass1");
    pass2 = document.getElementById("pass2");
 
    // Verificamos si las constraseñas no coinciden 
    if (pass1.value != pass2.value) {
 
        // Si las constraseñas no coinciden mostramos un mensaje 
        document.getElementById("error").classList.add("mostrar");
 
        return false;
    } else {
 
        // Si las contraseñas coinciden ocultamos el mensaje de error
        document.getElementById("error").classList.remove("mostrar");
 
        // Mostramos un mensaje mencionando que las Contraseñas coinciden 
        document.getElementById("ok").classList.remove("ocultar");
 
        // Desabilitamos el botón de login 
        document.getElementById("login").disabled = true;
 
        // Refrescamos la página (Simulación de envío del formulario) 
        setTimeout(function() {
            location.reload();
        }, 3000);
 
        return true;
    }
 
}
</script> 
  

<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "companyser2.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>
 
 
<?php
include '../dat/cdb/db.php'; 
$CompanyID= utf8_decode($_GET['CompanyID']); 
$CompanyID = utf8_decode($_GET['CompanyID']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM company WHERE CompanyID = '".$CompanyID."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$CompanyID=$row['CompanyID'];
$CompanyName=$row['CompanyName'];
$CompanyAddress=$row['CompanyAddress'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
 
 <?php  
$CompanyName = utf8_decode($_GET['CompanyName']); 
?> 
</head>
<body>
<div class="wrapper">
  <!-- header start -->
  <header class="header">

        <div class="header-main">
           <div class="logo">
               <img src="../img/aranaConsulting-logo.png">
           </div>
           <div class="open-nav-menu">
              <span></span>
           </div>
           <div class="menu-overlay">
           </div>
           <!-- navigation menu start -->
           <nav class="nav-menu">
             <div class="close-nav-menu">
                <img src="../img/close.svg" alt="close">
             </div>
             <ul class="menu">
               <li class="menu-item ">
                   <a href="../index.html" style="color:brown;">HOME</a>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">PORTFOLIO  <i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design</a></li>
                       <li class="menu-item"><a href="#">Start Up Consulting</a></li>
                       <li class="menu-item"><a href="#">Business Investment</a></li>
                     
                   </ul>
                </li>
                
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">SERVICES<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design & Marketing Development</a></li>
                       <li class="menu-item"><a href="#">
                        Start Up Consulting & Proof Techniques</a></li>
                   <li class="menu-item"><a href="#">Business Investment In Portugal</a></li>
                   </ul>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">ABOUT US<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Company History</a></li>
                       <li class="menu-item"><a href="#">Company Presentation</a></li>
                       <li class="menu-item"><a href="../login.html">login</a></li>
                   </ul>
                </li>
                  <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">FAQs<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">All FAQs</a></li>
                       <li class="menu-item"><a href="#">10 Important FAQ</a></li>
                      
                   </ul>
                </li>
               <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">LEGALS<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Cookies Policy</a></li>
                       <li class="menu-item"><a href="#">Data Protection</a></li>
                       <li class="menu-item"><a href="#">Privacy Policy</a></li>
                       <li class="menu-item"><a href="#">Terms and Condition</a></li>
                   </ul>
                </li>
                <li class="menu-item">
                   <a href="#">CONTACT US</a>
                </li>
                 <li class="menu-item">
                   <img src="../img/england-image.jpg">
                </li>
                 <li class="menu-item">
                  <img src="../img/germany.jpg">
                </li>
                 <li class="menu-item">
                   <img src="../img/purtugal-flag.jpg">
                </li>
             </ul>
           </nav>
           <!-- navigation menu end -->
   
     </div>
  </header>
  <!-- header end -->
</div>


<div class="social-links" >
  <div class="slide-toggle arrow-stickynav">
    <img src="../img/hide-social.png">
  </div>
    <div class="box">
      <div class="exhibitor-login">
            <a href="">Contact</a>
        </div>
        <div class="exhibitor-login exhibitor-pro">
            <a href="">Promotions</a>
        </div>
        <div class="social-links-body">
        <div class="menu-fixed-social-navigation-container">
          <ul id="menu-fixed-social-navigation" class="menu">
            <li id="menu-item-305" class="facebook-fix "><a target="_blank" rel="noopener noreferrer" href="#">Facebook</a></li>
           <li id="menu-item-306" class="instagram-fix"><a target="_blank" rel="noopener noreferrer" href="#">Instagram</a></li>
           <li id="menu-item-307" class="linked-in-fix"><a target="_blank" rel="noopener noreferrer" href="#">Linked In</a></li>
           <li id="menu-item-308" class="whatsapp-fix"><a target="_blank" rel="noopener noreferrer" href="#">WhatsApp</a></li>
           </ul>
         </div>   
              </div>

</div>
</div>
<script>
    var $ = jQuery;
        $(document).ready(function(){
    $(".slide-toggle").click(function(){
        $(".box").animate({
        width: "toggle"
        });
    });
    });
</script>
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
  
 
<div> <h2>company</h2> </div> 
 

<h2>busca por <strong class="cur">CompanyName</strong></h2>
<form action="companyser.php" method="POST">
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $CompanyName; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>  
 
<a href="../index.html?<?php echo $idusu; ?>">Back</a>

<div class="main-footer">
 <footer class="footer">
     <div class="container">
      <div class="row">
        <div class="footer-col">
          <h4>INFORMATION</h4>
          <ul>
            <li><a href="#">HOME</a></li>
            <li><a href="#">PORTFOLIO</a></li>
            <li><a href="#">SERVICES</a></li>
            <li><a href="#">CONTACT US</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>HOW CAN WE HELP?</h4>
          <ul>
            <li><a href="#">ALL FAQs</a></li>
            <li><a href="#">TERMS & CONDITIONS</a></li>
            <li><a href="#">PRIVACY POLICY</a></li>
            <li><a href="#">COOKIES POLICY</a></li>
            <li><a href="#">DATA PROTECTION</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>CONTACT US</h4>
          <ul>
            <li style="color:white;font-weight:bold;  font-family: "Raleway", sans-serif; ">ADDRESS</li>
            <li style="color:white;font-weight:bold;text-transform: uppercase;   
            font-family:"Raleway", sans-serif;">Calcada Do Carrascal <span class="num">180, 2 </span>DTO
            <span class="num">1900 - 
            135</span> Lisboa / Portugal
            </li>
            
          </ul>
        </div>
        <div class="footer-col">
         
          <div class="company_logo">
              <img src="../img/Aranath.png" width="200px">
          </div>
        </div>
      </div>
     </div>
  </footer>
  <div class="second-footer">
       <p>©COPYRIGHT | ARANATH-ZENITRAM <span class="num">2019.</span></p>
  </div>
</div>


<script src="../js/script.js"></script>
<script src="../js/script1.js"></script>

</body>
</html>
  
