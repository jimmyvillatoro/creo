<?php 
include '../dat/cdb/db.php'; 
 
$CompanyID= $_REQUEST['CompanyID'];
$CompanyName= $_REQUEST['CompanyName'];
$CompanyAddress= $_REQUEST['CompanyAddress'];
$Contact= $_REQUEST['Contact'];
$Email= $_REQUEST['Email'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM company WHERE CompanyID = '".$CompanyID."'" ); 
if (mysqli_num_rows($resultado)>0) {
$update_value = "UPDATE company SET CompanyName= '".$CompanyName."', CompanyAddress= '".$CompanyAddress."', Contact= '".$Contact."', Email= '".$Email."'   WHERE   CompanyID = '".$CompanyID."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: ../tableco.php"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../tableco.php");  }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
