<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$CompanyID = $_REQUEST['CompanyID'];
$CompanyID = $_REQUEST['CompanyID']; 
$CompanyID = $_REQUEST['CompanyID'];
 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM company WHERE CompanyName LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$CompanyID=$row['CompanyID'];
$html.= '<p><a href=companyupd2.php?CompanyID='.$CompanyID.'>'.$CompanyID.'</a></p></b>';$html.= '<p>'.$CompanyID.'</p></b>'; 
$CompanyName=$row['CompanyName'];
$html.= '<p>'.$CompanyName.'</p></b>'; 
$CompanyAddress=$row['CompanyAddress'];
$html.= '<p>'.$CompanyAddress.'</p></b>'; 
$Contact=$row['Contact'];
$html.= '<p>'.$Contact.'</p></b>'; 
$Email=$row['Email'];
$html.= '<p>'.$Email.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
