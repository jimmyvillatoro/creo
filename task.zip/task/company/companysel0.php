<?php
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>company</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../css/style.css">
   <link rel="stylesheet" type="text/css" href="../css/registration.css">
     <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
  
  

<?php
include 'db.php'; 
$CompanyName= utf8_decode($_GET['CompanyName']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM company WHERE CompanyName LIKE '".$CompanyName."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$CompanyID=$row['CompanyID'];
$CompanyName=$row['CompanyName'];
$CompanyAddress=$row['CompanyAddress'];
$Contact=$row['Contact'];
$Email=$row['Email'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head>
<!-- body --> 
<body> 
<div> 
<h2>'.company.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=5 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>CompanyID</th> 
<th>CompanyName</th> 
<th>CompanyAddress</th> 
<th>Contact</th> 
<th>Email</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $CompanyID; ?></th> 
<th><?php echo $CompanyName; ?></th> 
<th><?php echo $CompanyAddress; ?></th> 
<th><?php echo $Contact; ?></th> 
<th><?php echo $Email; ?></th> 
</tr></table></br></br> 
 
<a href="../index.html?<?php echo $idusu; ?>">Back</a>
</body> </html>