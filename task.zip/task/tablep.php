<?php
session_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   

<?php 
include 'dat/cdb/db.php';

date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 

if(!$_SESSION['EmployeeID'])
{
 echo '<a href="index.php" title="" class="round">Inicie sesion</a>';
  exit;
}
$resultado=mysqli_query($db_connection, "SELECT EmployeeName FROM employees WHERE EmployeeID='".$_SESSION['EmployeeID']."'  ");

$cuenta=0;
while ($row =mysqli_fetch_array($resultado)) {
$EmployeeName=$row['EmployeeName'];
   }


$numproj=mysqli_query($db_connection, "SELECT COUNT(*) Nump FROM project WHERE EmployeeID='".$_SESSION['EmployeeID']."'  ");
//WHERE EmployeeID='".$_SESSION['EmployeeID']."'
$row =mysqli_fetch_array($numproj);
$Nump=$row['Nump'];

$np=mysqli_query($db_connection, "SELECT COUNT(*) ED FROM project WHERE  ProjectStartDate  <= '".$dt."' && EmployeeID='".$_SESSION['EmployeeID']."' ");
$row =mysqli_fetch_array($np);
$ED=$row['ED'];

$np=mysqli_query($db_connection, "SELECT COUNT(*) FD FROM project WHERE  ProjectEndDate  <= '".$dt."'  && EmployeeID='".$_SESSION['EmployeeID']."' ");
$row =mysqli_fetch_array($np);
$FD=$row['FD'];

$P=$ED-$FD;
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "project/projectser2.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index2.php">Admin</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Last access : <?php echo $dt; ?> &nbsp; <a href="index.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
            <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
        <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
          </li>
        
          
                    <li>
                        <a  href="index2.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
<?php
if($_SESSION['ManagerID']==0)
{
?>
                      <li  >
                        <a  href="tableco.php"><i class="fa fa-table fa-3x"></i>Company</a>
                    </li>               <li  >
                        <a  href="table.php"><i class="fa fa-table fa-3x"></i>Employees</a>
                    </li>
                     <li>
                        <a  href="tablec.php"><i class="fa fa-table fa-3x"></i>Client</a>
                    </li>
                      <li>
                        <a class="active-menu" href="tablep.php"><i class="fa fa-table fa-3x"></i>Project</a>
                    </li>
<?php
}
?>      
                      <li>
                        <a  href="tablet.php"><i class="fa fa-table fa-3x"></i>Task</a>
                    </li>
                      <li>
                        <a  href="tables.php"><i class="fa fa-table fa-3x"></i>SubTask</a>
                    </li>
    
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Project</h2>   
                        <h5>Welcome <?php echo $EmployeeName ?>, Love to see you back. </h5>
          
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-green set-icon">
                    <i class="fa fa-bars"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Nump; ?> Project</p>
                    <p class="text-muted">Remaining</p>
                </div>
             </div>
		     </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $ED; ?> startdate</p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div>
		                     <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $FD; ?> enddate </p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div>    
		     
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-brown set-icon">
                    <i class="fa fa-rocket"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $P; ?> Orders</p>
                    <p class="text-muted">Pending</p>
                </div>
             </div>
		     </div>
			           
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">


<h1>Search for <strong class="cur">ProjectName</strong></h1>
<form action="tablep.php" method="POST">
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>              
  
 <h1>Add</h1>
<form action="project/projectadd.php" method="POST">
 
<input type='hidden' name='EmployeeID'   value='<?php echo $_SESSION['EmployeeID']; ?>' > 
 
<p>ClientName</p>
<div class="Reg">
<div class="Regbox">
<SELECT NAME="ClientID"> 
<OPTION SELECTED ="selected" VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$resulta=mysqli_query($db_connection, "SELECT ClientName, ClientID FROM  client ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$ClientName =$row['ClientName'];
$ClientID =$row['ClientID'];
?>
<OPTION VALUE="<?php echo $ClientID; ?>"> <?php echo $ClientName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>
 
<p>ProjectName</p>
<div><input type='text' name='ProjectName'   placeholder='ProjectName' required> </div>  
 
 
<p>ProjectDescription</p>
<div><textarea name='ProjectDescription' rows='5' cols='60'>Description</textarea> </div>  
 
<p>ProjectStartDate</p>
<div><input type='date' name='ProjectStartDate'  placeholder='ProjectStartDate'  required> </div>  
 
 
<p>ProjectEndDate</p>
<div><input type='date' name='ProjectEndDate'   placeholder='ProjectEndDate'  required> </div>  
 
 
<div><button type='submit' class='btn btn-success'>Add</button></div>

</form> 
  
  
<h1>Edit</h1>

<table class="table">
<thead>
<tr>
<th>Editar</th>
<th>ProjectName</th> 
<th>ProjectDescription</th> 
<th>ProjectStartDate</th> 
<th>ProjectEndDate</th>
</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT * FROM project WHERE EmployeeID='".$_SESSION['EmployeeID']."' " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$ProjectID=$row['ProjectID'];
$ClientID=$row['ClientID'];
$EmployeeID=$row['EmployeeID'];
$ProjectName=$row['ProjectName'];
$ProjectDescription=$row['ProjectDescription'];
$ProjectStartDate=$row['ProjectStartDate'];
$ProjectEndDate=$row['ProjectEndDate'];
 ?>
<tbody>
<?php

if($ProjectEndDate<$dt)
echo '<tr class="danger">';
if($ProjectEndDate>$dt)
echo '<tr class="success">';
 ?>
<form action="project/projectupd3.php" method="POST"> 
<input type='hidden' name='ProjectID' value='<?php echo $ProjectID; ?>'> 
<input type='hidden' name='ClientID' value='<?php echo $ClientID; ?>'> 
<input type='hidden' name='EmployeeID' value='<?php echo $EmployeeID; ?>'>  
 
<td><button type='submit' class='btn btn-success'>Edit</button> </td> 

 
<td><input type='text' name='ProjectName'  class='form-control' placeholder='ProjectName' value='<?php echo $ProjectName; ?>' class='form-input' required> </td>  
 
<td><input type='text' name='ProjectDescription'  class='form-control' placeholder='ProjectDescription' value='<?php echo $ProjectDescription; ?>' class='form-input' required> </td>  
 
<td><input type='date' name='ProjectStartDate'  class='form-control' placeholder='ProjectStartDate' value='<?php echo $ProjectStartDate; ?>' class='form-input' required> </td>  
 
<td><input type='date' name='ProjectEndDate'  class='form-control' placeholder='ProjectEndDate' value='<?php echo $ProjectEndDate; ?>' class='form-input' required> </td>  
 
</form> 
<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
                        </tbody>
                              </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

 <h3>Delete</h3>
<form action="project/projectdel.php" method="POST"> 
 
<div><input type='text' name='Idx' class='form-control' placeholder='ProjectID' class='form-input' required></div>  
<div> <button type='submit' class='btn btn-success'>Delete</button> </div> 
</form> 
  
   

            </div>
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>