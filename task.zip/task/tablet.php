<?php
session_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   

<?php 
include 'dat/cdb/db.php';
date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
if(!$_SESSION['EmployeeID'])
{
 echo '<a href="index.php" title="" class="round">Inicie sesion</a>';
  exit;
}
$resultado=mysqli_query($db_connection, "SELECT EmployeeName FROM employees WHERE EmployeeID='".$_SESSION['EmployeeID']."'  ");

$cuenta=0;
while ($row =mysqli_fetch_array($resultado)) {
$EmployeeName=$row['EmployeeName'];
   }

$c=mysqli_query($db_connection, "SELECT COUNT(t.Comments) C FROM task t, project p WHERE p.ProjectID=t.ProjectID && LENGTH(t.Comments)>0 && p.EmployeeID='".$_SESSION['EmployeeID']."'");
$row =mysqli_fetch_array($c);
$C=$row['C'];

$numtask=mysqli_query($db_connection, "SELECT COUNT(*) Numt FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' ");
$row =mysqli_fetch_array($numtask);
$Numt=$row['Numt'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) NtIn FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && IntroductionDate <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$NtIn=$row['NtIn'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Nt FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && startingDate <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Nt=$row['Nt'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Nte FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && DateFinishWork  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Nte=$row['Nte'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Ntr FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && retouchDate  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Ntr=$row['Ntr'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) Nti FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && internalDeathLineDate  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$Nti=$row['Nti'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) NtE FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && ExternalDeathLineDate  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$NtE=$row['NtE'];

$ntask=mysqli_query($db_connection, "SELECT COUNT(*) NtD FROM task t, project p WHERE p.ProjectID=t.ProjectID && p.EmployeeID='".$_SESSION['EmployeeID']."' && DateWaiting  <= '".$dt."' ");
$row =mysqli_fetch_array($ntask);
$NtD=$row['NtD'];

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "task/taskser2.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index2.php">Admin</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Last access : <?php echo $dt; ?> &nbsp; <a href="index.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
            <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
        <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
          </li>
        
          
                    <li>
                        <a  href="index2.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
<?php
if($_SESSION['ManagerID']==0)
{
?>
                       <li  >
                        <a  href="tableco.php"><i class="fa fa-table fa-3x"></i>Company</a>
                    </li>              <li  >
                        <a  href="table.php"><i class="fa fa-table fa-3x"></i>Employees</a>
                    </li>
                     <li>
                        <a  href="tablec.php"><i class="fa fa-table fa-3x"></i>Client</a>
                    </li>
                      <li>
                        <a  href="tablep.php"><i class="fa fa-table fa-3x"></i>Project</a>
                    </li>
<?php
}
?>      
                      <li>
                        <a class="active-menu" href="tablet.php"><i class="fa fa-table fa-3x"></i>Task</a>
                    </li>
                      <li>
                        <a  href="tables.php"><i class="fa fa-table fa-3x"></i>SubTask</a>
                    </li>
    
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Task</h2>   
                        <h5>Welcome <?php echo $EmployeeName ?>, Love to see you back. </h5>
                 
                 
        		<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-red set-icon">
                    <i class="fa fa-envelope-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $C; ?> Comments</p>
                     <a href="tablet.php" class="text-muted">Today</a>
                </div>
             </div>
		     </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-green set-icon">
                    <i class="fa fa-bars"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Numt; ?> Tasks</p>
                    <p class="text-muted">Remaining</p>
                </div>
             </div>
		     </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $NtIn; ?> Introduction</p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div>
		     
		                      <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Nt; ?> starting</p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div>
       
       
                       <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Ntr; ?> retouch</p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div> 
                        <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Nti; ?> internalDeathLine</p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div>
		     
		                   <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $NtE; ?> ExternalDeathLine</p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div>   
		                     <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $NtD; ?> Waiting</p>
                    <p class="text-muted">Notifications</p>
                </div>
             </div>
		     </div> 
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-brown set-icon">
                    <i class="fa fa-rocket"></i>
                </span>
                <div class="text-box" >
                    <p class="main-text"><?php echo $Nte; ?> Orders</p>
                    <p class="text-muted">FinishWork Pending</p>
                </div>
             </div>
		     </div>
     

<table class="table">
<thead>
<tr class="info">
<th>TaskName</th> 
<th>TaskType</th> 
<th>task_status</th> 
<th>SubResponsableExternal</th>
</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT t.TaskName TaskName, t.TaskType TaskType, t.task_status task_status, t.SubResponsableExternal SubResponsableExternal FROM task t, project p WHERE p.ProjectID=t.ProjectID AND t.task_status = 'Pending' OR t.task_status = 'Not paid' AND p.EmployeeID='".$_SESSION['EmployeeID']."' GROUP BY t.TaskNumber ");
while ($row =mysqli_fetch_array($resultado)) 
{  

$TaskName=$row['TaskName'];
$TaskType=$row['TaskType'];
$task_status=$row['task_status'];
$SubResponsableExternal=$row['SubResponsableExternal'];

 ?>
<tbody>
<?php
if($task_status=='Started')
echo '<tr class="warning">';
if($task_status=='Completed')
echo '<tr class="success">';
if($task_status=='Pending')
echo '<tr class="warning">';
if($task_status=='Not paid')
echo '<tr class="danger">';
if($task_status=='Not Started')
echo '<tr class="info">';

 ?>
 
<td><?php echo $TaskName; ?></td>  
<td><?php echo $TaskType; ?></td>  
<td><?php echo $task_status; ?></td>   
<td><?php echo $SubResponsableExternal; ?></td>  
 
<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
</tbody>
</table>
                       
<h1>For1</h1>
<table class="table">
<thead>
<tr class="info">
<th>TaskName</th> 
<th>TaskType</th> 
<th>task_status</th> 

</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT t.TaskName TaskName, t.TaskType TaskType, t.task_status task_status FROM task t, project p WHERE p.ProjectID=t.ProjectID AND t.For1='".$_SESSION['EmployeeID']."' GROUP BY t.TaskNumber ");
while ($row =mysqli_fetch_array($resultado)) 
{  

$TaskName=$row['TaskName'];
$TaskType=$row['TaskType'];
$task_status=$row['task_status'];

 ?>
<tbody>
<?php
if($task_status=='Started')
echo '<tr class="warning">';
if($task_status=='Completed')
echo '<tr class="success">';
if($task_status=='Pending')
echo '<tr class="warning">';
if($task_status=='Not paid')
echo '<tr class="danger">';
if($task_status=='Not Started')
echo '<tr class="info">';

 ?>
 
<td><?php echo $TaskName; ?></td>  
<td><?php echo $TaskType; ?></td>  
<td><?php echo $task_status; ?></td>   

<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
</tbody>
</table>

<h2>For1 Edit</h2> 
<table class="table">
<thead>
<tr class="info">
<th>Editar</th>
<th>TaskName</th> 
<th>TaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th>
<th>ExternalDeathLineDate</th>
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>For1</th> 
<th>SubResponsableExternal</th>
<th>For2</th> 
<th>Comments</th> 
<th>Link</th> 
</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT * FROM task t, project p WHERE p.ProjectID=t.ProjectID AND t.For1='".$_SESSION['EmployeeID']."' GROUP BY t.TaskNumber " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$TaskNumber=$row['TaskNumber'];
$ProjectID=$row['ProjectID'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$TaskName=$row['TaskName'];
$TaskType=$row['TaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$For1=$row['For1'];
$SubResponsableExternal=$row['SubResponsableExternal'];
$For2=$row['For2'];
$Comments=$row['Comments'];
$Link=$row['Link'];
 ?>
<tbody>
<?php
if($task_status=='Started')
echo '<tr class="warning">';
if($task_status=='Completed')
echo '<tr class="success">';
if($task_status=='Pending')
echo '<tr class="warning">';
if($task_status=='Not paid')
echo '<tr class="danger">';
if($task_status=='Not Started')
echo '<tr class="info">';

 ?>
<form action="task/taskupd4.php" method="POST"> 
<input type='hidden' name='TaskNumber' value='<?php echo $TaskNumber; ?>'> 
<input type='hidden' name='ProjectID' value='<?php echo $ProjectID; ?>'> 
<input type='hidden' name='SuperVisorEmployeeID' value='<?php echo $SuperVisorEmployeeID; ?>'> 
 
<td><button type='submit' class='btn btn-success'>Edit</button> </td> 

 
<td><input type='text' name='TaskName'   placeholder='TaskName' value='<?php echo $TaskName; ?>'  required> </td>  
 
<td><input type='text' name='TaskType'   placeholder='TaskType' value='<?php echo $TaskType; ?>'  required> </td>  
 
 
<td><div><select name='task_status'>
  <option value='Not Started'>Not Started</option>
  <option value='Started'>Started</option>
  <option value='Pending'>Pending</option>
  <option value='Completed'>Completed</option>
  <option value='Not paid'>Not paid</option>
<option value='<?php echo $task_status; ?>' SELECTED ="selected"><?php echo $task_status; ?></option>
</select> </div></td>   
 
<td><input type='date' name='IntroductionDate'   placeholder='IntroductionDate' value='<?php echo $IntroductionDate; ?>'  required> </td>  
 
<td><input type='date' name='startingDate'   placeholder='startingDate' value='<?php echo $startingDate; ?>'  required> </td>  
 
<td><input type='date' name='retouchDate'  class='form-control' placeholder='retouchDate' value='<?php echo $retouchDate; ?>' class='form-input' required> </td>  
 
<td><input type='TEXT' name='quantityOfRetouch'    placeholder='quantityOfRetouch' value='<?php echo $quantityOfRetouch; ?>'  required> </td>  
 
<td><input type='date' name='internalDeathLineDate'   placeholder='internalDeathLineDate' value='<?php echo $internalDeathLineDate; ?>'  required> </td>  
 
<td><input type='date' name='ExternalDeathLineDate'  placeholder='ExternalDeathLineDate' value='<?php echo $ExternalDeathLineDate; ?>'  required> </td>  
 
<td><input type='date' name='DateWaiting' placeholder='DateWaiting' value='<?php echo $DateWaiting; ?>'  required> </td> </td> 
 
<td><input type='date' name='DateFinishWork'   placeholder='DateFinishWork' value='<?php echo $DateFinishWork; ?>'  required> </td>  
 
<td>
<SELECT NAME="For1" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2=  $For1;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 

 
 <td>
<SELECT NAME="SubResponsableExternal" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2=  $SubResponsableExternal;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 
 
<td>
<SELECT NAME="For2" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2= $For2;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 
<td><textarea name='Comments' rows='5' cols='60'><?php echo $Comments; ?></textarea></td>
 
<td><input type='text' name='Link'   placeholder='Link' value='<?php echo $Link; ?>'  required> </td>   
 
</form> 
<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
                        </tbody>
                              </table> 

<h1>SubResponsableExternal</h1>
<table class="table">
<thead>
<tr class="info">
<th>TaskName</th> 
<th>TaskType</th> 
<th>task_status</th> 

</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT t.TaskName TaskName, t.TaskType TaskType, t.task_status task_status FROM task t, project p WHERE p.ProjectID=t.ProjectID AND t.task_status = 'Pending' OR t.task_status = 'Not paid' AND t.SubResponsableExternal='".$_SESSION['EmployeeID']."' GROUP BY t.TaskNumber ");
while ($row =mysqli_fetch_array($resultado)) 
{  

$TaskName=$row['TaskName'];
$TaskType=$row['TaskType'];
$task_status=$row['task_status'];

 ?>
<tbody>
<?php
if($task_status=='Started')
echo '<tr class="warning">';
if($task_status=='Completed')
echo '<tr class="success">';
if($task_status=='Pending')
echo '<tr class="warning">';
if($task_status=='Not paid')
echo '<tr class="danger">';
if($task_status=='Not Started')
echo '<tr class="info">';

 ?>
 
<td><?php echo $TaskName; ?></td>  
<td><?php echo $TaskType; ?></td>  
<td><?php echo $task_status; ?></td>   

<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
</tbody>
</table>

<h2>SubResponsableExternal Edit</h2> 
<table class="table">
<thead>
<tr class="info">
<th>Editar</th>
<th>TaskName</th> 
<th>TaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th>
<th>ExternalDeathLineDate</th>
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>For1</th> 
<th>SubResponsableExternal</th>
<th>For2</th> 
<th>Comments</th> 
<th>Link</th> 
</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT * FROM task t, project p WHERE p.ProjectID=t.ProjectID AND t.SubResponsableExternal='".$_SESSION['EmployeeID']."' GROUP BY t.TaskNumber " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$TaskNumber=$row['TaskNumber'];
$ProjectID=$row['ProjectID'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$TaskName=$row['TaskName'];
$TaskType=$row['TaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$For1=$row['For1'];
$SubResponsableExternal=$row['SubResponsableExternal'];
$For2=$row['For2'];
$Comments=$row['Comments'];
$Link=$row['Link'];
 ?>
<tbody>
<?php
if($task_status=='Started')
echo '<tr class="warning">';
if($task_status=='Completed')
echo '<tr class="success">';
if($task_status=='Pending')
echo '<tr class="warning">';
if($task_status=='Not paid')
echo '<tr class="danger">';
if($task_status=='Not Started')
echo '<tr class="info">';

 ?>
<form action="task/taskupd4.php" method="POST"> 
<input type='hidden' name='TaskNumber' value='<?php echo $TaskNumber; ?>'> 
<input type='hidden' name='ProjectID' value='<?php echo $ProjectID; ?>'> 
<input type='hidden' name='SuperVisorEmployeeID' value='<?php echo $SuperVisorEmployeeID; ?>'> 
 
<td><button type='submit' class='btn btn-success'>Edit</button> </td> 

 
<td><input type='text' name='TaskName'   placeholder='TaskName' value='<?php echo $TaskName; ?>'  required> </td>  
 
<td><input type='text' name='TaskType'   placeholder='TaskType' value='<?php echo $TaskType; ?>'  required> </td>  
 
 
<td><div><select name='task_status'>
  <option value='Not Started'>Not Started</option>
  <option value='Started'>Started</option>
  <option value='Pending'>Pending</option>
  <option value='Completed'>Completed</option>
  <option value='Not paid'>Not paid</option>
<option value='<?php echo $task_status; ?>' selected><?php echo $task_status; ?></option>
</select> </div></td>   
 
<td><input type='date' name='IntroductionDate'   placeholder='IntroductionDate' value='<?php echo $IntroductionDate; ?>'  required> </td>  
 
<td><input type='date' name='startingDate'   placeholder='startingDate' value='<?php echo $startingDate; ?>'  required> </td>  
 
<td><input type='date' name='retouchDate'  class='form-control' placeholder='retouchDate' value='<?php echo $retouchDate; ?>' class='form-input' required> </td>  
 
<td><input type='TEXT' name='quantityOfRetouch'    placeholder='quantityOfRetouch' value='<?php echo $quantityOfRetouch; ?>'  required> </td>  
 
<td><input type='date' name='internalDeathLineDate'   placeholder='internalDeathLineDate' value='<?php echo $internalDeathLineDate; ?>'  required> </td>  
 
<td><input type='date' name='ExternalDeathLineDate'  placeholder='ExternalDeathLineDate' value='<?php echo $ExternalDeathLineDate; ?>'  required> </td>  
 
<td><input type='date' name='DateWaiting' placeholder='DateWaiting' value='<?php echo $DateWaiting; ?>'  required> </td> </td> 
 
<td><input type='date' name='DateFinishWork'   placeholder='DateFinishWork' value='<?php echo $DateFinishWork; ?>'  required> </td>  
 
<td>
<SELECT NAME="For1" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2=  $For1;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 

 
 <td>
<SELECT NAME="SubResponsableExternal" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2=  $SubResponsableExternal;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 
 
<td>
<SELECT NAME="For2" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2= $For2;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 
<td><textarea name='Comments' rows='5' cols='60'><?php echo $Comments; ?></textarea></td>  
 
<td><input type='text' name='Link'   placeholder='Link' value='<?php echo $Link; ?>'  required> </td>   
 
</form> 
<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
                        </tbody>
                              </table> 

<h1>For2</h1>
<table class="table">
<thead>
<tr class="info">
<th>TaskName</th> 
<th>TaskType</th> 
<th>task_status</th> 
</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT t.TaskName TaskName, t.TaskType TaskType, t.task_status task_status FROM task t, project p WHERE p.ProjectID=t.ProjectID AND t.For2='".$_SESSION['EmployeeID']."' GROUP BY t.TaskNumber ");
while ($row =mysqli_fetch_array($resultado)) 
{  

$TaskName=$row['TaskName'];
$TaskType=$row['TaskType'];
$task_status=$row['task_status'];

 ?>
<tbody>
<?php
if($task_status=='Started')
echo '<tr class="warning">';
if($task_status=='Completed')
echo '<tr class="success">';
if($task_status=='Pending')
echo '<tr class="warning">';
if($task_status=='Not paid')
echo '<tr class="danger">';
if($task_status=='Not Started')
echo '<tr class="info">';

 ?>
 
<td><?php echo $TaskName; ?></td>  
<td><?php echo $TaskType; ?></td>  
<td><?php echo $task_status; ?></td>   

<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
</tbody>
</table>

<h2>For2 Edit</h2> 
<table class="table">
<thead>
<tr class="info">
<th>Editar</th>
<th>TaskName</th> 
<th>TaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th>
<th>ExternalDeathLineDate</th>
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>For1</th> 
<th>SubResponsableExternal</th>
<th>For2</th> 
<th>Comments</th> 
<th>Link</th> 
</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT * FROM task t, project p WHERE p.ProjectID=t.ProjectID AND t.For2='".$_SESSION['EmployeeID']."' GROUP BY t.TaskNumber " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$TaskNumber=$row['TaskNumber'];
$ProjectID=$row['ProjectID'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$TaskName=$row['TaskName'];
$TaskType=$row['TaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$For1=$row['For1'];
$SubResponsableExternal=$row['SubResponsableExternal'];
$For2=$row['For2'];
$Comments=$row['Comments'];
$Link=$row['Link'];
 ?>
<tbody>
<?php
if($task_status=='Started')
echo '<tr class="warning">';
if($task_status=='Completed')
echo '<tr class="success">';
if($task_status=='Pending')
echo '<tr class="warning">';
if($task_status=='Not paid')
echo '<tr class="danger">';
if($task_status=='Not Started')
echo '<tr class="info">';

 ?>
<form action="task/taskupd4.php" method="POST"> 
<input type='hidden' name='TaskNumber' value='<?php echo $TaskNumber; ?>'> 
<input type='hidden' name='ProjectID' value='<?php echo $ProjectID; ?>'> 
<input type='hidden' name='SuperVisorEmployeeID' value='<?php echo $SuperVisorEmployeeID; ?>'> 
 
<td><button type='submit' class='btn btn-success'>Edit</button> </td> 

 
<td><input type='text' name='TaskName'   placeholder='TaskName' value='<?php echo $TaskName; ?>'  required> </td>  
 
<td><input type='text' name='TaskType'   placeholder='TaskType' value='<?php echo $TaskType; ?>'  required> </td>  
 
 
<td><div><select name='task_status'>
  <option value='Not Started'>Not Started</option>
  <option value='Started'>Started</option>
  <option value='Pending'>Pending</option>
  <option value='Completed'>Completed</option>
  <option value='Not paid'>Not paid</option>
<option value='<?php echo $task_status; ?>' selected><?php echo $task_status; ?></option>
</select> </div></td>   
 
<td><input type='date' name='IntroductionDate'   placeholder='IntroductionDate' value='<?php echo $IntroductionDate; ?>'  required> </td>  
 
<td><input type='date' name='startingDate'   placeholder='startingDate' value='<?php echo $startingDate; ?>'  required> </td>  
 
<td><input type='date' name='retouchDate'  class='form-control' placeholder='retouchDate' value='<?php echo $retouchDate; ?>' class='form-input' required> </td>  
 
<td><input type='TEXT' name='quantityOfRetouch'    placeholder='quantityOfRetouch' value='<?php echo $quantityOfRetouch; ?>'  required> </td>  
 
<td><input type='date' name='internalDeathLineDate'   placeholder='internalDeathLineDate' value='<?php echo $internalDeathLineDate; ?>'  required> </td>  
 
<td><input type='date' name='ExternalDeathLineDate'  placeholder='ExternalDeathLineDate' value='<?php echo $ExternalDeathLineDate; ?>'  required> </td>  
 
<td><input type='date' name='DateWaiting' placeholder='DateWaiting' value='<?php echo $DateWaiting; ?>'  required> </td> </td> 
 
<td><input type='date' name='DateFinishWork'   placeholder='DateFinishWork' value='<?php echo $DateFinishWork; ?>'  required> </td>  
 
<td>
<SELECT NAME="For1" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2=  $For1;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 

 
 <td>
<SELECT NAME="SubResponsableExternal" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2=  $SubResponsableExternal;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 
 
<td>
<SELECT NAME="For2" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2= $For2;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 
<td><textarea name='Comments' rows='5' cols='60'><?php echo $Comments; ?></textarea></td>
 
<td><input type='text' name='Link'   placeholder='Link' value='<?php echo $Link; ?>'  required> </td>   
 
</form> 
<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
                        </tbody>
                              </table>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">


<h1>Search for <strong class="cur">SubTaskName</strong></h1>
<form action="tablet.php" method="POST">
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>              
  
 <h1>Add</h1>
  

 

<form action="task/taskadd.php" method="POST">

 

 <p>ProjectName</p>
 <div class="Reg">
<div class="Regbox">
<SELECT NAME="ProjectID" SIZE=1 > 
<OPTION SELECTED ="selected" VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$resulta=mysqli_query($db_connection, "SELECT ProjectID, ProjectName FROM  project ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$ProjectID =$row['ProjectID'];
$ProjectName =$row['ProjectName'];
?>
<OPTION VALUE="<?php echo $ProjectID; ?>"> <?php echo $ProjectName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}

mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>


<p>SuperVisorEmployeeName</p>
<div class="Reg">
<div class="Regbox">
<SELECT NAME="SuperVisorEmployeeID" SIZE=1 > 
<OPTION SELECTED ="selected" VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}

mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>


  <p>TaskName</p>
<input type='text' name='TaskName'   placeholder='TaskName'  required>   
 
 
  <p>TaskType</p>
<div><input type='text' name='TaskType'  placeholder='TaskType'  required> </div>  
 
 
  <p>task_status</p>
<div><select name='task_status'>
  <option value='Not Started'>Not Started</option>
  <option value='Started'>Started</option>
  <option value='Pending'>Pending</option>
  <option value='Completed'>Completed</option>
  <option value='Not paid'>Not paid</option>
</select> </div> 
 
 
 <p>IntroductionDate </p>
<div><input type='date' name='IntroductionDate'   placeholder='IntroductionDate' required> </div>  
 
 
 <p>startingDate </p>
<div><input type='date' name='startingDate'   placeholder='startingDate'  required> </div>  
 
 
 <p>retouchDate </p>
<div><input type='date' name='retouchDate'   placeholder='retouchDate'  required> </div>  
 
 
  <p>quantityOfRetouch</p>
<div><input type='TEXT' name='quantityOfRetouch'   placeholder='quantityOfRetouch' required> </div>  
 
 
<p>internalDeathLineDate </p> 
<div><input type='date' name='internalDeathLineDate'  placeholder='internalDeathLineDate'  required> </div>  
 
 
<p>ExternalDeathLineDate </p> 
<div><input type='date' name='ExternalDeathLineDate'   placeholder='ExternalDeathLineDate'  required> </div>  
 
 
 <p>DateWaiting </p>
<div><input type='date' name='DateWaiting'  placeholder='DateWaiting'  required> </div>  
 
 
 <p>DateFinishWork</p>
<div><input type='date' name='DateFinishWork'   placeholder='DateFinishWork'  required> </div>  
 
 
  <p>For1</p>
<div> 
<SELECT NAME="For1" SIZE=1> 
<OPTION SELECTED ="selected" VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
 </div>  
 
  <p>SubResponsableExternal</p>
 <div>  
<SELECT NAME="SubResponsableExternal" SIZE=1> 
<OPTION SELECTED ="selected" VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
 </div>  
 
  <p>For2</p>
 <div> 
<SELECT NAME="For2" SIZE=1> 
<OPTION SELECTED ="selected" VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
 </div>  

 
<p>Comments</p>
<div><textarea name='Comments' rows='5' cols='60'>Description</textarea> </div>  
 
 
 <p>Link</p>
<div><input type='text' name='Link'   placeholder='Link'  required> </div>  
 
 
<div>
<button type='submit' class='btn btn-success'>Add</button>
             </div>
             </form> 
  
  
<h1>Edit</h1>

<table class="table">
<thead>
<tr class="info">
<th>Editar</th>
<th>TaskName</th> 
<th>TaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th>
<th>ExternalDeathLineDate</th>
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>For1</th> 
<th>SubResponsableExternal</th>
<th>For2</th> 
<th>Comments</th> 
<th>Link</th> 
</tr>
</thead>
<?php
include 'dat/cdb/db.php'; 
$resultado=mysqli_query($db_connection, "SELECT * FROM task t, project p WHERE p.ProjectID=t.ProjectID AND p.EmployeeID='".$_SESSION['EmployeeID']."' GROUP BY t.TaskNumber " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$TaskNumber=$row['TaskNumber'];
$ProjectID=$row['ProjectID'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$TaskName=$row['TaskName'];
$TaskType=$row['TaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$For1=$row['For1'];
$SubResponsableExternal=$row['SubResponsableExternal'];
$For2=$row['For2'];
$Comments=$row['Comments'];
$Link=$row['Link'];
 ?>
<tbody>
<?php
if($task_status=='Started')
echo '<tr class="warning">';
if($task_status=='Completed')
echo '<tr class="success">';
if($task_status=='Pending')
echo '<tr class="warning">';
if($task_status=='Not paid')
echo '<tr class="danger">';
if($task_status=='Not Started')
echo '<tr class="info">';

 ?>
<form action="task/taskupd3.php" method="POST"> 
<input type='hidden' name='TaskNumber' value='<?php echo $TaskNumber; ?>'> 
<input type='hidden' name='ProjectID' value='<?php echo $ProjectID; ?>'> 
<input type='hidden' name='SuperVisorEmployeeID' value='<?php echo $SuperVisorEmployeeID; ?>'> 
 
<td><button type='submit' class='btn btn-success'>Edit</button> </td> 

 
<td><input type='text' name='TaskName'   placeholder='TaskName' value='<?php echo $TaskName; ?>'  required> </td>  
 
<td><input type='text' name='TaskType'   placeholder='TaskType' value='<?php echo $TaskType; ?>'  required> </td>  
 
 
<td><div><select name='task_status'>
  <option value='Not Started'>Not Started</option>
  <option value='Started'>Started</option>
  <option value='Pending'>Pending</option>
  <option value='Completed'>Completed</option>
  <option value='Not paid'>Not paid</option>
<option value='<?php echo $task_status; ?>' selected><?php echo $task_status; ?></option>
</select> </div></td>   
 
<td><input type='date' name='IntroductionDate'   placeholder='IntroductionDate' value='<?php echo $IntroductionDate; ?>'  required> </td>  
 
<td><input type='date' name='startingDate'   placeholder='startingDate' value='<?php echo $startingDate; ?>'  required> </td>  
 
<td><input type='date' name='retouchDate'  class='form-control' placeholder='retouchDate' value='<?php echo $retouchDate; ?>' class='form-input' required> </td>  
 
<td><input type='TEXT' name='quantityOfRetouch'    placeholder='quantityOfRetouch' value='<?php echo $quantityOfRetouch; ?>'  required> </td>  
 
<td><input type='date' name='internalDeathLineDate'   placeholder='internalDeathLineDate' value='<?php echo $internalDeathLineDate; ?>'  required> </td>  
 
<td><input type='date' name='ExternalDeathLineDate'  placeholder='ExternalDeathLineDate' value='<?php echo $ExternalDeathLineDate; ?>'  required> </td>  
 
<td><input type='date' name='DateWaiting' placeholder='DateWaiting' value='<?php echo $DateWaiting; ?>'  required> </td> </td>  
 
<td><input type='date' name='DateFinishWork'   placeholder='DateFinishWork' value='<?php echo $DateFinishWork; ?>'  required> </td>  
 
<td>
<SELECT NAME="For1" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2=  $For1;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 

 
 <td>
<SELECT NAME="SubResponsableExternal" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2=  $SubResponsableExternal;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 
 
<td>
<SELECT NAME="For2" SIZE=1> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "dat/cdb/db.php";
$selCombo2= $For2;
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName FROM  employees ");
if (mysqli_num_rows($resulta)>0)
{       
while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
?>
<OPTION VALUE="<?php echo $EmployeeID; ?>"> <?php echo $EmployeeName; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo2) > 0){
$resulta=mysqli_query($db_connection, "SELECT EmployeeID, EmployeeName  FROM  employees  WHERE EmployeeID = '".$selCombo2."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$EmployeeID =$row['EmployeeID'];
$EmployeeName =$row['EmployeeName'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $EmployeeID; ?>"> <?php  echo $EmployeeName; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</td>  
 
<td><textarea name='Comments' rows='5' cols='60'><?php echo $Comments; ?></textarea></td>  
 
<td><input type='text' name='Link'   placeholder='Link' value='<?php echo $Link; ?>'  required> </td>   
 
</form> 
<?php } 
mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
  </tr>        
                        </tbody>
                              </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>


 <h3>Delete</h3>
<form action="task/taskdel.php" method="POST"> 
<input type='hidden' name='TaskNumber' value='<?php echo utf8_decode($_GET['TaskNumber']); ?>'> 
<input type='hidden' name='TaskNumber' value='<?php echo utf8_decode($_GET['TaskNumber']); ?>'> 
 
<div><input type='text' name='Idx' placeholder='TaskNumber' required></div>  
<div> <button type='submit' class='btn btn-success'>Delete</button> </div> 
</form> 

               </div>
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
