<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="dat/css/style.css">
   <link rel="stylesheet" type="text/css" href="dat/css/login.css">

</head>
<body>
<div class="login">
<div class="loginbox">
<h1>EMAIL HERE</h1>
<form action="pforget.php" method="POST">
 <p>Email</p> 
 <input type="text" name="cor" placeholder="Enter Email">
 
  <a href="index.php">Back</a><br>

 <input type="submit" name="" value="Login">
 
 </form>
</div>
</div>
<script src="dat/js/script.js"></script>

</body>
</html>