<?php 
include '../dat/cdb/db.php'; 


$SubTaskNumber= $_REQUEST['SubTaskNumber'];
$TaskNumber= $_REQUEST['TaskNumber'];
$SuperVisorEmployeeID= $_REQUEST['SuperVisorEmployeeID'];
$SubTaskName= $_REQUEST['SubTaskName'];
$SubTaskType= $_REQUEST['SubTaskType'];
$task_status= $_REQUEST['task_status'];
$IntroductionDate= $_REQUEST['IntroductionDate'];
$startingDate= $_REQUEST['startingDate'];
$retouchDate= $_REQUEST['retouchDate'];
$quantityOfRetouch= $_REQUEST['quantityOfRetouch'];
$internalDeathLineDate= $_REQUEST['internalDeathLineDate'];
$ExternalDeathLineDate= $_REQUEST['ExternalDeathLineDate'];
$DateWaiting= $_REQUEST['DateWaiting'];
$DateFinishWork= $_REQUEST['DateFinishWork'];
$Comments= $_REQUEST['Comments'];
$Link= $_REQUEST['Link'];
$For1= $_REQUEST['For1'];
$For2= $_REQUEST['For2'];
$SubResponsableExternal= $_REQUEST['SubResponsableExternal'];
$Idx= $_REQUEST['Idx'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT SubTaskNumber FROM subtask WHERE SubTaskNumber ='".$Idx."'" );  
if (mysqli_num_rows($resultado)>0) {
$delete_value ="DELETE FROM subtask WHERE SubTaskNumber = '".$Idx."'";  
$retry_value = mysqli_query($db_connection,$delete_value);
 header("Location: ../tables.php"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../tables.php"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>