<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="dat/css/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript" src="dat/js/tablecloth.js"></script>
        <title>subtask</title> 
<style>
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style> 
  
 
<?php
include '../dat/cdb/db.php'; 
$SubTaskNumber= utf8_decode($_GET['SubTaskNumber']); 
$SubTaskNumber = utf8_decode($_GET['SubTaskNumber']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM subtask WHERE SubTaskNumber = '".$SubTaskNumber."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$SubTaskNumber=$row['SubTaskNumber'];
$TaskNumber=$row['TaskNumber'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$SubTaskName=$row['SubTaskName'];
$SubTaskType=$row['SubTaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$Comments=$row['Comments'];
$Link=$row['Link'];
$For1=$row['For1'];
$For2=$row['For2'];
$SubResponsableExternal=$row['SubResponsableExternal'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

        <div> <h2>subtask</h2> </div> 
 
<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr><th>SubTaskNumber</th> 
<th>TaskNumber</th> 
<th>SuperVisorEmployeeID</th> 
<th>SubTaskName</th> 
<th>SubTaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th> 
<th>ExternalDeathLineDate</th> 
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>Comments</th> 
<th>Link</th> 
<th>For1</th> 
<th>For2</th> 
<th>SubResponsableExternal</th> 

<?php
include '../dat/cdb/db.php'; 
$TaskNumber= utf8_decode($_GET['TaskNumber']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM subtask " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$SubTaskNumber=$row['SubTaskNumber'];
$TaskNumber=$row['TaskNumber'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$SubTaskName=$row['SubTaskName'];
$SubTaskType=$row['SubTaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$Comments=$row['Comments'];
$Link=$row['Link'];
$For1=$row['For1'];
$For2=$row['For2'];
$SubResponsableExternal=$row['SubResponsableExternal'];
 ?>
</tr><tr><td><?php echo $SubTaskNumber; ?></td> 
<td><?php echo $TaskNumber; ?></td> 
<td><?php echo $SuperVisorEmployeeID; ?></td> 
<td><?php echo $SubTaskName; ?></td> 
<td><?php echo $SubTaskType; ?></td> 
<td><?php echo $task_status; ?></td> 
<td><?php echo $IntroductionDate; ?></td> 
<td><?php echo $startingDate; ?></td> 
<td><?php echo $retouchDate; ?></td> 
<td><?php echo $quantityOfRetouch; ?></td> 
<td><?php echo $internalDeathLineDate; ?></td> 
<td><?php echo $ExternalDeathLineDate; ?></td> 
<td><?php echo $DateWaiting; ?></td> 
<td><?php echo $DateFinishWork; ?></td> 
<td><?php echo $Comments; ?></td> 
<td><?php echo $Link; ?></td> 
<td><?php echo $For1; ?></td> 
<td><?php echo $For2; ?></td> 
<td><?php echo $SubResponsableExternal; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th><th>SubTaskNumber</th> 
<th>TaskNumber</th> 
<th>SuperVisorEmployeeID</th> 
<th>SubTaskName</th> 
<th>SubTaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th> 
<th>ExternalDeathLineDate</th> 
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>Comments</th> 
<th>Link</th> 
<th>For1</th> 
<th>For2</th> 
<th>SubResponsableExternal</th> 

<?php
include '../dat/cdb/db.php'; 
$TaskNumber= utf8_decode($_GET['TaskNumber']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM subtask " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$SubTaskNumber=$row['SubTaskNumber'];
$TaskNumber=$row['TaskNumber'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$SubTaskName=$row['SubTaskName'];
$SubTaskType=$row['SubTaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$Comments=$row['Comments'];
$Link=$row['Link'];
$For1=$row['For1'];
$For2=$row['For2'];
$SubResponsableExternal=$row['SubResponsableExternal'];
 ?>
</tr><tr><tr><form action="subtaskupd3.php" method="POST"> 
<input type='hidden' name='SubTaskNumber' value='<?php echo utf8_decode($_GET['SubTaskNumber']); ?>'> 
<input type='hidden' name='SubTaskNumber' value='<?php echo utf8_decode($_GET['SubTaskNumber']); ?>'> 
 
<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td> 
<td><div><input type='number' name='SubTaskNumber'  class='form-control' placeholder='SubTaskNumber' value='<?php echo $SubTaskNumber; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='TaskNumber'  class='form-control' placeholder='TaskNumber' value='<?php echo $TaskNumber; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='SuperVisorEmployeeID'  class='form-control' placeholder='SuperVisorEmployeeID' value='<?php echo $SuperVisorEmployeeID; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='SubTaskName'  class='form-control' placeholder='SubTaskName' value='<?php echo $SubTaskName; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='SubTaskType'  class='form-control' placeholder='SubTaskType' value='<?php echo $SubTaskType; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='task_status'  class='form-control' placeholder='task_status' value='<?php echo $task_status; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='IntroductionDate'  class='form-control' placeholder='IntroductionDate' value='<?php echo $IntroductionDate; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='startingDate'  class='form-control' placeholder='startingDate' value='<?php echo $startingDate; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='retouchDate'  class='form-control' placeholder='retouchDate' value='<?php echo $retouchDate; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='TEXT' name='quantityOfRetouch'   class='form-control' placeholder='quantityOfRetouch' value='<?php echo $quantityOfRetouch; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='internalDeathLineDate'  class='form-control' placeholder='internalDeathLineDate' value='<?php echo $internalDeathLineDate; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='ExternalDeathLineDate'  class='form-control' placeholder='ExternalDeathLineDate' value='<?php echo $ExternalDeathLineDate; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='DateWaiting'  class='form-control' placeholder='DateWaiting' value='<?php echo $DateWaiting; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='date' name='DateFinishWork'  class='form-control' placeholder='DateFinishWork' value='<?php echo $DateFinishWork; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Comments'  class='form-control' placeholder='Comments' value='<?php echo $Comments; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Link'  class='form-control' placeholder='Link' value='<?php echo $Link; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='For1'  class='form-control' placeholder='For1' value='<?php echo $For1; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='For2'  class='form-control' placeholder='For2' value='<?php echo $For2; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='SubResponsableExternal'  class='form-control' placeholder='SubResponsableExternal' value='<?php echo $SubResponsableExternal; ?>' class='form-input' required> </div></td>  
 
</form> 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th><th>SubTaskNumber</th> 
<th>TaskNumber</th> 
<th>SuperVisorEmployeeID</th> 
<th>SubTaskName</th> 
<th>SubTaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th> 
<th>ExternalDeathLineDate</th> 
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>Comments</th> 
<th>Link</th> 
<th>For1</th> 
<th>For2</th> 
<th>SubResponsableExternal</th> 

<?php
include '../dat/cdb/db.php'; 
$TaskNumber= utf8_decode($_GET['TaskNumber']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM subtask " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$SubTaskNumber=$row['SubTaskNumber'];
$TaskNumber=$row['TaskNumber'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$SubTaskName=$row['SubTaskName'];
$SubTaskType=$row['SubTaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$Comments=$row['Comments'];
$Link=$row['Link'];
$For1=$row['For1'];
$For2=$row['For2'];
$SubResponsableExternal=$row['SubResponsableExternal'];
 ?>
</tr><tr><td><a href=subtaskupd2.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>><?php echo $SubTaskNumber; ?> actualizar</a></td><td><?php echo $SubTaskNumber; ?></td> 
<td><?php echo $TaskNumber; ?></td> 
<td><?php echo $SuperVisorEmployeeID; ?></td> 
<td><?php echo $SubTaskName; ?></td> 
<td><?php echo $SubTaskType; ?></td> 
<td><?php echo $task_status; ?></td> 
<td><?php echo $IntroductionDate; ?></td> 
<td><?php echo $startingDate; ?></td> 
<td><?php echo $retouchDate; ?></td> 
<td><?php echo $quantityOfRetouch; ?></td> 
<td><?php echo $internalDeathLineDate; ?></td> 
<td><?php echo $ExternalDeathLineDate; ?></td> 
<td><?php echo $DateWaiting; ?></td> 
<td><?php echo $DateFinishWork; ?></td> 
<td><?php echo $Comments; ?></td> 
<td><?php echo $Link; ?></td> 
<td><?php echo $For1; ?></td> 
<td><?php echo $For2; ?></td> 
<td><?php echo $SubResponsableExternal; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br> 
 
<a href="../usuarios.php?SubTaskNumber='".$SubTaskNumber."'&SubTaskNumber='".$SubTaskNumber."'">Regresar</a>
"<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th><th>SubTaskNumber</th> 
<th>TaskNumber</th> 
<th>SuperVisorEmployeeID</th> 
<th>SubTaskName</th> 
<th>SubTaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th> 
<th>ExternalDeathLineDate</th> 
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>Comments</th> 
<th>Link</th> 
<th>For1</th> 
<th>For2</th> 
<th>SubResponsableExternal</th> 

<?php
include '../dat/cdb/db.php'; 
$TaskNumber= utf8_decode($_GET['TaskNumber']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM subtask " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$SubTaskNumber=$row['SubTaskNumber'];
$TaskNumber=$row['TaskNumber'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$SubTaskName=$row['SubTaskName'];
$SubTaskType=$row['SubTaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$Comments=$row['Comments'];
$Link=$row['Link'];
$For1=$row['For1'];
$For2=$row['For2'];
$SubResponsableExternal=$row['SubResponsableExternal'];
 ?>
</tr><tr><td><a href=subtaskdel2.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>><?php echo $SubTaskNumber; ?> borrar</a></td><td><?php echo $SubTaskNumber; ?></td> 
<td><?php echo $TaskNumber; ?></td> 
<td><?php echo $SuperVisorEmployeeID; ?></td> 
<td><?php echo $SubTaskName; ?></td> 
<td><?php echo $SubTaskType; ?></td> 
<td><?php echo $task_status; ?></td> 
<td><?php echo $IntroductionDate; ?></td> 
<td><?php echo $startingDate; ?></td> 
<td><?php echo $retouchDate; ?></td> 
<td><?php echo $quantityOfRetouch; ?></td> 
<td><?php echo $internalDeathLineDate; ?></td> 
<td><?php echo $ExternalDeathLineDate; ?></td> 
<td><?php echo $DateWaiting; ?></td> 
<td><?php echo $DateFinishWork; ?></td> 
<td><?php echo $Comments; ?></td> 
<td><?php echo $Link; ?></td> 
<td><?php echo $For1; ?></td> 
<td><?php echo $For2; ?></td> 
<td><?php echo $SubResponsableExternal; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
