<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>subtask</title> 
  

<?php
include 'db.php'; 
$TaskNumber= utf8_decode($_GET['TaskNumber']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM subtask WHERE TaskNumber LIKE '".$TaskNumber."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$SubTaskNumber=$row['SubTaskNumber'];
$TaskNumber=$row['TaskNumber'];
$SuperVisorEmployeeID=$row['SuperVisorEmployeeID'];
$SubTaskName=$row['SubTaskName'];
$SubTaskType=$row['SubTaskType'];
$task_status=$row['task_status'];
$IntroductionDate=$row['IntroductionDate'];
$startingDate=$row['startingDate'];
$retouchDate=$row['retouchDate'];
$quantityOfRetouch=$row['quantityOfRetouch'];
$internalDeathLineDate=$row['internalDeathLineDate'];
$ExternalDeathLineDate=$row['ExternalDeathLineDate'];
$DateWaiting=$row['DateWaiting'];
$DateFinishWork=$row['DateFinishWork'];
$Comments=$row['Comments'];
$Link=$row['Link'];
$For1=$row['For1'];
$For2=$row['For2'];
$SubResponsableExternal=$row['SubResponsableExternal'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.subtask.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=19 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>SubTaskNumber</th> 
<th>TaskNumber</th> 
<th>SuperVisorEmployeeID</th> 
<th>SubTaskName</th> 
<th>SubTaskType</th> 
<th>task_status</th> 
<th>IntroductionDate</th> 
<th>startingDate</th> 
<th>retouchDate</th> 
<th>quantityOfRetouch</th> 
<th>internalDeathLineDate</th> 
<th>ExternalDeathLineDate</th> 
<th>DateWaiting</th> 
<th>DateFinishWork</th> 
<th>Comments</th> 
<th>Link</th> 
<th>For1</th> 
<th>For2</th> 
<th>SubResponsableExternal</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $SubTaskNumber; ?></th> 
<th><?php echo $TaskNumber; ?></th> 
<th><?php echo $SuperVisorEmployeeID; ?></th> 
<th><?php echo $SubTaskName; ?></th> 
<th><?php echo $SubTaskType; ?></th> 
<th><?php echo $task_status; ?></th> 
<th><?php echo $IntroductionDate; ?></th> 
<th><?php echo $startingDate; ?></th> 
<th><?php echo $retouchDate; ?></th> 
<th><?php echo $quantityOfRetouch; ?></th> 
<th><?php echo $internalDeathLineDate; ?></th> 
<th><?php echo $ExternalDeathLineDate; ?></th> 
<th><?php echo $DateWaiting; ?></th> 
<th><?php echo $DateFinishWork; ?></th> 
<th><?php echo $Comments; ?></th> 
<th><?php echo $Link; ?></th> 
<th><?php echo $For1; ?></th> 
<th><?php echo $For2; ?></th> 
<th><?php echo $SubResponsableExternal; ?></th> 
</tr></table></br></br> 
 
<a href="../usuarios.php?SubTaskNumber=<?php echo $SubTaskNumber; ?>&SubTaskNumber=<?php echo $SubTaskNumber; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
</body> </html>