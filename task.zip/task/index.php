<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="dat/css/style.css">
   <link rel="stylesheet" type="text/css" href="dat/css/login.css">

</head>
<body>
<div class="login">
<div class="loginbox">
<h1>LOGIN HERE</h1>
<form action="psesion.php" method="POST">
 <p>Username</p> 
 <input type="text" name="cor" placeholder="Enter Username">
 <p>Password</p>
 <input type="password" name="pas" placeholder="Enter Password">
  <a href="forget.php">Forget Password?</a><br>

 <input type="submit" name="" value="Login">
 
 </form>
</div>
</div>
<script src="dat/js/script.js"></script>

</body>
</html>