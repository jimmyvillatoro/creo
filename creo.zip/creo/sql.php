<?php
include 'db.php';

$y1 = $_REQUEST['y1'];
$y2 = $_REQUEST['y2'];
$y3 = $_REQUEST['y3'];



$result=mysqli_query($db_connection, "SELECT text FROM bible_rv60 WHERE book='".$y1."' && chapter='".$y2."' && verse='".$y3."' ");
 
if (mysqli_num_rows($result)>0)
while($row = mysqli_fetch_array($result))
{			
$x1=$row[text];
}


               
               if($y1==1)$y1="Génesis";if($y1==2)$y1="Éxodo";if($y1==3)$y1="Levítico";if($y1==4)$y1="Números";if($y1==5)$y1="Deuteronomio";
               if($y1==6)$y1="Josué";if($y1==7)$y1="Jueces";if($y1==8)$y1="Rut";if($y1==9)$y1="1 Samuel";if($y1==10)$y1="2 Samuel";
               if($y1==11)$y1="1 Reyes";if($y1==12)$y1="2 Reyes";if($y1==13)$y1="1 Crónicas";if($y1==14)$y1="2 Crónicas";if($y1==15)$y1="Esdras";
               if($y1==16)$y1="Nehemías";if($y1==17)$y1="Ester";if($y1==18)$y1="Job";if($y1==19)$y1="Salmos";if($y1==20)$y1="Proverbios.";
               if($y1==21)$y1="Eclesiastés";if($y1==22)$y1="Cantares";if($y1==23)$y1="Isaías";if($y1==24)$y1="Jeremías";if($y1==25)$y1="Lamentaciones";
               if($y1==26)$y1="Ezequiel";if($y1==27)$y1="Daniel";if($y1==28)$y1="Oseas";if($y1==29)$y1="Joel";if($y1==30)$y1="Amós";
               if($y1==31)$y1="Abdías";if($y1==32)$y1="Jonás";if($y1==33)$y1="Miqueas";if($y1==34)$y1="Nahúm";if($y1==35)$y1="Habacuc";
               if($y1==36)$y1="Sofonías";if($y1==37)$y1="Hageo";if($y1==38)$y1="Zacarías";if($y1==39)$y1="Malaquías";
               
               if($y1==40)$y1="San Mateo";if($y1==41)$y1="San Marcos";if($y1==42)$y1="San Lucas";if($y1==43)$y1="San Juan";if($y1==44)$y1="Hechos";
               if($y1==45)$y1="Romanos";if($y1==46)$y1="1 Corintios";if($y1==47)$y1="2 Corintios";if($y1==48)$y1="Gálatas";if($y1==49)$y1="Efesios";
               if($y1==50)$y1="Filipenses";if($y1==51)$y1="Colosenses";if($y1==52)$y1="1 Tesalonicenses";if($y1==53)$y1="2 Tesalonicenses";if($y1==54)$y1="1 Timoteo"; 
               if($y1==55)$y1="2 Timoteo";if($y1==56)$y1="Tito";if($y1==57)$y1="Filemón";if($y1==58)$y1="Hebreos";if($y1==59)$y1="Santiago";
               if($y1==60)$y1="1 Pedro";if($y1==61)$y1="2 Pedro";if($y1==62)$y1="1 Juan";if($y1==63)$y1="2 Juan";if($y1==64)$y1="3 Juan"; 
               if($y1==65)$y1="Judas";if($y1==66)$y1="Apocalipsis";

echo  "<font size='5' color='Red'><a style='background-color:#FFFF00'>"." ".$y1." ".$y2." : ".$y3." "." </a></font><br /><br />";
echo " "."<font size='5' color='Black'><a style='background-color:#CCFF8E'>".$x1."</a></font>";


mysqli_free_result($result);
mysqli_close($db_connection);
?>
