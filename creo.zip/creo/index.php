<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang='es'>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>DeepBible</title>
<meta name="description" content="Traiga la belleza y la verdad de la Biblia a su vida diaria. Con la Biblia App de DeepBible, puede leer, observar, escuchar y compartir en su teléfono inteligente o tableta, y en línea en creo.yaprendo.com" />
<meta content='https://www.creo.yaprendo.com/' name='url'>
<meta content='Leer la Biblia. La Biblia gratis para su teléfono, tableta, y computadora.' property='og:title'>
<meta content='https://www.creo.yaprendo.com/' property='og:url'>
<meta content='Lea la Palabra de Dios en cualquier momento y en cualquier lugar usando DeepBible App. Comparta las Escrituras con amigos, Resalte y Marque los pasajes para su vida, y cree un hábito diario con los Planes Bíblicos. Disponible para Android.' property='og:description'>

<link  rel="icon"   href="biblia1960.png" type="image/png" />
<link href="styles.css" rel="stylesheet" type="text/css" />

<script>
function ventanaSecundaria (URL){ 
   window.open(URL,"ventana1","width=120,height=300,scrollbars=NO") 
} 
</script>

</head>
<body>


<div id="bg2">

<div id="bg3">
<!-- header begins -->
<div id="header">
	 <div id="buttons">
      <a href="index.php" class="but"  title="">Inicio</a>
      <a href="https://creo.yaprendo.com/red" class="but"  title="DeebBible red de investigación bíblica" target="_blank">RED</a>
      <a href="http://yaprendo.com/about_us.html"  class="but" title="" target="_blank" >Acerca de</a>
      <a href="http://yaprendo.com/contact_us.html" class="but" title="" target="_blank" >Contactanos</a>
    </div>
 

	<div id="logo"><a href="#">DeepBible la bíblia rv1960</a>
      <h2><a href="#" id="metamorph">Consulta profunda</a></h2>
    </div>
   
</div>
<!-- header ends -->
        <!-- content begins -->
       	<div id="content">
            <div id="main">
                <div id="main_bot">
                    <div id="main_top">
                    <div id="right">
                   	  <h1 class="tit_right1">Categorias</h1>	
                        <div class="right_b">
                            <div class="munth"><a href="#" >Biblia rv1960</a></div>
                          	<div class="munth"><a href="#" >Concordancia</a></div>
                          	<div class="munth"><a href="#" >Diccionario</a></div>
                          	<div class="munth"><a href="#" >Geografia</a></div>
                          	<div class="munth"><a href="#" >Gramatica</a></div>
                          	<div class="munth"><a href="#" >Significados</a></div>
                          	<div class="munth"><a href="#" >Otros</a></div>
                          	
           	  		  </div>
                        <h1 class="tit_right2">Archivos</h1>	
                    	<div class="right_w fish_10">
                            <div class="munth"><a href="#" >Agosto  2020</a></div>
                          	
               	  	  </div>
                    	
                        
                    </div>
                    <div id="left">
                   	   <h1>Descripción</h1>
                      <div class="box1">
                        <div class="left_b"><span class="w">Bíblia, Reyna Valera 1960</span><br />
                                   La Palabra de Dios original, conforme esta escrita en la bíblia.
                                    <div style="height:20px;"><a class="read_l" href="app/DeepBiblia.apk">Descargar version Android del 5 - 9 </a></div>
                                  	<div style="height:20px;"><a class="read_l" href="app/DeepBiblia2.apk">Descargar version Android 10+ </a></div>

                        </div>
                       </div>
                       <div class="box2">
                           <div class="left_b"><span class="w">Concordancia, profunda.</span><br />
                                   Algoritmo de análisis de concordancias por palabras encontradas en toda la biblia y todos los versículos.
                                <div class="read"><a href="#"> ver más</a></div>
                         </div>
                       </div>
                       <div class="box3">
                           <div class="left_b"><span class="w">Diccionario, Biblico.</span><br />
                                   Definición biblica, por palabra del versiculo consultado, relacionado al algoritmo de busqueda profunda.
                                <div class="read"><a href="#"> ver más</a></div>
                         </div>
                       </div>
                      <div class="box4">
                          <div class="left_b"><span class="w">Estudio, Gramatical.</span><br />
                                  Decodificación gramatical del versículo consultado, en el análisis profundo, según la real academia de la letra española
                                <div class="read"><a href="#"> ver más</a></div>
                        </div>
                       </div>
                      </div>


 <div id="center">
<h1>Concordancia, profunda.</h1>

<form action="index.php" method="POST">

<div class="container">
   
                <table>
                    <tr>
                        <td>Libro</td>
                        <td>Capítulo</td>
                        <td>Versículo</td>
                    </tr>
                    <tr> 

<td style="background-color:#FFAC33"> <select name="select1">
  <option value="1" selected>Génesis</option> 
  <option value="2" >Éxodo</option>
  <option value="3">Levítico</option>
  <option value="4">Números</option>
  <option value="5">Deuteronomio</option>
  <option value="6">Josué</option>
  <option value="7">Jueces</option>
  <option value="8">Rut</option>
  <option value="9">1 Samuel</option>
  <option value="10">2 Samuel</option>
  <option value="11">1 Reyes</option>
  <option value="12">2 Reyes</option>
  <option value="13">1 Crónicas</option>
  <option value="14">2 Crónicas</option>
  <option value="15">Esdras</option>
  <option value="16">Nehemías</option>
  <option value="17">Ester</option>
  <option value="18">Job</option>
  <option value="19">Salmos</option>
  <option value="20">Proverbios</option>
  <option value="21">Eclesiastés</option>
  <option value="22">Cantares</option>
  <option value="23">Isaías</option>
  <option value="24">Jeremías</option>
  <option value="25">Lamentaciones</option>
  <option value="26">Ezequiel</option>
  <option value="27">Daniel</option>
  <option value="28">Oseas</option>
  <option value="29">Joel</option>
  <option value="30">Amós</option>
  <option value="31">Abdías</option>
  <option value="32">Jonás</option>
  <option value="33">Miqueas</option>
  <option value="34">Nahúm</option>
  <option value="35">Habacuc</option>
  <option value="36">Sofonías</option>
  <option value="37">Hageo</option>
  <option value="38">Zacarías</option>
  <option value="39">Malaquías</option>
  <option value="40">San Mateo</option>
  <option value="41">San Marcos</option>
  <option value="42">San Lucas</option>
  <option value="43">San Juan</option>
  <option value="44">Hechos</option>
  <option value="45">Romanos</option>
  <option value="46">1 Corintios</option>
  <option value="47">2 Corintios</option>
  <option value="48">Gálatas</option>
  <option value="49">Efesios</option>
  <option value="50">Filipenses</option>
  <option value="51">Colosenses</option>
  <option value="52">1 Tesalonicenses</option>
  <option value="53">2 Tesalonicenses</option>
  <option value="54">1 Timoteo</option>
  <option value="55">2 Timoteo</option>
  <option value="56">Tito</option>
  <option value="57">Filemón</option>
  <option value="58">Hebreos</option>
  <option value="59">Santiago</option>
  <option value="60">1 Pedro</option>
  <option value="61">2 Pedro</option>
  <option value="62">1 Juan</option>
  <option value="63">2 Juan</option>
  <option value="64">3 Juan</option>
  <option value="65">Judas</option>
  <option value="66">Apocalipsis</option>
  </select></td>
  
<td style="background-color:#FFAC33"><input type="text" size="5" style="background-color:#FFAC33" name="cap" class="form-control" class="form-input"  required></td> 
<td style="background-color:#FFAC33"><input type="text" size="5" style="background-color:#FFAC33" name="ver" class="form-control" class="form-input"  required></td>
<td><button type="submit">Buscar</button></td>

                        </tr>
                </table>



<?php

include 'db.php';

$bibliar_b= $_REQUEST['select1'];
$bibliar_c= $_REQUEST['cap'];
$bibliar_v= $_REQUEST['ver'];
$result=mysqli_query($db_connection, "SELECT book, chapter, verse, text FROM bible_rv60 WHERE book='".$bibliar_b."' && chapter='".$bibliar_c."' && verse='".$bibliar_v."' ");
 
if (mysqli_num_rows($result)>0)
while($row = mysqli_fetch_array($result))
{			
//=set_time_limit(5);
$x1=$row[book];
$x2=$row[chapter];
$x3=$row[verse];
$x=$row[text];

               $y1=$x1;
               if($y1==1)$y1="Gn.";if($y1==2)$y1="Ex.";if($y1==3)$y1="Lv.";if($y1==4)$y1="Nm.";if($y1==5)$y1="Dt.";
               if($y1==6)$y1="Jos.";if($y1==7)$y1="Jue.";if($y1==8)$y1="Rut.";if($y1==9)$y1="1 Sam.";if($y1==10)$y1="2 Sam.";
               if($y1==11)$y1="1 Re.";if($y1==12)$y1="2 Re.";if($y1==13)$y1="1 Cr.";if($y1==14)$y1="2 Cr.";if($y1==15)$y1="Esd.";
               if($y1==16)$y1="Ne.";if($y1==17)$y1="Est.";if($y1==18)$y1="Job.";if($y1==19)$y1="Sl.";if($y1==20)$y1="Pr.";
               if($y1==21)$y1="Ecl.";if($y1==22)$y1="Ct.";if($y1==23)$y1="Is.";if($y1==24)$y1="Jr.";if($y1==25)$y1="Lm.";
               if($y1==26)$y1="Ez.";if($y1==27)$y1="Dn.";if($y1==28)$y1="Os.";if($y1==29)$y1="Jl.";if($y1==30)$y1="Am.";
               if($y1==31)$y1="Ab.";if($y1==32)$y1="Jon.";if($y1==33)$y1="Mi.";if($y1==34)$y1="Na.";if($y1==35)$y1="Ha.";
               if($y1==36)$y1="So.";if($y1==37)$y1="Ag.";if($y1==38)$y1="Za.";if($y1==39)$y1="Ml.";
               
               if($y1==40)$y1="Mt.";if($y1==41)$y1="Mc.";if($y1==42)$y1="Lc.";if($y1==43)$y1="Jn.";if($y1==44)$y1="He.";
               if($y1==45)$y1="Ro.";if($y1==46)$y1="1 Cor.";if($y1==47)$y1="2 Cor.";if($y1==48)$y1="Ga.";if($y1==49)$y1="Ef.";
               if($y1==50)$y1="Flp.";if($y1==51)$y1="Col.";if($y1==52)$y1="1 Te.";if($y1==53)$y1="2 Te.";if($y1==54)$y1="1 Tim."; 
               if($y1==55)$y1="2 Tim.";if($y1==56)$y1="Tit.";if($y1==57)$y1="Flm.";if($y1==58)$y1="Heb.";if($y1==59)$y1="Sant.";
               if($y1==60)$y1="1 Pe.";if($y1==61)$y1="2 Pe.";if($y1==62)$y1="1 Jn.";if($y1==63)$y1="2 Jn.";if($y1==64)$y1="3 Jn."; 
               if($y1==65)$y1="Jds.";if($y1==66)$y1="Ap."; 
      
      
      echo  "<br />";  
      echo  "<h2> ".$y1." ".$x2." : ".$x3." </h2>"; 
      
echo "<br /><font size='4' color='Black'>  ".$x."</td>"."</font><br />";
   
      echo  "<br />";  
      echo  "<a style='background-color:#FFFC33'>Nota1: Da clic en el número que aparece en cada palabra para ver su concordancia.</a>"; 
      echo  "<br />";
      echo  "<br />";
      $token = strtok($x," \n\t"); // Primer token 
 $num=0;
        while($token !== false)
        {
        echo "<font size='3' color='Black'> ".$token."</font>";
        
                             $p = substr($token, -1);
                            if($p === ',' || $p === '.' || $p === ':' || $p === ';' || $p === ')' || $p === '?' || $p === '!' )
                            $token = substr($token, 0, -1);
  
                                 $r=substr($token, 0, 2);


                            if($r === ',' || $r === '.' || $r === ':' || $r === ';' || $r === '(' || $r === '¡' || $r === '¿')
                            $token= substr($token, 2);

                            $token=strtolower($token);
        
        $result1=mysqli_query($db_connection, "SELECT COUNT(book) num FROM Concordancia WHERE word='".$token."' ORDER BY book ");
 
        if (mysqli_num_rows($result1)>0)
            while($row1 = mysqli_fetch_array($result1))
               $y4=$row1[num];
          $num=$y4+$num;
            echo  "<font size='2' ><a   class='left_a' href='index.php?t=".$token."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."'>"."(".$y4.")"."</a></font>";
          
            $token = strtok(" \n\t");
        }
        echo  "<br /><br /><font size='2' color='Black'>Número: </font>"."<font size='3' color='Blue'>".$num."</font>"."<font size='2' color='Black'> veces.</font>";
  


}//mientras hay registros
      echo  "<br />";
      echo  "<br />";
  echo  "<br />";  
      echo  "<a style='background-color:#FFFC33'>Nota2: Da clic en la referencia que aparece para ver el versículo en una ventana flotante.</a>"; 
      echo  "<br />";
      echo  "<br />";
$t= $_GET['t'];
 echo "Referencias de la palabra: "."<font size='4' color='Red'>".$t."</font><br /><br />";
        $result2=mysqli_query($db_connection, "SELECT book, chapter, verse FROM Concordancia WHERE word='".$t."' ORDER BY book ");
 
        if (mysqli_num_rows($result1)>0)
            while($row2 = mysqli_fetch_array($result2))
            {
               $y1=$row2[book];
               $y2=$row2[chapter];
               $y3=$row2[verse];
               
               $l=$y1;
               
               if($y1==1)$y1="Gn.";if($y1==2)$y1="Ex.";if($y1==3)$y1="Lv.";if($y1==4)$y1="Nm.";if($y1==5)$y1="Dt.";
               if($y1==6)$y1="Jos.";if($y1==7)$y1="Jue.";if($y1==8)$y1="Rut.";if($y1==9)$y1="1 Sam.";if($y1==10)$y1="2 Sam.";
               if($y1==11)$y1="1 Re.";if($y1==12)$y1="2 Re.";if($y1==13)$y1="1 Cr.";if($y1==14)$y1="2 Cr.";if($y1==15)$y1="Esd.";
               if($y1==16)$y1="Ne.";if($y1==17)$y1="Est.";if($y1==18)$y1="Job.";if($y1==19)$y1="Sl.";if($y1==20)$y1="Pr.";
               if($y1==21)$y1="Ecl.";if($y1==22)$y1="Ct.";if($y1==23)$y1="Is.";if($y1==24)$y1="Jr.";if($y1==25)$y1="Lm.";
               if($y1==26)$y1="Ez.";if($y1==27)$y1="Dn.";if($y1==28)$y1="Os.";if($y1==29)$y1="Jl.";if($y1==30)$y1="Am.";
               if($y1==31)$y1="Ab.";if($y1==32)$y1="Jon.";if($y1==33)$y1="Mi.";if($y1==34)$y1="Na.";if($y1==35)$y1="Ha.";
               if($y1==36)$y1="So.";if($y1==37)$y1="Ag.";if($y1==38)$y1="Za.";if($y1==39)$y1="Ml.";
               
               if($y1==40)$y1="Mt.";if($y1==41)$y1="Mc.";if($y1==42)$y1="Lc.";if($y1==43)$y1="Jn.";if($y1==44)$y1="He.";
               if($y1==45)$y1="Ro.";if($y1==46)$y1="1 Cor.";if($y1==47)$y1="2 Cor.";if($y1==48)$y1="Ga.";if($y1==49)$y1="Ef.";
               if($y1==50)$y1="Flp.";if($y1==51)$y1="Col.";if($y1==52)$y1="1 Te.";if($y1==53)$y1="2 Te.";if($y1==54)$y1="1 Tim."; 
               if($y1==55)$y1="2 Tim.";if($y1==56)$y1="Tit.";if($y1==57)$y1="Flm.";if($y1==58)$y1="Heb.";if($y1==59)$y1="Sant.";
               if($y1==60)$y1="1 Pe.";if($y1==61)$y1="2 Pe.";if($y1==62)$y1="1 Jn.";if($y1==63)$y1="2 Jn.";if($y1==64)$y1="3 Jn."; 
               if($y1==65)$y1="Jds.";if($y1==66)$y1="Ap.";
               
             
                if($l>=1 && $l<=5)
                echo  "<font size='3'><a style='background-color:#ECCD04' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                
                if($l>=6 && $l<=16)
                echo  "<font size='3'><a style='background-color:#7AC6FA' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                
                if($l>=17 && $l<=18)
                echo  "<font size='3'><a style='background-color:#FFB394' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                
                if($l>=19 && $l<=22)
                echo  "<font size='3'><a style='background-color:#FF94D5' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                
                if($l>=23 && $l<=27)
                echo  "<font size='3'><a style='background-color:#7360FF' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                
                if($l>=28 && $l<=39)
                echo  "<font size='3'><a style='background-color:#9C8EFF' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                
                
                
                if( $l==40 )
                echo  "<font size='3'><a style='background-color:#FFFB2C' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                if( $l==41 )
                echo  "<font size='3'><a style='background-color:#FFFB2C' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                if( $l==42 )
                echo  "<font size='3'><a style='background-color:#FFFB2C' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3.""."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                if( $l==43 )
                echo  "<font size='3'><a style='background-color:#FFFB2C' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                
               if($l==44)
                echo  "<font size='3'><a style='background-color:#CCFF8E' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                
               if($l>=45 && $l<=58)
                echo  "<font size='3'><a style='background-color:#E58EFF' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>"; 
                if($l>=59 && $l<=65)
                echo  "<font size='3'><a style='background-color:#55FFF2' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
                if($l==66)
                echo  "<font size='3'><a style='background-color:#FFB255' href=javascript:ventanaSecundaria('sql.php?y1=".$l."&y2=".$y2."&y3=".$y3."&t=".$t."&select1=".$bibliar_b."&cap=".$bibliar_c."&ver=".$bibliar_v."')>"." ".$y1." ".$y2." : ".$y3." "."</a></font><font size='3' color='White'><a style='background-color:#FFFFFF'>-</a></font>";
             
            }
mysqli_free_result($result2);         
mysqli_free_result($result1);
mysqli_free_result($result);
mysqli_close($db_connection);
?>
</form>
 <br /> 
                      	</div>
                         <div class="text">
                        
                         he desarrollado un algoritmo que separa cada palabra de cada versiculo de la biblia, y almacene todas las palabras sin repetir a una tabla resultando que son 25418 de cada una de estas palabras cree una tabla relacionada de concordancias, donde almacene cada palabra que se repite y son 705512, señale en que parte de la biblia se encuentra dando como resultado una concordancia profunda. <br />
                   	  	 </div>

         
                   	  	
   <div id="center">
                      <h1>Estudio, Gramatical.</h1>



<div class="container">


<?php
include 'db.php';
$bibliar_b= $_REQUEST['select1'];
$bibliar_c= $_REQUEST['cap'];
$bibliar_v= $_REQUEST['ver'];

function eliminar_tildes($cadena){

    $cadena = str_replace(array('á', 'à', 'ä', 'â', 'ª', 'Á', 'À', 'Â', 'Ä'), array('a', 'a', 'a', 'a', 'a', 'A', 'A', 'A', 'A'), $cadena);
    $cadena = str_replace(array('é', 'è', 'ë', 'ê', 'É', 'È', 'Ê', 'Ë'), array('e', 'e', 'e', 'e', 'E', 'E', 'E', 'E'), $cadena );
    $cadena = str_replace(array('í', 'ì', 'ï', 'î', 'Í', 'Ì', 'Ï', 'Î'), array('i', 'i', 'i', 'i', 'I', 'I', 'I', 'I'), $cadena );
    $cadena = str_replace(array('ó', 'ò', 'ö', 'ô', 'Ó', 'Ò', 'Ö', 'Ô'), array('o', 'o', 'o', 'o', 'O', 'O', 'O', 'O'), $cadena );
    $cadena = str_replace(array('ú', 'ù', 'ü', 'û', 'Ú', 'Ù', 'Û', 'Ü'), array('u', 'u', 'u', 'u', 'U', 'U', 'U', 'U'), $cadena );
    $cadena = str_replace(array('ñ', 'Ñ', 'ç', 'Ç'), array('n', 'N', 'c', 'C'), $cadena );

    return $cadena;
}

$resultx=mysqli_query($db_connection, "SELECT book, chapter, verse, text FROM bible_rv60 WHERE book='".$bibliar_b."' && chapter='".$bibliar_c."' && verse='".$bibliar_v."' ");


 
if (mysqli_num_rows($resultx)>0)
while($rowx = mysqli_fetch_array($resultx))
{			

$x1=$rowx[book];
$x2=$rowx[chapter];
$x3=$rowx[verse];
$x=$rowx[text];


    
                    $cadena =$rowx[text];
                    // Se divide en espacios, tabulaciones y cambios de línea
                    $token = strtok($cadena," \n\t"); // Primer token
                    while($token !== false)
                    {
                     
$token1=$token;      
$p = substr($token, -1);
                            if($p === ',' || $p === '.' || $p === ':' || $p === ';' || $p === ')' || $p === '?' || $p === '!' )
$token = substr($token, 0, -1);
  
$r=substr($token, 0, 2);


  if($r === ',' || $r === '.' || $r === ':' || $r === ';' || $r === '(' || $r === '¡' || $r === '¿')
$token= substr($token, 2);

$token=strtolower($token);
            


$t="|";
 $token=eliminar_tildes($token);   
 
 
$result3=mysqli_query($db_connection, "SELECT adjetivo FROM adjetivos WHERE adjetivo='".$token."' ");                
if(mysqli_num_rows($result3)>0)  
     $t.="| adjetivo ";  

$result4=mysqli_query($db_connection, "SELECT adverbio FROM adverbios WHERE adverbio='".$token."' ");                
if(mysqli_num_rows($result4)>0)  
     $t.="| adverbio ";  

$result5=mysqli_query($db_connection, "SELECT lugar FROM lugares WHERE lugar='".$token."' ");                
if(mysqli_num_rows($result5)>0)  
     $t.="| lugar ";  

$result6=mysqli_query($db_connection, "SELECT nombre FROM nombres_personales WHERE nombre='".$token."' ");                
if(mysqli_num_rows($result6)>0)  
     $t.="| nombre ";   

$result7=mysqli_query($db_connection, "SELECT preposicion FROM preposiciones WHERE preposicion='".$token."' ");                
if(mysqli_num_rows($result7)>0)  
     $t.="| preposición ";   

$result8=mysqli_query($db_connection, "SELECT pronombre FROM pronombres WHERE pronombre='".$token."' ");                
if(mysqli_num_rows($result8)>0)  
     $t.="| pronombre ";   


$result9=mysqli_query($db_connection, "SELECT sustantivo FROM sustantivos WHERE sustantivo='".$token."' ");                
if(mysqli_num_rows($result9)>0)  
     $t.="| sustantivo ";  

 $result10=mysqli_query($db_connection, "SELECT verbo FROM verbos WHERE verbo='".$token."' ");                
if(mysqli_num_rows($result10)>0)  
     $t.="| verbo ";  
                           
         
                   echo "<font size='3' color='Black'>".$token1."</font>"."<font size='3' color='Red'>".$t."</font>";  
           
                 $token = strtok(" \n\t");
                 mysqli_free_result($result3);
                 mysqli_free_result($result4);
                 mysqli_free_result($result5);
                 mysqli_free_result($result6);
                 mysqli_free_result($result7);
                 mysqli_free_result($result8);
                 mysqli_free_result($result9);
                 mysqli_free_result($result10);
                    }
                            

}
 echo "<br /><br /><font size='3' color='Black'>"."Este proyecto esta aun en desarrollo."."</font>"; 
mysqli_free_result($resultx);
mysqli_close($db_connection);
?>

 <br /> 
                      	</div>



                        <div class="text">
	<span>Consulta la gramatica por palabra dentro de cada versiculo</span>
                      	</div>
                         <div class="text">
                          <img src="images/img1.jpg" class="img" width="120" height="90" alt="" />
                          he desarrollado un algoritmo que separa cada palabra de cada versiculo de la biblia, y la compara con tablas dentro de la base de datos para determinar la gramatica de cada versiculo segun la real academia española. <br />
                          <div class="read"><a href="#"> ver más</a></div><br />
                   	  	</div>                 	  	
                   	  	
                        <h1>Diccionario, Biblico.</h1>
                        <div class="text">
  <div class="container">                          
<form action="index.php" method="POST">
     <input type="hidden" name="t" value="<?php echo $_GET['t']; ?>">
     <input type="hidden" name="select1" value="<?php echo $_GET['select1']; ?>">
     <input type="hidden" name="cap" value="<?php echo $_GET['cap']; ?>">
     <input type="hidden" name="ver" value="<?php echo $_GET['ver']; ?>">
     
<div>
<div>
<input type="text" style="background-color:#FFAC33" name="t" class="form-control" class="form-input"  required><button type="submit">Buscar palabra</button>
</div>
</div>
</form>

<?php
include 'db.php';

$x = $_REQUEST['t'];

$result3=mysqli_query($db_connection, "SELECT name, description FROM words WHERE name='".$x."' ");
 
if (mysqli_num_rows($result3)>0)
while($row3 = mysqli_fetch_array($result3))
{			
$x1=$row3[name];
$x2=$row3[description];
}


echo "Palabra "."<a style='background-color:#E58EFF'>".$x1.$x2."</a>";

mysqli_free_result($result3);
mysqli_close($db_connection);
?>
                            
	</div>
                          <ol>
									<li><a href="#">Diccionario biblico estandar</a></li>
									<li><a href="#">Diccionario biblico referenciado</a></li>
									
							  </ol>
							  <br /><br />
                   	  </div>
                        <div id="all_col">
                       	  <div class="col_left"><a class="left_a"  href="#">En el Diccionario biblico estandar puedes consultar la definicion de palabras que se encuentran en la biblia en una tabla con mas de 2576 palabras. </a><br />
								<div class="read"><a href="#"> leer más</a></div>		
                          </div>
                            <div class="col_right"><a class="right_a"  href="#">En el Diccionario biblico referenciado desarrolle un algoritmo que busca en cada versiculo que consultas si existe algunas de las palabras en la tabla y si existen te entrega la definicion por palabra.</a> <br />
								<div class="read"><a href="#"> leer más</a></div>
                          </div>
                        </div>


 <div id="center">
<h1>Consulta Biblica</h1>

 <div class="container">
   
                <table>
                    <tr>
                        <td>Version</td>
                        <td>Libro</td>
                        <td>Capítulo</td>
                        <td>Versículo</td>
                    </tr>
                    <tr> 
<td style="background-color:#FFAC33"><select id="bibliar_t"></select></td>
<td style="background-color:#FFAC33"><select id="bibliar_b"></select></td>
<td style="background-color:#FFAC33"><select id="bibliar_c"></select></td> 
<td style="background-color:#FFAC33"><select id="bibliar_v"></select></td>
                    </tr>
                 
                    <tr>
                        <td colspan="3" style="background-color:#9988FA">Palabra a Buscar
                            <input type="text" id="bibliar_s" value="" />
                        </td>
                        <td><input type="button" id="bibliar_a" value="Buscar" /></td>
                        </td>
                </table>

                <div id="bibliar_r">
                <script src="inc/jquery-3.4.1.min.js"></script>
                <script src="inc/app.js"></script>
                </div>
        </div>
        

    <!-- content ends -->

<h2>Haz una donación</h2>

<ul>
<li>Donaciones seguras de PayPal.</li>
<li>						    
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick" />
<input type="hidden" name="hosted_button_id" value="Z6FWNDED7TKXN" />
<input type="image" src="https://www.paypalobjects.com/es_XC/MX/i/btn/btn_donateCC_LG.gif" border="0" name="submit" title="PayPal - La forma segura y facil para donar en linea!" alt="Donar con el botón PayPal" />
<img alt="" border="0" src="https://www.paypal.com/es_MX/i/scr/pixel.gif" width="1" height="1" />
</form>
</li>

<li>Su donación no es un pago, sino una SEMILLA sembrada para el apoyo de este proyecto de software web. Tenga en cuenta que NO estamos vendiendo este servicio, pero necesitamos mantener los servicores activos para su uso y esto gracias a nuestros generosos donantes.</li>
<li>Para más información por favor contáctenos.</li>
</ul>   
  
                    </div>

                      
                    </div>
                </div>
            </div>
        
        </div>
    <!-- content ends -->
<div id="footer">
<ul>
<li><font size='2' color='Black'>Copyright  2020. yaprendo</font><br /></li>
<li><font size='2' color='Black'> ;]</font><br /></li>
<li><a  class="left_a" href="http://yaprendo.com/politica.html">Politicas de Privacidad</a> | <a class="left_a" href="http://yaprendo.com/terminos.html">Terminos de Uso</a></li>
</ul>     
      </div>

</body>
</html>
