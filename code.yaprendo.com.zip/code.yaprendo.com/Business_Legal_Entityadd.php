<?php 
include 'dat/cdb/db.php'; 

$IdU = $_REQUEST['IdU'];
$IdS = $_REQUEST['IdS'];
$IdB = $_REQUEST['IdB'];

$Business_Name= $_REQUEST['Business_Name'];
$Business_Address= $_REQUEST['Business_Address'];
$Business_Registration_Number= $_REQUEST['Business_Registration_Number'];
$Business_Registration_Certificate= $_REQUEST['Business_Registration_Certificate'];
$Paid_Capital= $_REQUEST['Paid_Capital'];
$Nature_of_the_Industry= $_REQUEST['Nature_of_the_Industry'];
$Number_of_Employees= $_REQUEST['Number_of_Employees'];
$Business_Email_ID= $_REQUEST['Business_Email_ID'];
$Business_Contact= $_REQUEST['Business_Contact'];
$City= $_REQUEST['City'];
$Post_code= $_REQUEST['Post_code'];
$Country= $_REQUEST['Country'];
$Work_Time_Zone= $_REQUEST['Work_Time_Zone'];
$Manager_Name= $_REQUEST['Manager_Name'];
$Manager_Mobile_Number= $_REQUEST['Manager_Mobile_Number'];
$Manager_Email_ID= $_REQUEST['Manager_Email_ID'];
$Manager_Responsible_Name= $_REQUEST['Manager_Responsible_Name'];
$Manager_Responsible_contact_Number= $_REQUEST['Manager_Responsible_contact_Number'];
$Marketing_Manager= $_REQUEST['Marketing_Manager'];
$Marketing_Manager_Mobile_Number= $_REQUEST['Marketing_Manager_Mobile_Number'];
$Marketing_Manager_Email_ID= $_REQUEST['Marketing_Manager_Email_ID'];
$Marketing_Manager_Responsible_Name= $_REQUEST['Marketing_Manager_Responsible_Name'];
$Marketing_Manager_Responsible_Mobile_Number= $_REQUEST['Marketing_Manager_Responsible_Mobile_Number'];
$Salesperson_Name= $_REQUEST['Salesperson_Name'];
$Salesperson_Mobile_Number= $_REQUEST['Salesperson_Mobile_Number'];
$Salesperson_Email_ID= $_REQUEST['Salesperson_Email_ID'];
$Salesperson_Responsible_Name= $_REQUEST['Salesperson_Responsible_Name'];
$Salesperson_Responsible_Mobile_Number= $_REQUEST['Salesperson_Responsible_Mobile_Number'];
$Estado= 1;
$Tipo= 1;
$Terminos= 1;
$Politicas= 1;

 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM Business_Legal_Entity WHERE Business_Name LIKE '".$Business_Name."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: usuarios.php?IdU=$IdU&IdS=$IdS&IdB=$IdB&IdU=$IdU"); 
} else {  
$insert_value ="INSERT INTO Business_Legal_Entity(Business_Name, Business_Address, Business_Registration_Number, Business_Registration_Certificate, Paid_Capital, Nature_of_the_Industry, Number_of_Employees, Business_Email_ID, Business_Contact, City, Post_code, Country, Work_Time_Zone, Manager_Name, Manager_Mobile_Number, Manager_Email_ID, Manager_Responsible_Name, Manager_Responsible_contact_Number, Marketing_Manager, Marketing_Manager_Mobile_Number, Marketing_Manager_Email_ID, Marketing_Manager_Responsible_Name, Marketing_Manager_Responsible_Mobile_Number, Salesperson_Name, Salesperson_Mobile_Number, Salesperson_Email_ID, Salesperson_Responsible_Name, Salesperson_Responsible_Mobile_Number, Fecha, Estado, Tipo, Terminos, Politicas, IdU) VALUES ( '".$Business_Name."',  '".$Business_Address."',  '".$Business_Registration_Number."',  '".$Business_Registration_Certificate."',  '".$Paid_Capital."',  '".$Nature_of_the_Industry."',  '".$Number_of_Employees."',  '".$Business_Email_ID."',  '".$Business_Contact."',  '".$City."',  '".$Post_code."',  '".$Country."',  '".$Work_Time_Zone."',  '".$Manager_Name."',  '".$Manager_Mobile_Number."',  '".$Manager_Email_ID."',  '".$Manager_Responsible_Name."',  '".$Manager_Responsible_contact_Number."',  '".$Marketing_Manager."',  '".$Marketing_Manager_Mobile_Number."',  '".$Marketing_Manager_Email_ID."',  '".$Marketing_Manager_Responsible_Name."',  '".$Marketing_Manager_Responsible_Mobile_Number."',  '".$Salesperson_Name."',  '".$Salesperson_Mobile_Number."',  '".$Salesperson_Email_ID."',  '".$Salesperson_Responsible_Name."',  '".$Salesperson_Responsible_Mobile_Number."',  '".$dt."', '".$Estado."',  '".$Tipo."',  '".$Terminos."',  '".$Politicas."',  '".$IdU."')";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT IdB  FROM  Business_Legal_Entity  WHERE Business_Name = '".$Business_Name."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $IdB =$row['IdB']; 
 header("Location: usuarios.php?IdU=$IdU&IdB=$IdB"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>