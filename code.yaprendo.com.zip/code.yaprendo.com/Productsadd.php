<?php 
include 'dat/cdb/db.php'; 

$IdU = $_REQUEST['IdU'];
$IdB = $_REQUEST['IdB'];
 
$IdP= $_REQUEST['IdP'];
$Name= $_REQUEST['Name'];
$Description= $_REQUEST['Description'];
$Global_price= $_REQUEST['Global_price'];
$Commission= $_REQUEST['Commission'];
$Fixed_price= $_REQUEST['Fixed_price'];
$Minimal_price= $_REQUEST['Minimal_price'];
$Tax= $_REQUEST['Tax'];

$Estado= 1;

 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM Products WHERE Name LIKE '".$Name."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: usuarios.php?IdU=$IdU&IdB=$IdB&IdPIdP=$IdP&IdU=$IdU"); 
} else {  
$insert_value ="INSERT INTO Products(IdP, Name, Description, Global_price, Commission, Fixed_price, Minimal_price, Tax, Date, Estado, IdU, IdB) VALUES ( '".$IdP."',  '".$Name."',  '".$Description."',  '".$Global_price."',  '".$Commission."',  '".$Fixed_price."',  '".$Minimal_price."',  '".$Tax."',  '".$dt."',  '".$Estado."',  '".$IdU."',  '".$IdB."')";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT IdP FROM  Products  WHERE Name = '".$Name."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $IdP =$row['IdP']; 
 header("Location: usuarios.php?IdU=$IdU&IdB=$IdB&IdP=$IdP"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>