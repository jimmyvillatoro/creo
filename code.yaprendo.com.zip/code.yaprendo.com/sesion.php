<!DOCTYPE html>
<html lang="en">
<head>
  <title>Arana-Consulting</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;1,100&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700&family=Raleway:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
      <link rel="stylesheet" type="text/css" href="css/style.css">
     <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

<?php
include 'dat/cdb/db.php';
$IdE = utf8_decode($_GET['IdE']);
$IdU = utf8_decode($_GET['IdU']);
$Sesion = utf8_decode($_GET['Sesion']);
$resultado=mysqli_query($db_connection, "SELECT IdU, Nombres, Apellidos, Fecha FROM Usuarios  WHERE IdU = '".$IdU."' ");

while ($row =mysqli_fetch_array($resultado)) {
     $IdUx=$row[IdU];  
   	 $Nombres=$row[Nombres];
   	 $Apellidos=$row[Apellidos];
   	 $Fecha=$row[Fecha];
  
   }
   

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>    
     <script>
function verificarPasswords() {
 
    // Ontenemos los valores de los campos de contraseñas 
    pass1 = document.getElementById('pass1');
    pass2 = document.getElementById('pass2');
 
    // Verificamos si las constraseñas no coinciden 
    if (pass1.value != pass2.value) {
 
        // Si las constraseñas no coinciden mostramos un mensaje 
        document.getElementById("error").classList.add("mostrar");
 
        return false;
    } else {
 
        // Si las contraseñas coinciden ocultamos el mensaje de error
        document.getElementById("error").classList.remove("mostrar");
 
        // Mostramos un mensaje mencionando que las Contraseñas coinciden 
        document.getElementById("ok").classList.remove("ocultar");
 
        // Desabilitamos el botón de login 
        document.getElementById("login").disabled = true;
 
        // Refrescamos la página (Simulación de envío del formulario) 
        setTimeout(function() {
            location.reload();
        }, 3000);
 
        return true;
    }
 
}
</script>
          
      
   </head>
<body>

<div class="wrapper">
  <!-- header start -->
  <header class="header">

        <div class="header-main">
           <div class="logo">
               <img src="img/aranaConsulting-logo.png">
           </div>
           <div class="open-nav-menu">
              <span></span>
           </div>
           <div class="menu-overlay">
           </div>
           <!-- navigation menu start -->
           <nav class="nav-menu">
             <div class="close-nav-menu">
                <img src="img/close.svg" alt="close">
             </div>
             <ul class="menu">
               <li class="menu-item ">
                   <a href="index.html" style="color:brown;">HOME</a>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">PORTFOLIO  <i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design</a></li>
                       <li class="menu-item"><a href="#">Start Up Consulting</a></li>
                       <li class="menu-item"><a href="#">Business Investment</a></li>
                     
                   </ul>
                </li>
                
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">SERVICES<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design & Marketing Development</a></li>
                       <li class="menu-item"><a href="#">
                        Start Up Consulting & Proof Techniques</a></li>
                   <li class="menu-item"><a href="#">Business Investment In Portugal</a></li>
                   </ul>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">ABOUT US<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Company History</a></li>
                       <li class="menu-item"><a href="#">Company Presentation</a></li>
                       <li class="menu-item"><a href="afiliados.php">register</a></li>
                       <li class="menu-item"><a href="login.html">login</a></li>
                   </ul>
                </li>
                  <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">FAQs<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">All FAQs</a></li>
                       <li class="menu-item"><a href="#">10 Important FAQ</a></li>
                      
                   </ul>
                </li>
               <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">LEGALS<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Cookies Policy</a></li>
                       <li class="menu-item"><a href="#">Data Protection</a></li>
                       <li class="menu-item"><a href="#">Privacy Policy</a></li>
                       <li class="menu-item"><a href="#">Terms and Condition</a></li>
                   </ul>
                </li>
                <li class="menu-item">
                   <a href="#">CONTACT US</a>
                </li>
                 <li class="menu-item">
                   <img src="img/england-image.jpg">
                </li>
                 <li class="menu-item">
                  <img src="img/germany.jpg">
                </li>
                 <li class="menu-item">
                   <img src="img/purtugal-flag.jpg">
                </li>
             </ul>
           </nav>
           <!-- navigation menu end -->
   
     </div>
  </header>
  <!-- header end -->
</div>
</div>

  <div id="slider">

    <img src="img/home-slider-image.jpg">
    <div class="slider-text" data-aos="fade-up"><h1 style="  font-family: 'Montserrat', sans-serif;">START-UP WORLD</h1>
      <h2 style="  font-family: 'Montserrat', sans-serif;">working for your future</h2><a href="http://consulting.aranath-zenitram.eu/company-presentation/">Read More</a></div>
      <!--<img src="img/home-slider-image.jpg">
        <img src="img/home-slider-image.jpg">-->

</div>
<div class="social-links" >
  <div class="slide-toggle arrow-stickynav">
    <img src="img/hide-social.png">
  </div>
    <div class="box">
      <div class="exhibitor-login">
            <a href="">Contact</a>
        </div>
        <div class="exhibitor-login exhibitor-pro">
            <a href="">Promotions</a>
        </div>
        <div class="social-links-body">
        <div class="menu-fixed-social-navigation-container">
          <ul id="menu-fixed-social-navigation" class="menu">
            <li id="menu-item-305" class="facebook-fix "><a target="_blank" rel="noopener noreferrer" href="#">Facebook</a></li>
           <li id="menu-item-306" class="instagram-fix"><a target="_blank" rel="noopener noreferrer" href="#">Instagram</a></li>
           <li id="menu-item-307" class="linked-in-fix"><a target="_blank" rel="noopener noreferrer" href="#">Linked In</a></li>
           <li id="menu-item-308" class="whatsapp-fix"><a target="_blank" rel="noopener noreferrer" href="#">WhatsApp</a></li>
           </ul>
         </div>   
              </div>

</div>
</div>
<script>
    var $ = jQuery;
        $(document).ready(function(){
    $(".slide-toggle").click(function(){
        $(".box").animate({
        width: "toggle"
        });
    });
    });
</script>

 
   

<div class="Currency-bg">
  <div class="container">
    <div class="row">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="abouttitle">
          <h2>AFILIADOS</h2>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Currency -->
<div class="Currency">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="titlepage">
          <h2>RESULTADOS DE MARKETING, <strong class="cur">NO SÓLO HABLAR</strong></h2>
          <p>El concepto de marketing de Aranath Zenitram es proporcionar resultados a su negocio y no solo estadísticas. Desde el inicio de su negocio hasta el trabajo base diario de una empresa madura, le ayudamos a obtener los resultados que necesita. Parte de nuestro personal ha trabajado directamente para clientes de Google / Youtube y Facebook / Instagram y ha realizado más de 1000 consultas en los últimos años, y esta experiencia hace la diferencia. Deje de perder tiempo y dinero, comience a hablar con nosotros y verá qué tan rápido puede obtener resultados.</p>
        
      </div>
    </div>


					<div id="content" class="round">

					

			<h1>Inicia sesión.</h1>

								   

			          <p>

             <div>

      <form action="psesion.php" method="GET">

             <div>

             <div>

 



<input type="text" name="cor" class="form-control"              placeholder="Correo Electrónico" class="form-input" required>

             </div>

             <div>

             <div>

<input type="password" name="pas" class="form-control" placeholder="Contraseña"                              class="form-input" required>

             </div>

             </div>

             </div>


<br />

<input name="Terminos" type="checkbox" required />Terms & Condition

<br />

<input name="Politicas" type="checkbox" required />Privacy Policy

<br />

             <div>

             <div>

<button type="submit" class="btn btn-success">Iniciar Sesión</button>

<p></p>

<p align="justify"> Dudas? soporte@arana.com</p>

             </div>

             </div>

             </form>

         </p>

    </div>



	



  </div>
</div>
<!-- end Currency --> 

<!-- footer -->
<footer>
  <div class="footer">
    <div class="container">
      <div class="row">
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
          <div class="Contact">
            <h3>Contact Us</h3>
            <ul class="contant_icon">
              <li> <a href="#"><img src="icon/location.png"></a></li>
              <li> <a href="#"><img src="icon/tellephone.png"></a></li>
              <li> <a href="#"><img src="icon/email.png"></a></li>
            </ul>
          </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
          <div class="Social">
            <h3>Social links</h3>
            <ul class="socil_link">
              <li><a href="#"><img src="icon/fb.png"></a></li>
              <li><a href="#"><img src="icon/Tw.png"></a></li>
              <li> <a href="#"><img src="icon/lin.png"></a></li>
              <li> <a href="#"><img src="icon/insta.png"></a></li>
            </ul>
          </div>
        </div>
        <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
          <div class="newsletter">
            <h3>newsletter</h3>
            <input class="new" placeholder="Enter your email" type="Enter your email" >
            <button class="subscribe">subscribe</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <p>Copyright 2019 All Right Reserved By <a href="http://html.design">Free html Templates</a></p>
    </div>
  </div>
</footer>
<!-- end footer --> 
<!-- Javascript files --> 
<script src="js/bootstrap.bundle.js"></script>
<script src="js/jquery.min.js"></script> 
<!-- sidebar --> 
<script src="js/custom.js"></script>
</body>
</html>