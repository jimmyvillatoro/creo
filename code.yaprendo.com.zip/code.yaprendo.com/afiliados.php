<!DOCTYPE html>
<html lang="en">
<head>
  <title>Arana-Consulting</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;1,100&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700&family=Raleway:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
      <link rel="stylesheet" type="text/css" href="css/style.css">
     <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
      
     <style>
.ocultar {
    display: none;
}
.mostrar {
    display: block;
}
     </style> 
     
      <script>
function verificarPasswords() {
 
    // Ontenemos los valores de los campos de contraseñas 
    pass1 = document.getElementById('pass1');
    pass2 = document.getElementById('pass2');
 
    // Verificamos si las constraseñas no coinciden 
    if (pass1.value != pass2.value) {
 
        // Si las constraseñas no coinciden mostramos un mensaje 
        document.getElementById("error").classList.add("mostrar");
 
        return false;
    } else {
 
        // Si las contraseñas coinciden ocultamos el mensaje de error
        document.getElementById("error").classList.remove("mostrar");
 
        // Mostramos un mensaje mencionando que las Contraseñas coinciden 
        document.getElementById("ok").classList.remove("ocultar");
 
        // Desabilitamos el botón de login 
        document.getElementById("login").disabled = true;
 
        // Refrescamos la página (Simulación de envío del formulario) 
        setTimeout(function() {
            location.reload();
        }, 3000);
 
        return true;
    }
 
}
</script>
      
</head>
<!-- body -->
<body>

<div class="wrapper">
  <!-- header start -->
  <header class="header">

        <div class="header-main">
           <div class="logo">
               <img src="img/aranaConsulting-logo.png">
           </div>
           <div class="open-nav-menu">
              <span></span>
           </div>
           <div class="menu-overlay">
           </div>
           <!-- navigation menu start -->
           <nav class="nav-menu">
             <div class="close-nav-menu">
                <img src="img/close.svg" alt="close">
             </div>
             <ul class="menu">
               <li class="menu-item ">
                   <a href="index.html" style="color:brown;">HOME</a>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">PORTFOLIO  <i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design</a></li>
                       <li class="menu-item"><a href="#">Start Up Consulting</a></li>
                       <li class="menu-item"><a href="#">Business Investment</a></li>
                     
                   </ul>
                </li>
                
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">SERVICES<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design & Marketing Development</a></li>
                       <li class="menu-item"><a href="#">
                        Start Up Consulting & Proof Techniques</a></li>
                   <li class="menu-item"><a href="#">Business Investment In Portugal</a></li>
                   </ul>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">ABOUT US<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Company History</a></li>
                       <li class="menu-item"><a href="#">Company Presentation</a></li>
                       <li class="menu-item"><a href="afiliados.php">register</a></li>
                       <li class="menu-item"><a href="login.html">login</a></li>
                   </ul>
                </li>
                  <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">FAQs<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">All FAQs</a></li>
                       <li class="menu-item"><a href="#">10 Important FAQ</a></li>
                      
                   </ul>
                </li>
               <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">LEGALS<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Cookies Policy</a></li>
                       <li class="menu-item"><a href="#">Data Protection</a></li>
                       <li class="menu-item"><a href="#">Privacy Policy</a></li>
                       <li class="menu-item"><a href="#">Terms and Condition</a></li>
                   </ul>
                </li>
                <li class="menu-item">
                   <a href="#">CONTACT US</a>
                </li>
                 <li class="menu-item">
                   <img src="img/england-image.jpg">
                </li>
                 <li class="menu-item">
                  <img src="img/germany.jpg">
                </li>
                 <li class="menu-item">
                   <img src="img/purtugal-flag.jpg">
                </li>
             </ul>
           </nav>
           <!-- navigation menu end -->
   
     </div>
  </header>
  <!-- header end -->
</div>
</div>
  <div id="slider">

    <img src="img/home-slider-image.jpg">
    <div class="slider-text" data-aos="fade-up"><h1 style="  font-family: 'Montserrat', sans-serif;">START-UP WORLD</h1>
      <h2 style="  font-family: 'Montserrat', sans-serif;">working for your future</h2><a href="http://consulting.aranath-zenitram.eu/company-presentation/">Read More</a></div>
      <!--<img src="img/home-slider-image.jpg">
        <img src="img/home-slider-image.jpg">-->

</div>
<div class="social-links" >
  <div class="slide-toggle arrow-stickynav">
    <img src="img/hide-social.png">
  </div>
    <div class="box">
      <div class="exhibitor-login">
            <a href="">Contact</a>
        </div>
        <div class="exhibitor-login exhibitor-pro">
            <a href="">Promotions</a>
        </div>
        <div class="social-links-body">
        <div class="menu-fixed-social-navigation-container">
          <ul id="menu-fixed-social-navigation" class="menu">
            <li id="menu-item-305" class="facebook-fix "><a target="_blank" rel="noopener noreferrer" href="#">Facebook</a></li>
           <li id="menu-item-306" class="instagram-fix"><a target="_blank" rel="noopener noreferrer" href="#">Instagram</a></li>
           <li id="menu-item-307" class="linked-in-fix"><a target="_blank" rel="noopener noreferrer" href="#">Linked In</a></li>
           <li id="menu-item-308" class="whatsapp-fix"><a target="_blank" rel="noopener noreferrer" href="#">WhatsApp</a></li>
           </ul>
         </div>   
              </div>

</div>
</div>
<script>
    var $ = jQuery;
        $(document).ready(function(){
    $(".slide-toggle").click(function(){
        $(".box").animate({
        width: "toggle"
        });
    });
    });
</script>

<div class="Currency-bg">
  <div class="container">
    <div class="row">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="abouttitle">
          <h2>AFILIADOS</h2>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Currency -->
<div class="Currency">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="titlepage">
          <h2>ARANA <strong class="cur">AFFILIATES</strong></h2>
 <p>Welcome to one of the largest affiliate marketing programs in the world. The Arana Affiliate program helps content creators, publishers and bloggers monetize their traffic. With millions of products and programs available on Arana, partners use link building tools to direct their audience to their recommendations and earn money through affiliate purchases and programs.</p>
          </div>
      </div>
    </div>

<h3>Registration</h3>

						<ul>

<li> 

        <p>
            

           
     

            <form action="pregusu.php" onsubmit="verificarPasswords(); return false" method="POST">
 
                <div>
                    <div>
                        <input type="text" name="nom" class="form-control" placeholder="First Name" class="form-input"

                            required>

                    </div>

                    <div>

                        <input type="text" name="ape" class="form-control" placeholder="Last Name"

                            class="form-input" required>

                    </div>

                </div>

<div>

                    <div>

                        <input type="email" name="cor" class="form-control" placeholder="Email" class="form-input"

                            required>

                    </div>

                </div>
                
                <div>

                    <div>

                        <input type="text" name="pai" class="form-control" placeholder="Country" class="form-input"

                            required>

                    </div>

                </div>

                <div>

                    <div>

                        <input type="text" name="mov" class="form-control" placeholder="Movil" class="form-input"

                            required>

                    </div>

                </div>

                  <div>

                    <div>

                        <input type="password" name="pas" class="form-control" placeholder="Password" class="form-input"

                          id="pass1"  required>

                    </div>
                    <div>

                        <input type="password" name="pas2" class="form-control" placeholder="Confirm Password" class="form-input"

                         id="pass2"   required>

                    </div>

                </div>
                
<div id="msg"></div>
 
<!-- Mensajes de Verificación -->
<div id="error" class="alert alert-danger ocultar" role="alert">
    Passwords do not match, please try again !
</div>
<div id="ok" class="alert alert-success ocultar" role="alert">
   Passwords match! (Processing form ...)
</div>


<br />

<input name="Terminos" type="checkbox" required />Terms & Condition

<br />

<input name="Politicas" type="checkbox" required />Privacy Policy

<br />
                

     <div >
          <div >
            
           <button type="submit" class="btn btn-success">subscribe</button>
     
          </div>
        </div>

       

            </form>
            
            <p id="ad">Log in</p>

<ul>	

	<li><a href="sesion.php" title="" 

class="round">Members</a></li>

					</ul>
            

   

	



  </div>
</div>
<!-- end Currency --> 

<!-- footer -->
<div class="main-footer">
 <footer class="footer">
     <div class="container">
      <div class="row">
        <div class="footer-col">
          <h4>INFORMATION</h4>
          <ul>
            <li><a href="#">HOME</a></li>
            <li><a href="#">PORTFOLIO</a></li>
            <li><a href="#">SERVICES</a></li>
            <li><a href="#">CONTACT US</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>HOW CAN WE HELP?</h4>
          <ul>
            <li><a href="#">ALL FAQs</a></li>
            <li><a href="#">TERMS & CONDITIONS</a></li>
            <li><a href="#">PRIVACY POLICY</a></li>
            <li><a href="#">COOKIES POLICY</a></li>
            <li><a href="#">DATA PROTECTION</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>CONTACT US</h4>
          <ul>
            <li style="color:white;font-weight:bold;  font-family: 'Raleway', sans-serif; ">ADDRESS</li>
            <li style="color:white;font-weight:bold;text-transform: uppercase;   
            font-family:'Raleway', sans-serif;"> Danara Martinez Saiz
Calçada do Carrascal  <span class="num">180, 1 </span>ESQ 
            <span class="num">1900 - 
            135</span> Lisboa / Portugal
            </li>
          </ul>
        </div>
        <div class="footer-col">
         
          <div class="company_logo">
              <img src="img/Aranath.png" width="200px" >
          </div>
        </div>
      </div>
     </div>
  </footer>
  <div class="second-footer">
    <p>©COPYRIGHT | ARANATH-ZENITRAM <span class="num">2019.</span></p>
  </div>
</div>


<script src="js/script.js"></script>
<script src="js/script1.js"></script>
 <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
 <script src="js/jquery.min.js"></script> 
  <script>
    AOS.init();
  </script>
</body>
</html>