<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Upload</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;1,100&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700&family=Raleway:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
      <link rel="stylesheet" type="text/css" href="css/style.css">
     <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
   </head>

<?php
	
include 'dat/cdb/db.php';

$IdG = utf8_decode($_GET['IdG']);
$IdP = utf8_decode($_GET['IdP']);
$IdU = utf8_decode($_GET['IdU']);
$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT IdU, Nombres, Apellidos, Fecha FROM Usuarios  WHERE IdU = '".$IdU."' ");

while ($row =mysqli_fetch_array($resultado)) {
     $IdUx=$row['IdU'];  
   	 $Nombres=$row['Nombres'];
   	 $Apellidos=$row['Apellidos'];
   	 $Fecha=$row['Fecha'];
  
   }
   


mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

     
   </head>
<body>

<div class="wrapper">
  <!-- header start -->
  <header class="header">

        <div class="header-main">
           <div class="logo">
               <img src="img/aranaConsulting-logo.png">
           </div>
           <div class="open-nav-menu">
              <span></span>
           </div>
           <div class="menu-overlay">
           </div>
           <!-- navigation menu start -->
           <nav class="nav-menu">
             <div class="close-nav-menu">
                <img src="img/close.svg" alt="close">
             </div>
             <ul class="menu">
               <li class="menu-item ">
                   <a href="index.html" style="color:brown;">HOME</a>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">PORTFOLIO  <i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design</a></li>
                       <li class="menu-item"><a href="#">Start Up Consulting</a></li>
                       <li class="menu-item"><a href="#">Business Investment</a></li>
                     
                   </ul>
                </li>
                
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">SERVICES<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design & Marketing Development</a></li>
                       <li class="menu-item"><a href="#">
                        Start Up Consulting & Proof Techniques</a></li>
                   <li class="menu-item"><a href="#">Business Investment In Portugal</a></li>
                   </ul>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">ABOUT US<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Company History</a></li>
                       <li class="menu-item"><a href="#">Company Presentation</a></li>
                       <li class="menu-item"><a href="afiliados.php">register</a></li>
                       <li class="menu-item"><a href="login.html">login</a></li>
                   </ul>
                </li>
                  <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">FAQs<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">All FAQs</a></li>
                       <li class="menu-item"><a href="#">10 Important FAQ</a></li>
                      
                   </ul>
                </li>
               <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">LEGALS<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Cookies Policy</a></li>
                       <li class="menu-item"><a href="#">Data Protection</a></li>
                       <li class="menu-item"><a href="#">Privacy Policy</a></li>
                       <li class="menu-item"><a href="#">Terms and Condition</a></li>
                   </ul>
                </li>
                <li class="menu-item">
                   <a href="#">CONTACT US</a>
                </li>
                 <li class="menu-item">
                   <img src="img/england-image.jpg">
                </li>
                 <li class="menu-item">
                  <img src="img/germany.jpg">
                </li>
                 <li class="menu-item">
                   <img src="img/purtugal-flag.jpg">
                </li>
             </ul>
           </nav>
           <!-- navigation menu end -->
   
     </div>
  </header>
  <!-- header end -->
</div>
</div>

  <div id="slider">

    <img src="img/home-slider-image.jpg">
    <div class="slider-text" data-aos="fade-up"><h1 style="  font-family: 'Montserrat', sans-serif;">START-UP WORLD</h1>
      <h2 style="  font-family: 'Montserrat', sans-serif;">working for your future</h2><a href="http://consulting.aranath-zenitram.eu/company-presentation/">Read More</a></div>
      <!--<img src="img/home-slider-image.jpg">
        <img src="img/home-slider-image.jpg">-->

</div>
<div class="social-links" >
  <div class="slide-toggle arrow-stickynav">
    <img src="img/hide-social.png">
  </div>
    <div class="box">
      <div class="exhibitor-login">
            <a href="">Contact</a>
        </div>
        <div class="exhibitor-login exhibitor-pro">
            <a href="">Promotions</a>
        </div>
        <div class="social-links-body">
        <div class="menu-fixed-social-navigation-container">
          <ul id="menu-fixed-social-navigation" class="menu">
            <li id="menu-item-305" class="facebook-fix "><a target="_blank" rel="noopener noreferrer" href="#">Facebook</a></li>
           <li id="menu-item-306" class="instagram-fix"><a target="_blank" rel="noopener noreferrer" href="#">Instagram</a></li>
           <li id="menu-item-307" class="linked-in-fix"><a target="_blank" rel="noopener noreferrer" href="#">Linked In</a></li>
           <li id="menu-item-308" class="whatsapp-fix"><a target="_blank" rel="noopener noreferrer" href="#">WhatsApp</a></li>
           </ul>
         </div>   
              </div>

</div>
</div>
<script>
    var $ = jQuery;
        $(document).ready(function(){
    $(".slide-toggle").click(function(){
        $(".box").animate({
        width: "toggle"
        });
    });
    });
</script>

 


<div class="Currency-bg">
  <div class="container">
    <div class="row">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="abouttitle">
          <h2>USER  : <?php echo $Nombres; ?> <?php echo $Apellidos; ?></h2>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
$archivo = $directorio.basename($_FILES['subir_archivo']['name']);
$l = strlen($archivo);
if($l <= 0){
?>
<h1 align="center">Send file</h1>
</br>
<form enctype="multipart/form-data" action="carga.php" method="POST">
<input type="hidden" name="IdU" value="<?php echo utf8_decode($_GET['IdU']); ?>">
<input type="hidden" name="IdG" value="<?php echo utf8_decode($_GET['IdG']); ?>">
<input type="hidden" name="IdP" value="<?php echo utf8_decode($_GET['IdP']); ?>">
<input type="hidden" name="MAX_FILE_SIZE" value="512000" />
<p><input name="subir_archivo" type="file" /> <button type="submit" value="Send file" >Send file</button></p>
</form>
<?php
}
?>
</br>
<div class="main">
<h1 align="center">File in process</h1>
<?php
$archivo = $directorio.basename($_FILES['subir_archivo']['name']);
$l = strlen($archivo);
mkdir("dat/imgE/", 0700); 
$directorio = 'dat/imgE/';
$subir_archivo = $directorio.basename($_FILES['subir_archivo']['name']);
echo "<div>";
if (move_uploaded_file($_FILES['subir_archivo']['tmp_name'], $subir_archivo)) {
      echo "The file is valid and uploaded successfully.<br><br>";
	  /*echo"<a href='".$subir_archivo."' target='_blank'><img src='".$subir_archivo."' width='150'></a>";*/
    } else {
       echo "uploading file";
    }
   
if($l > 0){
$info = new SplFileInfo($archivo);
var_dump($info->getExtension());
$nuevoNombre = uniqid() .$info;
$archivoAbierto = fopen($archivo, 'r');
fclose($archivoAbierto);
rename( $directorio.$archivo,$directorio.$nuevoNombre);
include 'dat/cdb/db.php';
$IdU = $_REQUEST['IdU'];
$IdP = $_REQUEST['IdP'];
$IdG = $_REQUEST['IdG'];
$update_value ="UPDATE Graphic_elements SET Photo='".$nuevoNombre."' WHERE IdG='".$IdG."' ";
$retry_value = mysqli_query($db_connection,$update_value);
mysqli_close($db_connection);
//echo "<img src='dat/imgE/'".$nuevoNombre."'>";
}    
 echo "</div>";
?>
<br>

<div style="border:1px solid #000000; text-transform:uppercase">  
</div>
</div>
<p><a href="usuarios.php?IdU=<?php echo $IdU; ?>&Sesion=<?php echo $Sesion; ?>&IdE=<?php echo $IdE; ?>&IdA=<?php echo $IdA; ?>&IdO=<?php echo $IdO; ?>">Back</a></p>

  </div>
</div>
<!-- end Currency --> 


  </div>
</div>
<!-- end Currency --> 

<div class="main-footer">
 <footer class="footer">
     <div class="container">
      <div class="row">
        <div class="footer-col">
          <h4>INFORMATION</h4>
          <ul>
            <li><a href="#">HOME</a></li>
            <li><a href="#">PORTFOLIO</a></li>
            <li><a href="#">SERVICES</a></li>
            <li><a href="#">CONTACT US</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>HOW CAN WE HELP?</h4>
          <ul>
            <li><a href="#">ALL FAQs</a></li>
            <li><a href="#">TERMS & CONDITIONS</a></li>
            <li><a href="#">PRIVACY POLICY</a></li>
            <li><a href="#">COOKIES POLICY</a></li>
            <li><a href="#">DATA PROTECTION</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>CONTACT US</h4>
          <ul>
            <li style="color:white;font-weight:bold;  font-family: 'Raleway', sans-serif; ">ADDRESS</li>
            <li style="color:white;font-weight:bold;text-transform: uppercase;   
            font-family:'Raleway', sans-serif;"> Danara Martinez Saiz
Calçada do Carrascal  <span class="num">180, 1 </span>ESQ 
            <span class="num">1900 - 
            135</span> Lisboa / Portugal
            </li>
          </ul>
        </div>
        <div class="footer-col">
         
          <div class="company_logo">
              <img src="img/Aranath.png" width="200px" >
          </div>
        </div>
      </div>
     </div>

  </footer>
  <div class="second-footer">
    <p>©COPYRIGHT | ARANATH-ZENITRAM <span class="num">2019.</span></p>
  </div>
</div>


<script src="js/script.js"></script>
<script src="js/script1.js"></script>
 <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>
</body>
</html>