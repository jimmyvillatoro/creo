<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Galery</title>
</head>
<body>
<div class='container'>
<h1 class="page-header">Galería de imágenes</h1>
<p>&nbsp;</p>
<?php
include 'dat/cdb/db.php'; 
$IdP = $_REQUEST['IdP'];
$IdU = $_REQUEST['IdU'];
$IdG = $_REQUEST['IdG'];

$resultado=mysqli_query($db_connection, "SELECT * FROM Graphic_elements WHERE IdG > 0 "); 
if (mysqli_num_rows($resultado)>0)
 while ($row =mysqli_fetch_array($resultado)){
    
 $Photo =$row['Photo']; 
  $Title =$row['Title']; 
   $Description =$row['Description']; 
    echo '
    <table class="default" height="100" align="left" bgcolor="#EEEEEE" style="border:solid; border-width:thin; border-color:#CCCCCC">
    <tr style="background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);">
    <td><a>'.$Title.'</a></td>
    </tr>';
    echo '<tr style="background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);">
    <td>
     <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="prueba" data-caption="esta es una prueba de descripcion de la galleria de imagenes" data-image="img/banner/632867.jpg" data-target="#image-gallery">
     <a><img class="img-responsive" src="dat/imgE/'.$Photo.'" alt="'.$Description.'"></a>
    </td>
    </tr>';
    echo '<tr>
    <td width="20" ><a>'.$Description.'</a></td>
    </tr>';

    echo '</table>';
}
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
</div>
<p>&nbsp;</p>
</body>
</html>
