<?php 
include 'dat/cdb/db.php'; 

$IdP = $_REQUEST['IdP'];
$IdU = $_REQUEST['IdU'];
$IdG = $_REQUEST['IdG'];

 

$Photo= "";
$Title= $_REQUEST['Title'];
$Description= $_REQUEST['Description'];
$Link= $_REQUEST['Link'];
$Date= $_REQUEST['Date'];
$Estado= $_REQUEST['Estado'];

 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM Graphic_elements WHERE Photo LIKE '".$Photo."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: usuarios.php?IdP=$IdP&IdU=$IdU&IdE=$IdE&IdP=$IdP"); 
} else {  
$insert_value ="INSERT INTO Graphic_elements(Photo, Title, Description, Link, Date, Estado, IdP) VALUES ( '".$Photo."',  '".$Title."',  '".$Description."',  '".$Link."',  '".$dt."',  1,  '".$IdP."')";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT IdG  FROM  Graphic_elements  WHERE Photo = '".$Photo."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $IdG =$row['IdG']; 
 header("Location: carga.php?IdU=$IdU&IdG=$IdG&IdP=$IdP"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>