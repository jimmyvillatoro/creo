-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 15-07-2021 a las 13:45:31
-- Versión del servidor: 5.7.23-23
-- Versión de PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `yaprendo_ProyectoDan`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Affiliates`
--

DROP TABLE IF EXISTS `Affiliates`;
CREATE TABLE IF NOT EXISTS `Affiliates` (
  `IdA` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Last_Name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Date_of_Birth` datetime NOT NULL,
  `Nationality` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Contact_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Optional_Contact_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `City` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Post_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `Country` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Passport_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Profession` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Fecha` datetime NOT NULL,
  `Terminos` int(11) NOT NULL,
  `Politicas` int(11) NOT NULL,
  `IdU` int(11) NOT NULL,
  PRIMARY KEY (`IdA`),
  KEY `IdU` (`IdU`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Affiliates`
--

INSERT INTO `Affiliates` (`IdA`, `First_Name`, `Last_Name`, `Date_of_Birth`, `Nationality`, `Email_ID`, `Contact_Number`, `Optional_Contact_Number`, `City`, `Post_code`, `Country`, `Address`, `Passport_Number`, `Profession`, `Estado`, `Fecha`, `Terminos`, `Politicas`, `IdU`) VALUES
(1, 'Maria', 'Boanerges', '2021-07-15 13:00:00', 'Mexicana', 'maria@arana.com', '9611772089', '9611772089', 'Mexico', '29040', 'Mexico', 'Comocida', '123456789', 'ninguna', 1, '2021-07-15 13:00:30', 1, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Business_Legal_Entity`
--

DROP TABLE IF EXISTS `Business_Legal_Entity`;
CREATE TABLE IF NOT EXISTS `Business_Legal_Entity` (
  `IdB` int(11) NOT NULL AUTO_INCREMENT,
  `Business_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Registration_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Registration_Certificate` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Paid_Capital` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Nature_of_the_Industry` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Number_of_Employees` int(11) NOT NULL,
  `Business_Email_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Contact` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `City` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Post_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Country` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Work_Time_Zone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Manager_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Manager_Mobile_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Manager_Email_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Manager_Responsible_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Manager_Responsible_contact_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Marketing_Manager` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Marketing_Manager_Mobile_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Marketing_Manager_Email_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Marketing_Manager_Responsible_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Marketing_Manager_Responsible_Mobile_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Salesperson_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Salesperson_Mobile_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Salesperson_Email_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Salesperson_Responsible_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Salesperson_Responsible_Mobile_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Fecha` datetime NOT NULL,
  `Estado` int(11) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Terminos` int(11) NOT NULL,
  `Politicas` int(11) NOT NULL,
  `IdU` int(11) NOT NULL,
  PRIMARY KEY (`IdB`),
  KEY `IdU` (`IdU`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Business_Legal_Entity`
--

INSERT INTO `Business_Legal_Entity` (`IdB`, `Business_Name`, `Business_Address`, `Business_Registration_Number`, `Business_Registration_Certificate`, `Paid_Capital`, `Nature_of_the_Industry`, `Number_of_Employees`, `Business_Email_ID`, `Business_Contact`, `City`, `Post_code`, `Country`, `Work_Time_Zone`, `Manager_Name`, `Manager_Mobile_Number`, `Manager_Email_ID`, `Manager_Responsible_Name`, `Manager_Responsible_contact_Number`, `Marketing_Manager`, `Marketing_Manager_Mobile_Number`, `Marketing_Manager_Email_ID`, `Marketing_Manager_Responsible_Name`, `Marketing_Manager_Responsible_Mobile_Number`, `Salesperson_Name`, `Salesperson_Mobile_Number`, `Salesperson_Email_ID`, `Salesperson_Responsible_Name`, `Salesperson_Responsible_Mobile_Number`, `Fecha`, `Estado`, `Tipo`, `Terminos`, `Politicas`, `IdU`) VALUES
(1, 'Maria compañy', 'conocida', '9611772089', '12345', '10', 'nada', 3, 'maria@arana.com', 'maria', 'mexico', '29040', 'Mexico', 'mexico', 'maia', '9611772089', 'maria@arana.com', 'maria', 'maria', 'maria', '9611772089', 'maria@arana.com', 'maria', 'maria', 'maria', 'maria', 'maria@arana.com', 'maria', 'maria', '2021-07-15 13:12:28', 1, 1, 1, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE IF NOT EXISTS `chat` (
  `chatid` int(11) NOT NULL AUTO_INCREMENT,
  `sender_userid` int(11) NOT NULL,
  `reciever_userid` int(11) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`chatid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `chat`
--

INSERT INTO `chat` (`chatid`, `sender_userid`, `reciever_userid`, `message`, `timestamp`, `status`) VALUES
(1, 2, 1, 'hello this is a welcome message, you know I am a dreamer, and I would like to maybe in the future design this chat in such a way that it would look appropriate for a corporate company.  but I leave you this small sample that is still in development, I thank GNU for the contribution. ', '2021-07-13 14:36:01', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chat_login_details`
--

DROP TABLE IF EXISTS `chat_login_details`;
CREATE TABLE IF NOT EXISTS `chat_login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `IdU` int(11) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_typing` enum('no','yes') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `chat_login_details`
--

INSERT INTO `chat_login_details` (`id`, `IdU`, `last_activity`, `is_typing`) VALUES
(1, 2, '2021-07-15 17:56:15', 'no');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Clasificaciones`
--

DROP TABLE IF EXISTS `Clasificaciones`;
CREATE TABLE IF NOT EXISTS `Clasificaciones` (
  `IdC` int(11) NOT NULL AUTO_INCREMENT,
  `Clasificacion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Descripcion` text COLLATE utf8_unicode_ci NOT NULL,
  `Tipo` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `IdP` int(11) NOT NULL,
  `IdC2` int(11) NOT NULL,
  PRIMARY KEY (`IdC`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Clasificaciones`
--

INSERT INTO `Clasificaciones` (`IdC`, `Clasificacion`, `Descripcion`, `Tipo`, `IdP`, `IdC2`) VALUES
(1, 'Especie', 'Categoría o división establecida teniendo en cuenta determinadas cualidades, condiciones o criterios de clasificación.', 'Sustantivo', 0, 0),
(2, 'Genero', 'Conjunto de personas o cosas que tienen características generales comunes.', 'Sustantivo', 0, 1),
(3, 'Familia', 'Grupo de personas formado por una pareja (normalmente unida por lazos legales o religiosos), que convive y tiene un proyecto de vida en común, y sus hijos, cuando los tienen.', 'Sustantivo', 0, 2),
(4, 'Ordenes', 'Manera de estar colocadas las cosas o las personas en el espacio o de sucederse los hechos en el tiempo, según un determinado criterio o una determinada norma.', 'Sustantivo', 0, 3),
(5, 'Clases', 'Grupo de elementos de un conjunto que tiene características comunes.', 'Sustantivo', 0, 4),
(6, 'Plantas', 'Organismo vivo que crece sin poder moverse, en especial el que crece fijado al suelo y se nutre de las sales minerales y del anhídrido carbónico que absorbe por las raíces o por los poros de las hojas.', 'genero neutro', 0, 4),
(7, 'Animales', 'Reino al que pertenecen los organismos pluricelulares que se nutren de sustancias elaboradas por otros seres vivos (pues no pueden elaborarlas por sí mismos), las cuales consiguen desplazándose hacia ellas o, en las especies sésiles, atrayéndolas hacia sí; generalmente están dotados de capacidad de movimiento, sistema nervioso y órganos sensoriales.', 'genero neutro', 0, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Dandic`
--

DROP TABLE IF EXISTS `Dandic`;
CREATE TABLE IF NOT EXISTS `Dandic` (
  `IdD` int(11) NOT NULL AUTO_INCREMENT,
  `Palabra` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Idioma1` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Idioma2` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Traduccion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Significado` text COLLATE utf8_unicode_ci NOT NULL,
  `Relacion` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Tipo` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Tipo2` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Fonetica` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `IdU` int(11) NOT NULL,
  `Fecha` datetime NOT NULL,
  `Estado` int(11) NOT NULL,
  PRIMARY KEY (`IdD`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Dandic`
--

INSERT INTO `Dandic` (`IdD`, `Palabra`, `Idioma1`, `Idioma2`, `Traduccion`, `Significado`, `Relacion`, `Tipo`, `Tipo2`, `Fonetica`, `IdU`, `Fecha`, `Estado`) VALUES
(1, 'God', 'English', 'English', 'Dios', '', '', 'Verbo', '', '60c4fad895ce1.webm', 4, '2021-06-12 13:19:57', 1),
(2, 'Love', 'Spanish', 'English', 'Amar', '', '', 'Verb', 'Place', '60c50945b278b.webm', 4, '2021-06-12 14:21:32', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Graphic_elements`
--

DROP TABLE IF EXISTS `Graphic_elements`;
CREATE TABLE IF NOT EXISTS `Graphic_elements` (
  `IdG` int(11) NOT NULL AUTO_INCREMENT,
  `Photo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Description` text COLLATE utf8_unicode_ci NOT NULL,
  `Link` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Date` datetime NOT NULL,
  `Estado` int(11) NOT NULL,
  `IdP` int(11) NOT NULL,
  PRIMARY KEY (`IdG`),
  KEY `IdP` (`IdP`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Graphic_elements`
--

INSERT INTO `Graphic_elements` (`IdG`, `Photo`, `Title`, `Description`, `Link`, `Date`, `Estado`, `IdP`) VALUES
(1, '60f081cc526e7descarga.jpg', 'presetacion de zapato', 'zapatos hermosos', 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fcnnespanol.cnn.com%2Fwp-content%2Fuploads%2F2015%2F12%2Fmanshoes.jpg%3Fquality%3D100%26strip%3Dinfo&imgrefurl=https%3A%2F%2Fcnnespanol.cnn.com%2F2015%2F12%2F21%2Ftres-tipos-de-zapatos-que-todo-hombre', '2021-07-15 13:27:41', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Idiomas`
--

DROP TABLE IF EXISTS `Idiomas`;
CREATE TABLE IF NOT EXISTS `Idiomas` (
  `Idioma` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Descripcion` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Relacion` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  PRIMARY KEY (`Idioma`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Idiomas`
--

INSERT INTO `Idiomas` (`Idioma`, `Descripcion`, `Relacion`, `Estado`) VALUES
('AS UNA SELECION', '', '', 1),
('Chinese', '', '', 1),
('English', '', '', 1),
('French', '', '', 1),
('German', '', '', 1),
('Italian', '', '', 1),
('Spanish', '', '', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Landing`
--

DROP TABLE IF EXISTS `Landing`;
CREATE TABLE IF NOT EXISTS `Landing` (
  `IdL` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nombres` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Apellidos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Correo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Movil` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Msj` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Tipo` int(6) DEFAULT NULL,
  `Estado` int(6) DEFAULT NULL,
  PRIMARY KEY (`IdL`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Landing`
--

INSERT INTO `Landing` (`IdL`, `Nombres`, `Apellidos`, `Correo`, `Movil`, `Msj`, `Fecha`, `Tipo`, `Estado`) VALUES
(1, 'Jimmy', 'Villatoro', 'jimmyvillatoro77@gmail.com', '9611772089', 'hola esto es un saludo', '2021-07-05 15:09:37', 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Lexeme`
--

DROP TABLE IF EXISTS `Lexeme`;
CREATE TABLE IF NOT EXISTS `Lexeme` (
  `IdL` int(11) NOT NULL AUTO_INCREMENT,
  `IdIdiom` int(11) NOT NULL,
  `IdWord` int(11) NOT NULL,
  `ProperNoun` tinyint(1) NOT NULL,
  `Noun` tinyint(1) NOT NULL,
  `Pronoun_personal` tinyint(1) NOT NULL,
  `Pronoun_possessive` tinyint(1) NOT NULL,
  `Verb` tinyint(1) NOT NULL,
  `Adverb` tinyint(1) NOT NULL,
  `Adjective` tinyint(1) NOT NULL,
  `Participle` tinyint(1) NOT NULL,
  `Particle` tinyint(1) NOT NULL,
  `Preposition` tinyint(1) NOT NULL,
  PRIMARY KEY (`IdL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Pagosdemarketing`
--

DROP TABLE IF EXISTS `Pagosdemarketing`;
CREATE TABLE IF NOT EXISTS `Pagosdemarketing` (
  `IdP` int(11) NOT NULL AUTO_INCREMENT,
  `IdA` int(11) NOT NULL,
  `Fecha` datetime NOT NULL,
  `Importe` float NOT NULL,
  `Descuento` float NOT NULL,
  `Impuesto` float NOT NULL,
  `Total` float NOT NULL,
  `Estado` int(11) NOT NULL,
  PRIMARY KEY (`IdP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Products`
--

DROP TABLE IF EXISTS `Products`;
CREATE TABLE IF NOT EXISTS `Products` (
  `IdP` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Description` text COLLATE utf8_unicode_ci NOT NULL,
  `Global_price` float NOT NULL,
  `Commission` float NOT NULL,
  `Fixed_price` float NOT NULL,
  `Minimal_price` float NOT NULL,
  `Tax` float NOT NULL,
  `Date` datetime NOT NULL,
  `Estado` int(11) NOT NULL,
  `IdU` int(11) NOT NULL,
  `IdB` int(11) NOT NULL,
  PRIMARY KEY (`IdP`),
  KEY `IdU` (`IdU`,`IdB`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Products`
--

INSERT INTO `Products` (`IdP`, `Name`, `Description`, `Global_price`, `Commission`, `Fixed_price`, `Minimal_price`, `Tax`, `Date`, `Estado`, `IdU`, `IdB`) VALUES
(1, 'shoes', 'zapatos muy bonitos', 100, 10, 90, 50, 16, '2021-07-15 13:19:57', 1, 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Relacionafiliadoobjeto`
--

DROP TABLE IF EXISTS `Relacionafiliadoobjeto`;
CREATE TABLE IF NOT EXISTS `Relacionafiliadoobjeto` (
  `IdR` int(11) NOT NULL,
  `IdA` int(11) NOT NULL,
  `IdO` int(11) NOT NULL,
  `Fecha` datetime NOT NULL,
  `Estado` int(11) NOT NULL,
  PRIMARY KEY (`IdR`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Reseller`
--

DROP TABLE IF EXISTS `Reseller`;
CREATE TABLE IF NOT EXISTS `Reseller` (
  `IdR` int(11) NOT NULL AUTO_INCREMENT,
  `Business_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Nature_of_business_Industry` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Business_City` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Country` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Registration_Number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Contact_Number_01` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Contact_Number_02` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Website` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Manager_Full_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Manager_ID_card_number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Manager_passport_number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Manager_Contact_number_1` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Manager_Contact_number_2` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Business_Manager_Email_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Fecha` datetime NOT NULL,
  `Estado` int(11) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Terminos` int(11) NOT NULL,
  `Politicas` int(11) NOT NULL,
  `IdU` int(11) NOT NULL,
  PRIMARY KEY (`IdR`),
  KEY `IdU` (`IdU`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Reseller`
--

INSERT INTO `Reseller` (`IdR`, `Business_Name`, `Nature_of_business_Industry`, `Business_Address`, `Business_City`, `Business_Country`, `Business_Registration_Number`, `Business_Contact_Number_01`, `Business_Contact_Number_02`, `Business_Email`, `Business_Website`, `Business_Manager_Full_Name`, `Business_Manager_ID_card_number`, `Business_Manager_passport_number`, `Business_Manager_Contact_number_1`, `Business_Manager_Contact_number_2`, `Business_Manager_Email_ID`, `Fecha`, `Estado`, `Tipo`, `Terminos`, `Politicas`, `IdU`) VALUES
(1, 'Maria compañy', 'nada', 'conocida', 'mexico', 'mexico', '9611772089', '9611772089', '9611772089', 'maria@arana.com', 'maria.com', 'maria  boanerges', '12354', '123445', 'maria', 'maria', 'maria@arana.com', '2021-07-15 13:11:14', 1, 1, 1, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Servidores`
--

DROP TABLE IF EXISTS `Servidores`;
CREATE TABLE IF NOT EXISTS `Servidores` (
  `IdS` int(11) NOT NULL AUTO_INCREMENT,
  `Servidor` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Usuario` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Clave` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Basedatos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Tabla` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Fecha` datetime NOT NULL,
  PRIMARY KEY (`IdS`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Servidores`
--

INSERT INTO `Servidores` (`IdS`, `Servidor`, `Usuario`, `Clave`, `Basedatos`, `Tabla`, `Fecha`) VALUES
(1, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'clientes', '2021-07-04 15:04:43'),
(2, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-04 15:05:11'),
(3, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'clientes', '2021-07-04 15:13:15'),
(4, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-04 22:40:04'),
(5, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-04 22:40:34'),
(6, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-04 23:23:11'),
(7, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-04 23:25:30'),
(8, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-05 11:33:13'),
(9, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-05 11:35:58'),
(10, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-05 11:35:58'),
(11, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-05 18:27:06'),
(12, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-06 11:38:35'),
(13, 'www.yaprendo.com', 'yaprendo_root', 'us1317mx@', 'yaprendo_pymes', 'usuarios', '2021-07-06 21:39:09'),
(14, 'fdg', 'hgfgh', 'fghfg', 'hfgh', 'gfgh', '2021-07-08 17:34:54'),
(15, 'fdg', 'hgfgh', 'fghfg', 'hfgh', 'gfgh', '2021-07-08 17:34:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Tablas`
--

DROP TABLE IF EXISTS `Tablas`;
CREATE TABLE IF NOT EXISTS `Tablas` (
  `IdT` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Crea` text COLLATE utf8_unicode_ci NOT NULL,
  `Fecha` datetime NOT NULL,
  PRIMARY KEY (`IdT`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Tablas`
--

INSERT INTO `Tablas` (`IdT`, `Nombre`, `Crea`, `Fecha`) VALUES
(1, 'Frio', 'CREATE TABLE Frio (\r\nIdT INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,\r\nNombres VARCHAR(50) NOT NULL,\r\nApellidos VARCHAR(50) NOT NULL,\r\nCorreo_electronico VARCHAR(50)\r\n)', '2021-07-04 15:18:09'),
(2, 'TEST', 'CREATE TABLE TEST (\r\nIdT INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,\r\nNombres VARCHAR(50) NOT NULL,\r\nApellidos VARCHAR(50) NOT NULL,\r\nCorreo_electronico VARCHAR(50),\r\nCelular VARCHAR(10),\r\nMensaje TEXT,\r\nFecha_nacimiento DATETIME NOT NULL,\r\nFecha_registro TIMESTAMP,\r\nTipo_Usuario FLOAT NOT NULL,\r\nEstado_Acceso TINYINT(1) NOT NULL \r\n)', '2021-07-04 15:25:46'),
(3, 'Frio', 'CREATE TABLE Frio (\r\nIdT INT(6) AUTO_INCREMENT PRIMARY KEY,\r\nNombres VARCHAR(50) NOT NULL,\r\nApellidos VARCHAR(50) NOT NULL,\r\nCorreo_electronico VARCHAR(50),\r\nCelular VARCHAR(10),\r\nMensaje TEXT,\r\nFecha_nacimiento DATETIME NOT NULL,\r\nFecha_registro TIMESTAMP,\r\nTipo_Usuario FLOAT NOT NULL,\r\nEstado_Acceso TINYINT(1) NOT NULL \r\n)', '2021-07-04 15:29:17'),
(4, 'TEST', 'CREATE TABLE TEST (\r\nIdT INT(6) AUTO_INCREMENT PRIMARY KEY,\r\nNombres VARCHAR(50) NOT NULL,\r\nApellidos VARCHAR(50) NOT NULL,\r\nCorreo_electronico VARCHAR(50),\r\nCelular VARCHAR(10),\r\nMensaje TEXT,\r\nFecha_nacimiento DATETIME NOT NULL,\r\nFecha_registro TIMESTAMP,\r\nTipo_Usuario FLOAT NOT NULL,\r\nEstado_Acceso TINYINT(1) NOT NULL \r\n)', '2021-07-04 22:40:15'),
(5, 'TEST', 'CREATE TABLE TEST (\r\nIdT INT(6) AUTO_INCREMENT PRIMARY KEY,\r\nNombres VARCHAR(50) NOT NULL,\r\nApellidos VARCHAR(50) NOT NULL,\r\nCorreo_electronico VARCHAR(50),\r\nCelular VARCHAR(10),\r\nMensaje TEXT,\r\nFecha_nacimiento DATETIME NOT NULL,\r\nFecha_registro TIMESTAMP,\r\nTipo_Usuario FLOAT NOT NULL,\r\nEstado_Acceso TINYINT(1) NOT NULL \r\n)', '2021-07-04 22:40:22'),
(6, 'TEST2', 'CREATE TABLE TEST (\r\nIdT INT(6) AUTO_INCREMENT PRIMARY KEY,\r\nNombres VARCHAR(50) NOT NULL,\r\nApellidos VARCHAR(50) NOT NULL,\r\nCorreo_electronico VARCHAR(50),\r\nCelular VARCHAR(10),\r\nMensaje TEXT,\r\nFecha_nacimiento DATETIME NOT NULL,\r\nFecha_registro TIMESTAMP,\r\nTipo_Usuario FLOAT NOT NULL,\r\nEstado_Acceso TINYINT(1) NOT NULL \r\n)', '2021-07-04 22:40:29'),
(7, 'TEST', 'CREATE TABLE TEST (\r\nIdT INT(6) AUTO_INCREMENT PRIMARY KEY,\r\nNombres VARCHAR(50) NOT NULL,\r\nApellidos VARCHAR(50) NOT NULL,\r\nCorreo_electronico VARCHAR(50),\r\nCelular VARCHAR(10),\r\nMensaje TEXT,\r\nFecha_nacimiento DATETIME NOT NULL,\r\nFecha_registro TIMESTAMP,\r\nTipo_Usuario FLOAT NOT NULL,\r\nEstado_Acceso TINYINT(1) NOT NULL \r\n)', '2021-07-05 12:41:05'),
(8, 'TEST', 'CREATE TABLE TEST (\r\nIdT INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,\r\nNombres VARCHAR(50) NOT NULL,\r\nApellidos VARCHAR(50) NOT NULL,\r\nCorreo_electronico VARCHAR(50),\r\nCelular VARCHAR(10),\r\nMensaje TEXT,\r\nFecha_nacimiento DATETIME NOT NULL,\r\nFecha_registro TIMESTAMP,\r\nTipo_Usuario FLOAT NOT NULL,\r\nEstado_Acceso TINYINT(1) NOT NULL \r\n)', '2021-07-08 17:35:05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Tipos`
--

DROP TABLE IF EXISTS `Tipos`;
CREATE TABLE IF NOT EXISTS `Tipos` (
  `Tipo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Descripcion` text COLLATE utf8_unicode_ci NOT NULL,
  `Relacion` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  PRIMARY KEY (`Tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Tipos`
--

INSERT INTO `Tipos` (`Tipo`, `Descripcion`, `Relacion`, `Estado`) VALUES
('Adjective', 'Class of word that accompanies the noun to express a quality of the thing designated by it or to determine or limit its extension.', '', 1),
('Adverb', 'An invariable word that modifies a verb, an adjective, another adverb or a whole period; they can indicate place, time, mode, quantity, affirmation, negation, doubt and other nuances.', '', 1),
('Adverse', 'but, otherwise, even if', 'Conjunction', 1),
('amount', 'more', 'Adverb', 1),
('Article', 'Written text that has its own entity and is published together with other texts in a newspaper, magazine or book.', '', 1),
('Common', 'Dog', 'Name', 1),
('Comparative', 'equality, superiority, inferiority', 'Adjective', 1),
('Concrete', 'plate', 'Name', 1),
('Conjunction', 'A conjunction is a word or set of them that links propositions, phrases or words. It constitutes one of the kinds of links. It should not be confused with discourse markers, higher order links that join texts, and not words, phrases or sentences.', '', 1),
('Copulatives', 'and, e (español y, e)', 'Conjunction', 1),
('Demonstrative', 'this that that that\r\nthese those those\r\nthese those those', 'Article', 1),
('Determinants', 'A determinant is a morpheme or word that, being adjacent to a noun phrase, forms with it a determining phrase, fulfilling the function of specializing or quantifying it.', '', 1),
('Determined', 'the', 'Article', 1),
('Distributive', 'well, already, be, (ora Español)', 'Conjunction', 1),
('Doubt', 'maybe', 'Adverb', 1),
('Indeterminate', 'one, one, ones', 'Article', 1),
('Individual', 'sheep', 'Name', 1),
('Interjection', 'Word or expression that, pronounced in an exclamatory tone, expresses by itself a state of mind or captures the attention of the listener; are written between exclamation marks.', '', 1),
('Mode', 'So', 'Adverb', 1),
('Name', 'The name is the designation or verbal designation (non-verbal names are studied by iconology and iconography) that is given to a person, animal, thing, or tangible or intangible, concrete or abstract concept, to distinguish it from others.', '', 1),
('Noun', 'It is called the class of words that are used to designate beings, entities or objects', '', 1),
('Numerals', 'cardinals: one, two, three\r\n\r\nordinals: quint, sixth', 'Article', 1),
('Own self', 'Jimmy', 'Name', 1),
('Place', 'here', 'Adverb', 1),
('Positive', 'easy, White', 'Adjective', 1),
('Possessive', 'my, mine, mine, our\r\nyou, yours, yours, yours\r\nhis, his, his, hers', 'Article', 1),
('Preposition', 'An invariant word that is used to establish a dependency relationship between two or more words; the one that follows the preposition works as a complement; the type of relationship that is established varies according to the preposition.', '', 1),
('Pronoun', 'Word that is used to designate a thing without using its name, common or proper.', '', 1),
('Superlative', 'relative, the most absolute', 'Adjective', 1),
('Time', 'today', 'Adverb', 1),
('Tradeoffs', 'o, u (español)', 'Conjunction', 1),
('Undefined', 'one, one, ones', 'Article', 1),
('Verb', 'Class of word with which actions, processes, states or existence that affect people or things are expressed; has variation of time, aspect, mode, voice, number and person and functions as the core of the predicate.', '', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuarios`
--

DROP TABLE IF EXISTS `Usuarios`;
CREATE TABLE IF NOT EXISTS `Usuarios` (
  `IdU` int(11) NOT NULL AUTO_INCREMENT,
  `Nombres` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Apellidos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Correo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Pais` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Pass` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `Movil` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `Fecha` datetime NOT NULL,
  `Msj` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Terminos` int(11) NOT NULL,
  `Politicas` int(11) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Avatar` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Current_session` int(11) NOT NULL,
  `Online` int(11) NOT NULL,
  PRIMARY KEY (`IdU`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Usuarios`
--

INSERT INTO `Usuarios` (`IdU`, `Nombres`, `Apellidos`, `Correo`, `Pais`, `Pass`, `Movil`, `Fecha`, `Msj`, `Estado`, `Terminos`, `Politicas`, `Tipo`, `Avatar`, `Current_session`, `Online`) VALUES
(1, 'Danara', 'Sanz', 'admin@arana.com', 'México', 'us1317mx@', '9611772089', '2021-06-01 09:28:43', '', 1, 1, 1, 1, 'user3.jpg', 2, 1),
(2, 'Jimmy', 'Villatoro', 'jimmyvillatoro77@gmail.com', 'México', 'us1317mx@', '9611772089', '2021-06-01 09:28:43', '', 1, 1, 1, 1, 'user5.jpg', 3, 1),
(3, 'Maria', 'Boanerges', 'maria@arana.com', 'Mexico', 'us1317mx@', '9611772089', '2021-07-13 11:32:20', '', 1, 1, 1, 0, 'user3.jpg', 2, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
