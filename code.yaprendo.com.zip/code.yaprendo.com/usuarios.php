<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Arana-Consulting</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;1,100&display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700&family=Raleway:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
      <link rel="stylesheet" type="text/css" href="css/style.css">
     <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
   </head>

<--- CHAT ---->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/css/font-awesome.min.css'>
<link href="css/stylechat.css" rel="stylesheet" id="bootstrap-css">
<script src="js/chat.js"></script>



<?php
include 'dat/cdb/db.php';
$IdE = utf8_decode($_GET['IdE']);
$IdU = utf8_decode($_GET['IdU']);
$Sesion = utf8_decode($_GET['Sesion']);
$resultado=mysqli_query($db_connection, "SELECT IdU, Nombres, Apellidos, Fecha FROM Usuarios  WHERE IdU = '".$IdU."' ");

while ($row =mysqli_fetch_array($resultado)) {
     $IdUx=$row[IdU];  
   	 $Nombres=$row[Nombres];
   	 $Apellidos=$row[Apellidos];
   	 $Fecha=$row[Fecha];
  
   }
   

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>    


<style>
.modal-dialog {
    width: 400px;
    margin: 30px auto;	
}
</style>
 
      
   </head>
<body>

<div class="wrapper">
  <!-- header start -->
  <header class="header">

        <div class="header-main">
           <div class="logo">
               <img src="img/aranaConsulting-logo.png">
           </div>
           <div class="open-nav-menu">
              <span></span>
           </div>
           <div class="menu-overlay">
           </div>
           <!-- navigation menu start -->
           <nav class="nav-menu">
             <div class="close-nav-menu">
                <img src="img/close.svg" alt="close">
             </div>
             <ul class="menu">
               <li class="menu-item ">
                   <a href="index.html" style="color:brown;">HOME</a>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">PORTFOLIO  <i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design</a></li>
                       <li class="menu-item"><a href="#">Start Up Consulting</a></li>
                       <li class="menu-item"><a href="#">Business Investment</a></li>
                     
                   </ul>
                </li>
                
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">SERVICES<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Graphic Design & Marketing Development</a></li>
                       <li class="menu-item"><a href="#">
                        Start Up Consulting & Proof Techniques</a></li>
                   <li class="menu-item"><a href="#">Business Investment In Portugal</a></li>
                   </ul>
                </li>
                <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">ABOUT US<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Company History</a></li>
                       <li class="menu-item"><a href="#">Company Presentation</a></li>
                       <li class="menu-item"><a href="afiliados.php">register</a></li>
                       <li class="menu-item"><a href="login.html">login</a></li>
                   </ul>
                </li>
                  <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">FAQs<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">All FAQs</a></li>
                       <li class="menu-item"><a href="#">10 Important FAQ</a></li>
                      
                   </ul>
                </li>
               <li class="menu-item menu-item-has-children">
                   <a href="#" data-toggle="sub-menu">LEGALS<i class="fa fa-caret-down"></i></a>
                   <ul class="sub-menu">
                       <li class="menu-item"><a href="#">Cookies Policy</a></li>
                       <li class="menu-item"><a href="#">Data Protection</a></li>
                       <li class="menu-item"><a href="#">Privacy Policy</a></li>
                       <li class="menu-item"><a href="#">Terms and Condition</a></li>
                   </ul>
                </li>
                <li class="menu-item">
                   <a href="#">CONTACT US</a>
                </li>
                 <li class="menu-item">
                   <img src="img/england-image.jpg">
                </li>
                 <li class="menu-item">
                  <img src="img/germany.jpg">
                </li>
                 <li class="menu-item">
                   <img src="img/purtugal-flag.jpg">
                </li>
             </ul>
           </nav>
           <!-- navigation menu end -->
   
     </div>
  </header>
  <!-- header end -->
</div>
</div>

  <div id="slider">

    <img src="img/home-slider-image.jpg">
    <div class="slider-text" data-aos="fade-up"><h1 style="  font-family: 'Montserrat', sans-serif;">START-UP WORLD</h1>
      <h2 style="  font-family: 'Montserrat', sans-serif;">working for your future</h2><a href="http://consulting.aranath-zenitram.eu/company-presentation/">Read More</a></div>
      <!--<img src="img/home-slider-image.jpg">
        <img src="img/home-slider-image.jpg">-->

</div>
<div class="social-links" >
  <div class="slide-toggle arrow-stickynav">
    <img src="img/hide-social.png">
  </div>
    <div class="box">
      <div class="exhibitor-login">
            <a href="">Contact</a>
        </div>
        <div class="exhibitor-login exhibitor-pro">
            <a href="">Promotions</a>
        </div>
        <div class="social-links-body">
        <div class="menu-fixed-social-navigation-container">
          <ul id="menu-fixed-social-navigation" class="menu">
            <li id="menu-item-305" class="facebook-fix "><a target="_blank" rel="noopener noreferrer" href="#">Facebook</a></li>
           <li id="menu-item-306" class="instagram-fix"><a target="_blank" rel="noopener noreferrer" href="#">Instagram</a></li>
           <li id="menu-item-307" class="linked-in-fix"><a target="_blank" rel="noopener noreferrer" href="#">Linked In</a></li>
           <li id="menu-item-308" class="whatsapp-fix"><a target="_blank" rel="noopener noreferrer" href="#">WhatsApp</a></li>
           </ul>
         </div>   
              </div>

</div>
</div>
<script>
    var $ = jQuery;
        $(document).ready(function(){
    $(".slide-toggle").click(function(){
        $(".box").animate({
        width: "toggle"
        });
    });
    });
</script>

 


<div class="Currency-bg">
  <div class="container">
    <div class="row">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="abouttitle">
          <h2>USER  : <?php echo $Nombres; ?> <?php echo $Apellidos; ?></h2>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Currency -->
<div class="Currency">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="titlepage">
            
          <h2>AFFILIATES<strong class="cur"></strong></h2>
          <p><a href="Affiliatesadd2.php?IdU=<?php echo $IdU; ?>">Register</a></p>
     
            
          <h2>RESELLER<strong class="cur"></strong></h2>
          <p><a href="Reselleradd2.php?IdU=<?php echo $IdU; ?>">Register</a></p>
      
    
          <h2>REGISTER YOUR <strong class="cur">COMPANY</strong></h2>
          <p>You can share products and programs available in your company thanks to our customized linking tools and increase your sales.</p>
          <p><a href="Business_Legal_Entityadd2.php?IdU=<?php echo $IdU; ?>">Register</a></p>
       
         
          
          <h2>THE COMPANY REGISTERS ITS PRODUCTS <strong class="cur">MARKETING</strong></h2>
          <p>These are the products or services of your company.</p>
          <p><a href="Productsadd2.php?IdU=<?php echo $IdU; ?>">Register</a></p>
         
         
          <h2>THE COMPANY REGISTERS ITS GRAPHIC ELEMENTS <strong class="cur">MARKETING</strong></h2>
          <p>These are the graphics of the products.</p>
          <p><a href="Graphic_elementsadd2.php?IdU=<?php echo $IdU; ?>">Register</a></p>
         
         

      </div>
    </div>


	
<div class="container">		
	<h1>Live Chat</h1>		
	<br>		
	<?php if(isset($_SESSION['IdU']) && $_SESSION['IdU']) { ?> 	
		<div class="chat"> 
			<div id="frame">		
				<div id="sidepanel">
					<div id="profile">
					<?php
					include ('Chat.php');
					$chat = new Chat();
					$loggedUser = $chat->getUserDetails($_SESSION['IdU']);
					echo '<div class="wrap">';
					$currentSession = '';
					foreach ($loggedUser as $user) {
						$Current_session = $user['Current_session'];
						echo '<img id="profile-img" src="userpics/'.$user['Avatar'].'" class="online" alt="" />';
						echo  '<p>'.$user['Correo'].'</p>';
							echo '<i class="fa fa-chevron-down expand-button" aria-hidden="true"></i>';
							echo '<div id="status-options">';
							echo '<ul>';
								echo '<li id="status-online" class="active"><span class="status-circle"></span> <p>Online</p></li>';
								echo '<li id="status-away"><span class="status-circle"></span> <p>Ausente</p></li>';
								echo '<li id="status-busy"><span class="status-circle"></span> <p>Ocupado</p></li>';
								echo '<li id="status-offline"><span class="status-circle"></span> <p>Desconectado</p></li>';
							echo '</ul>';
							echo '</div>';
							echo '<div id="expanded">';			
							echo '<a href="logout.php">Salir</a>';
							echo '</div>';
					}
					echo '</div>';
					?>
					</div>
					<div id="search">
						<label for=""><i class="fa fa-search" aria-hidden="true"></i></label>
						<input type="text" placeholder="Buscar Contactos..." />					
					</div>
					<div id="contacts">	
					<?php
					echo '<ul>';
					$chatUsers = $chat->chatUsers($_SESSION['IdU']);
					foreach ($chatUsers as $user) {
						$status = 'offline';						
						if($user['Online']) {
							$status = 'online';
						}
						$activeUser = '';
						if($user['IdU'] == $Current_session) {
							$activeUser = "active";
						}
						echo '<li id="'.$user['IdU'].'" class="contact '.$activeUser.'" data-touserid="'.$user['IdU'].'" data-tousername="'.$user['Correo'].'">';
						echo '<div class="wrap">';
						echo '<span id="status_'.$user['IdU'].'" class="contact-status '.$status.'"></span>';
						echo '<img src="userpics/'.$user['Avatar'].'" alt="" />';
						echo '<div class="meta">';
						echo '<p class="name">'.$user['Correo'].'<span id="unread_'.$user['IdU'].'" class="unread">'.$chat->getUnreadMessageCount($user['IdU'], $_SESSION['IdU']).'</span></p>';
						echo '<p class="preview"><span id="isTyping_'.$user['IdU'].'" class="isTyping"></span></p>';
						echo '</div>';
						echo '</div>';
						echo '</li>'; 
					}
					echo '</ul>';
					?>
					</div>
					<div id="bottom-bar">	
						<button id="addcontact"><i class="fa fa-user-plus fa-fw" aria-hidden="true"></i> <span>Agregar Contactos</span></button>
						<button id="settings"><i class="fa fa-cog fa-fw" aria-hidden="true"></i> <span>Configuracion</span></button>					
					</div>
				</div>			
				<div class="content" id="content"> 
					<div class="contact-profile" id="userSection">	
					<?php
					$userDetails = $chat->getUserDetails($Current_session);
					foreach ($userDetails as $user) {										
						echo '<img src="userpics/'.$user['Avatar'].'" alt="" />';
							echo '<p>'.$user['Correo'].'</p>';
							echo '<div class="social-media">';
								echo '<i class="fa fa-facebook" aria-hidden="true"></i>';
								echo '<i class="fa fa-twitter" aria-hidden="true"></i>';
								 echo '<i class="fa fa-instagram" aria-hidden="true"></i>';
							echo '</div>';
					}	
					?>						
					</div>
					<div class="messages" id="conversation">		
					<?php
					echo $chat->getUserChat($_SESSION['IdU'], $Current_session);						
					?>
					</div>
					<div class="message-input" id="replySection">				
						<div class="message-input" id="replyContainer">
							<div class="wrap">
								<input type="text" class="chatMessage" id="chatMessage<?php echo $Current_session; ?>" placeholder="Escribe tu mensaje..." />
								<button class="submit chatButton" id="chatButton<?php echo $Current_session; ?>"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>	
							</div>
						</div>					
					</div>
				</div>
			</div>
		</div>
	<?php } else { ?>
		<br>
		<br>
		<strong><a href="login.html"><h3>Acceder al Chat</h3></a></strong>		
	<?php } ?>
	<br>
	<br>	  

	



  </div>
</div>
<!-- end Currency --> 

<div class="main-footer">
 <footer class="footer">
     <div class="container">
      <div class="row">
        <div class="footer-col">
          <h4>INFORMATION</h4>
          <ul>
            <li><a href="#">HOME</a></li>
            <li><a href="#">PORTFOLIO</a></li>
            <li><a href="#">SERVICES</a></li>
            <li><a href="#">CONTACT US</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>HOW CAN WE HELP?</h4>
          <ul>
            <li><a href="#">ALL FAQs</a></li>
            <li><a href="#">TERMS & CONDITIONS</a></li>
            <li><a href="#">PRIVACY POLICY</a></li>
            <li><a href="#">COOKIES POLICY</a></li>
            <li><a href="#">DATA PROTECTION</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>CONTACT US</h4>
          <ul>
            <li style="color:white;font-weight:bold;  font-family: 'Raleway', sans-serif; ">ADDRESS</li>
            <li style="color:white;font-weight:bold;text-transform: uppercase;   
            font-family:'Raleway', sans-serif;"> Danara Martinez Saiz
Calçada do Carrascal  <span class="num">180, 1 </span>ESQ 
            <span class="num">1900 - 
            135</span> Lisboa / Portugal
            </li>
          </ul>
        </div>
        <div class="footer-col">
         
          <div class="company_logo">
              <img src="img/Aranath.png" width="200px" >
          </div>
        </div>
      </div>
     </div>

  </footer>
  <div class="second-footer">
    <p>©COPYRIGHT | ARANATH-ZENITRAM <span class="num">2019.</span></p>
  </div>
</div>


<script src="js/script.js"></script>
<script src="js/script1.js"></script>
 <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
  <script>
    AOS.init();
  </script>
</body>
</html>