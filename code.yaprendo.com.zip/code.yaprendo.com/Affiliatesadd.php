<?php 
include 'dat/cdb/db.php'; 

$IdU = $_REQUEST['IdU'];
$IdS = $_REQUEST['IdS'];
$IdA = $_REQUEST['IdA'];


 

$First_Name= $_REQUEST['First_Name'];
$Last_Name= $_REQUEST['Last_Name'];
$Date_of_Birth= $_REQUEST['Date_of_Birth'];
$Nationality= $_REQUEST['Nationality'];
$Email_ID= $_REQUEST['Email_ID'];
$Contact_Number= $_REQUEST['Contact_Number'];
$Optional_Contact_Number= $_REQUEST['Optional_Contact_Number'];
$City= $_REQUEST['City'];
$Post_code= $_REQUEST['Post_code'];
$Country= $_REQUEST['Country'];
$Address= $_REQUEST['Address'];
$Passport_Number= $_REQUEST['Passport_Number'];
$Profession= $_REQUEST['Profession'];
$Estado= 1;
$Fecha= $_REQUEST['Fecha'];
$Terminos= 1;
$Politicas= 1;

 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM Affiliates WHERE First_Name LIKE '".$First_Name."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: usuarios.php?IdU=$IdU&IdS=$IdS&IdA=$IdA&IdU=$IdU"); 
} else {  
$insert_value ="INSERT INTO Affiliates(First_Name, Last_Name, Date_of_Birth, Nationality, Email_ID, Contact_Number, Optional_Contact_Number, City, Post_code, Country, Address, Passport_Number, Profession, Estado, Fecha, Terminos, Politicas, IdU) VALUES ( '".$First_Name."',  '".$Last_Name."',  '".$Date_of_Birth."',  '".$Nationality."',  '".$Email_ID."',  '".$Contact_Number."',  '".$Optional_Contact_Number."',  '".$City."',  '".$Post_code."',  '".$Country."',  '".$Address."',  '".$Passport_Number."',  '".$Profession."',  '".$Estado."',  '".$dt."',  '".$Terminos."',  '".$Politicas."',  '".$IdU."')";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT IdA  FROM  Affiliates  WHERE First_Name = '".$First_Name."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $IdA =$row['IdA']; 
 header("Location: usuarios.php?IdU=$IdU&IdA=$IdA"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>