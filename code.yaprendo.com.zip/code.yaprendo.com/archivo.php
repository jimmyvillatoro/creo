<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>Arana - Afiliados</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">
<!-- bootstrap css -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      <script src="lib/jquery-3.6.0.min.js"></script>
      
<script>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   'salida2.php',
                  type:  'post',
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>

<?php
	
include 'dat/cdb/db.php';
$IdE = utf8_decode($_GET['IdE']);
$IdO = utf8_decode($_GET['IdO']);
$IdU = utf8_decode($_GET['IdU']);
$Sesion = utf8_decode($_GET['Sesion']);

$IdE = $_REQUEST['IdE'];
$IdO = $_REQUEST['IdO'];
$IdA = $_REQUEST['IdA'];
$IdU = $_REQUEST['IdU'];
$Sesion = $_REQUEST['Sesion'];

$resultado=mysqli_query($db_connection, "SELECT IdU, Nombres, Apellidos, Fecha FROM Usuarios  WHERE IdU = '".$IdU."' ");

while ($row =mysqli_fetch_array($resultado)) {
     $IdUx=$row[IdU];  
   	 $Nombres=$row[Nombres];
   	 $Apellidos=$row[Apellidos];
   	 $Fecha=$row[Fecha];
  
   }
   
 $result=mysqli_query($db_connection, "SELECT Codigodebarra, Nombre, Descripcion, Preciodelobjeto FROM Objetodemarketing  WHERE IdO = '".$IdO."' ");

while ($row1 =mysqli_fetch_array($result)) {
     $c=$row1[Codigodebarra];  
   	 $n=$row1[Nombre];
   	 $d=$row1[Descripcion];
   	 $p=$row1[Preciodelobjeto];
  
   }  


if ($IdUx!=$IdU || $Fecha != $Sesion) {
    header("Location: sesion.php");
    die();
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

     
      
</head>
<!-- body -->
<body class="main-layout">
<!-- loader  -->
<div class="loader_bg">
  <div class="loader"><img src="images/loading.gif" alt="#" /></div>
</div>
<!-- end loader --> 
<!-- header -->
<header> 
  <!-- header inner -->
  <div class="head-top">
    <div class="container">
      <div class="row">
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
          <div class="email"> <a href="#">Email : aranans@hotmail.com</a> </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
          <div class="icon"> <i> <a href="https://www.facebook.com/aranathzenitramfoodservices/"><img src="icon/facebook.png"></a></i> <i> <a href="#"><img src="icon/Twitter.png"></a></i> <i> <a href="https://www.instagram.com/danaramartinez/"><img src="icon/linkedin.png"></a></i> <i> <a href="#"><img src="icon/google+.png"></a></i> </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
          <div class="contact"> <a href="#">Contact :  +71  78908540</a> </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
        <div class="full">
          <div class="center-desk">
            <div class="logo"> <a href="index.html"><img src="images/aranaConsulting-logo.png" alt="#"></a> </div>
          </div>
        </div>
      </div>
      <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
        <div class="menu-area">
          <div class="limit-box">
            <nav class="main-menu">
              <ul class="menu-area-main">
         <li class="active"> <a href="index2.php">HOME</a> </li>
                <li class="active"> <a href="services.php">SERVICES</a> </li>
                <li> <a href="aboutus.php">ABOUT US</a> </li>
                <li> <a href="team.php">TEAM</a> </li>
                <li> <a href="faqs.php">FAQS</a> </li>
                <li> <a href="legal.php">LEGAL</a> </li>
                <li> <a href="contact.php">CONTACT US</a> </li>
                <li> <a href="#"><img src="images/search_icon.png" alt="#" /></a> </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end header inner --> 
</header>
<!-- end header -->

<div class="Currency-bg">
  <div class="container">
    <div class="row">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="abouttitle">
          <h2>ARCHIVO DE MARKETING</h2>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Currency -->
<div class="Currency">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="titlepage">
          <h2>Empresa de: <strong class="cur"><?php echo $Nombres; ?> <?php echo $Apellidos; ?></strong></h2>
 <p>Te damos la bienvenida a uno de los programas de marketing de Afiliados más grandes del mundo. </p>
          <span><img src="images/boder.png" alt="img"/> </span> </div>
      </div>
    </div>
    
    <h1>Buscar archivos de marketing por descripcion</h1>
<ul>
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" placeholder="Buscar" aria-label="Buscar" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2">Buscar</span>
        </div>
</div>
<div class="salida"></div>

</ul>
				

      <div class="col-md-12">
        <div class="titlepage">
          <h2>Objeto: <strong class="cur"><?php echo $c; ?> <?php echo $n; ?> - <?php echo $d; ?> $<?php echo $p; ?></strong></h2>
      </div>
    </div>	

<h3>Registration</h3>

						<ul>

<li> 

        <p>
            

           
     

            <form action="pregarc.php"  method="POST">
                
                
<input type="hidden" name="IdU" value="<?php echo utf8_decode($_GET['IdU']); ?>">
<input type="hidden" name="Sesion" value="<?php echo utf8_decode($_GET['Sesion']); ?>">
<input type="hidden" name="IdE" value="<?php echo utf8_decode($_GET['IdE']); ?>">
<input type="hidden" name="IdO" value="<?php echo utf8_decode($_GET['IdO']); ?>">

 
               
                
                    <div>
                    <div>
                        <input type="text" name="des" class="form-control" placeholder="Descripcion" class="form-input" required>
                    </div>
                   </div>




<div>

                    <div>
                    <input type="text" name="tip" class="form-control" placeholder="Tipo de archivo" class="form-input"     required>
                    </div>

                </div>




          

     <div >
          <div >
            
           <button type="submit" class="btn btn-success">subscribe</button>
     
          </div>
        </div>

       

            </form>
            
           


  </div>
</div>
<!-- end Currency --> 

<!-- footer -->
<footer>
  
  <div class="copyright">
    <div class="container">
      <p>Copyright 2019 All Right Reserved By <a href="http://html.design">Free html Templates</a></p>
    </div>
  </div>
</footer>
<!-- end footer --> 
<!-- Javascript files --> 
<script src="js/bootstrap.bundle.js"></script>
<script src="js/jquery.min.js"></script> 
<!-- sidebar --> 
<script src="js/custom.js"></script>
</body>
</html>