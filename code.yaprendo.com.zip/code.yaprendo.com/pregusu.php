<?php

include 'dat/cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];
$pai = $_REQUEST['pai'];

$avatar="user3.jpg";

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());
$dt= $date.' '. $time;

$resultado=mysqli_query($db_connection, "SELECT IdU FROM Usuarios WHERE Correo = '".$cor."' ");
if (mysqli_num_rows($resultado)>0)
{
header('Location: index.php?nom='.$nom.'& mov='.$mov.'&cor='.$cor.'');
 } else {





$insert_value = "INSERT INTO Usuarios (Nombres, Apellidos, Correo, Movil, Pass, Pais, Fecha, Estado, Terminos, Politicas, Avatar) VALUES ('".$nom."',  '".$ape."',  '".$cor."',  '".$mov."',  '".$pas."',  '".$pai."' ,  '".$dt."', 1, 1, 1, '".$avatar."')";



$retry_value = mysqli_query($db_connection,$insert_value);





$cuerpo='Nombre: '. $nom.'  Movil: '.$mov.'  Correo: '.$cor;



mail('soporte@yaprendo.com','ProyectoDan dale seguimiento->',$cuerpo,'ProyectoDan');



$resultado=mysqli_query($db_connection, "SELECT IdU FROM Usuarios  WHERE Nombres = '".$nom."' ");





while ($row =mysqli_fetch_array($resultado)) {

   	 $IdU=$row[IdU];

   }







header('Location: login.html');



}



mysqli_free_result($retry_value);

mysqli_close($db_connection);

?>

