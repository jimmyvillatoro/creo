<?php 
$servidor  =utf8_decode($_GET['server']); 
$usuario   =utf8_decode($_GET['user']);
$clave     =utf8_decode($_GET['pass']);
$basedatos =utf8_decode($_GET['db']);
$txt=$_GET['tabla'];


date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 

$Servidor= $servidor;
$Usuario= $usuario;
$Clave  =$clave  ;
$Basedatos= $basedatos;
$Tabla= $txt;
$Fecha= $dt;

$db_connection2 = mysqli_connect('localhost', 'yaprendo_test', 'us1317mx$', 'yaprendo_ProyectoDan') or die(mysql_error());
if (!$db_connection2) {
	die("Se ha podido conectar a la base de datos");
}else
	echo mysqli_connect_error($db_connection2);

$insert_value2 ="INSERT INTO Servidores( Servidor, Usuario, Clave, Basedatos, Tabla, Fecha) VALUES (  '".$Servidor."',  '".$Usuario."',  '".$Clave."',  '".$Basedatos."',  '".$Tabla."',  '".$Fecha."')";
$retry_value2 = mysqli_query($db_connection2,$insert_value2);
mysqli_free_result($retry_value2);


$db_connection = mysqli_connect($servidor, $usuario, $clave, $basedatos) or die(mysql_error());
if (!$db_connection) {
	die("Se ha podido conectar a la base de datos");
}else
	echo mysqli_connect_error($db_connection);

$consulta = "SELECT * FROM ".$txt;
$resultado=mysqli_query($db_connection, $consulta);

$info_campo = mysqli_fetch_fields($resultado);
$fila = mysqli_fetch_array($resultado);
$field_cnt = $resultado->field_count;


// INSERT INTO  
$cadena1="";
$sql = "INSERT INTO ".$txt."(";   $primary="";
$bus=0;
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.", ";
      if($bus==1)
      $bus=$valor->name;
      
      if($primary==""){
      $primary=$valor->name;
      $bus=1;
      }
   } 
   $myString = substr($cadena1, 0, -2);
  $sql.= $myString.")";
  $c="'";
  $p=".";
  $sql.=" VALUES (";
     foreach ($info_campo as $valor) {
      $cadena2.=' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
   $myString = substr($cadena2, 0, -2);
   $sql.=$myString.")";
   $insert_value =$sql;
   
   
$dir = "php/".$txt."/";
if (!file_exists($dir)) 
mkdir($dir, 0777, true);


 //------------------------------------------------------------------------------add 
 
//echo  'Archivo : '.$txt.'add.php listo';
   
$archivo = fopen($dir.$txt."add.php","w+b");
if( $archivo == false ) {
echo "Error al crear el archivo";
    }
    else
    {
        

fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include '../dat/cdb/db.php'; \r\n");
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, "\r\n");  
$c="'";
$frac1= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac1."\r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$bus.' LIKE '.$c.'".$'.$bus.'."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");


$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac3."\r\n");
$frac4='header("Location: ../usuarios.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'");  ';

fwrite($archivo, " \r\n");
fwrite($archivo, $frac4."\r\n");
$frac5='} else {  ';
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, $frac5."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '$insert_value ="');
fwrite($archivo, $sql);
$frac6='";';
fwrite($archivo, $frac6."\r\n");
fwrite($archivo,"\r\n");
fwrite($archivo, "\r\n");
fwrite($archivo,'$retry_value = mysqli_query($db_connection,$insert_value);');
fwrite($archivo, "\r\n");
fwrite($archivo,"\r\n");

$frac7='$resultado=mysqli_query($db_connection, "SELECT '.$primary.'  FROM  '.$txt.'  WHERE '.$bus.' = '.$c.'".$'.$bus.'."'.$c.'" ); ';

fwrite($archivo, $frac7."\r\n");
fwrite($archivo, " \r\n");

$frac8=' while ($row =mysqli_fetch_array($resultado))   $'.$primary.' =$row['.$primary.' ]; ';
fwrite($archivo, $frac8."\r\n");
fwrite($archivo, " \r\n");

$frac9=' header("Location: ../usuarios.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'"); ';

fwrite($archivo, $frac9."\r\n");
fwrite($archivo, " \r\n");


$frac10='mysqli_free_result($retry_value);';

fwrite($archivo, $frac10."\r\n");
fwrite($archivo, "}\r\n");

$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}
//------------------------------------------------------------------------------add2
//echo  'Archivo : '.$txt.'add2.php listo';
   
    $archivo = fopen($dir.$txt."add2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title>
<meta name="keywords" content="">
<meta name="description: formulario de registro" content="">
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" />');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
   fwrite($archivo, '</head>
<!-- body -->
<body>
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
    
fwrite($archivo, '<h3>Registrarte</h3>
<form action="'.$txt.'add.php" method="POST">');
$s="$";

fwrite($archivo,"<input type='hidden' name=".$primary." value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'>");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


 foreach ($info_campo as $valor) {

    printf("Nombre:        %s\n", $valor->name);
    printf("Tabla:         %s\n", $valor->table);
    printf("Longitud máx.: %d\n", $valor->max_length);
    printf("Banderas:      %d\n", $valor->flags);
    printf("Tipo:          %d\n", $valor->type);
    fwrite($archivo, " \r\n");
    
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

//if($valor->flags==2 || $valor->flags==8 || $valor->flags==512 )
//fwrite($archivo, "<div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required>  </div>  \r\n");
//else
//fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required>  </div>  \r\n");
//min='1' max='5'

  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246  )//DECIMALES 
  fwrite($archivo, "<div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");


  if($valor->type == 7)//fechas
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
   if($valor->type == 10)
  fwrite($archivo, "<div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> ".$valor->name." </textarea> </div>  \r\n");
 

  if($valor->type == 253)//cadena
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");


  
   }
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
   fwrite($archivo, "<div>
             <button type='submit' class='btn btn-success'>Registrate</button>
             </div>
             </form> \r\n");
fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>
");
fwrite($archivo,"\r\n");

fwrite($archivo, "</body>
</html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------upd 
//echo  'Archivo : '.$txt.'upd.php listo';
   
    $archivo = fopen($dir.$txt."upd.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include '../dat/cdb/db.php'; \r\n");
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, "\r\n");  
$c="'";
$frac1= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac1."\r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");
$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, $frac3."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '$update_value ="');
//----------------------------UPDATE--------------------------------------------
$cadena1="";
 $c="'";
 $p=".";
$sql = "UPDATE ".$txt." SET ";   
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.'='.' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
  $myString = substr($cadena1, 0, -2);
  $sql.= $myString." ";
  $sql.='  WHERE   '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ; ';
fwrite($archivo, $sql);
fwrite($archivo, "\r\n");
fwrite($archivo,'$retry_value = mysqli_query($db_connection,$update_value );');
fwrite($archivo, "\r\n");
//-----------------------------UPDATE-------------------------------------------
$frac9=' header("Location: ../usuarios.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'"); ';
fwrite($archivo, $frac9."\r\n");
$frac10='mysqli_free_result($retry_value);';
fwrite($archivo, $frac10."\r\n");
$frac5='} else {  ';
fwrite($archivo, $frac5."\r\n");
$frac4='header("Location: ../usuarios.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'");  ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac4."\r\n");
fwrite($archivo, "}\r\n");
$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------upd3 
//echo  'Archivo : '.$txt.'upd.php listo';
   
    $archivo = fopen($dir.$txt."upd3.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include '../dat/cdb/db.php'; \r\n");
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, "\r\n");  
$c="'";
$frac1= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac1."\r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");
$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, $frac3."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '$update_value ="');
//----------------------------UPDATE--------------------------------------------
$cadena1="";
 $c="'";
 $p=".";
$sql = "UPDATE ".$txt." SET ";   
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.'='.' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
  $myString = substr($cadena1, 0, -2);
  $sql.= $myString." ";
  $sql.='  WHERE   '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ; ';
fwrite($archivo, $sql);
fwrite($archivo, "\r\n");
fwrite($archivo,'$retry_value = mysqli_query($db_connection,$update_value );');
fwrite($archivo, "\r\n");
//-----------------------------UPDATE-------------------------------------------
$frac9=' header("Location: '.$txt.'sel.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'"); ';
fwrite($archivo, $frac9."\r\n");
$frac10='mysqli_free_result($retry_value);';
fwrite($archivo, $frac10."\r\n");
$frac5='} else {  ';
fwrite($archivo, $frac5."\r\n");
$frac4='header("Location: '.$txt.'sel.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'");  ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac4."\r\n");
fwrite($archivo, "}\r\n");
$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------upd2
//echo  'Archivo : '.$txt.'upd2.php listo';
   
    $archivo = fopen($dir.$txt."upd2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de actualizacion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="styles.css" />
');

fwrite($archivo, " \r\n");
fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary = utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
    
fwrite($archivo, '<h3>Actualiza</h3>
<form action="'.$txt.'upd.php" method="POST">');
$s="$";
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']);?> '>");
fwrite($archivo,"\r\n");
 foreach ($info_campo as $valor) {
   /*fwrite($archivo,"<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' value='<?php echo $".$valor->name."; ?>' required>  </div> ");*/
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");



  if($valor->type == 7)//fechas
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div>  \r\n");
 

  if($valor->type == 253)//cadena
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");

    fwrite($archivo,"\r\n");
   }
   fwrite($archivo,"\r\n");
   fwrite($archivo,"<div> <button type='submit' class='btn btn-success'>actualiza</button> </div> </form>");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>");

fwrite($archivo, "</body>
</html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------del 
//echo  'Archivo : '.$txt.'del.php listo';
   
    $archivo = fopen($dir.$txt."del.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include '../dat/cdb/db.php'; \r\n");
       //REQUEST
 $Idx= "$"."Idx= $"."_REQUEST['Idx'];";
 fwrite($archivo,$Idx);       
 fwrite($archivo, "\r\n");        
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, "\r\n");  
$c="'"; $s="$";
$frac1= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac1."\r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$primary.' LIKE '.$c.'".'.$s.'Idx."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");
$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, $frac3."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '$delete_value ="');
//----------------------------DELETE--------------------------------------------
$cadena1="";
 $c="'";
 $p=".";
$sql = 'DELETE FROM '.$txt.' WHERE '.$primary.' LIKE '.$c.'".'.$s.'Idx."'.$c.'"; ';   
fwrite($archivo, $sql);
fwrite($archivo, "\r\n");
fwrite($archivo,'$retry_value = mysqli_query($db_connection,$delete_value );');
fwrite($archivo, "\r\n");
//-----------------------------DELETE-------------------------------------------
$frac9=' header("Location: ../usuarios.php?'.$primary.'='.$c.'".'.$s.'Idx."'.$c.'"); ';
fwrite($archivo, $frac9."\r\n");
$frac10='mysqli_free_result($retry_value);';
fwrite($archivo, $frac10."\r\n");
$frac5='} else {  ';
fwrite($archivo, $frac5."\r\n");
$frac4='header("Location: ../usuarios.php?'.$primary.'='.$c.'".'.$s.'Idx."'.$c.'");  ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac4."\r\n");
fwrite($archivo, "}\r\n");
$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------del2
//echo  'Archivo : '.$txt.'del2.php listo';
   
    $archivo = fopen($dir.$txt."del2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de borrado" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="styles.css" />
');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    

fwrite($archivo, " <?php  \r\n");
fwrite($archivo, "$"."$primary = utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> <!-- body --> <body> <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
    
fwrite($archivo, '<h3>Borrar</h3>
<form action="'.$txt.'del.php" method="POST">');
$s="$";
fwrite($archivo, " \r\n");
/*fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'>");*/
fwrite($archivo, " \r\n");
fwrite($archivo,"<div><input type='text' name='Idx' class='form-control' placeholder='Id a Borrar' class='form-input' value='<?php echo  $".$primary."; ?>' required></div> ");
fwrite($archivo, " \r\n");                
fwrite($archivo,"<div> <button type='submit' class='btn btn-success'>Borrar</button> </div> 
</form>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>");

fwrite($archivo, "</body>
</html>");

fflush($archivo);
fclose($archivo);
}
/*
//------------------------------------------------------------------------------sel
//echo  'Archivo : '.$txt.'sel.php listo';
   
    $archivo = fopen($dir.$txt."sel.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
//<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">

');

fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$bus.' LIKE '.$c.'".$'.$bus.'."'.$c.'" );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '<h3>Seleccionar datos</h3>');



fwrite($archivo,  "<table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=".$field_cnt." style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr>");
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
 fwrite($archivo,  "</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<th><?php echo $".$valor->name."; ?></th>");
   fwrite($archivo,  " \r\n");
      }
fwrite($archivo, "</tr></table></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}

*/
//------------------------------------------------------------------------------sel
//echo  'Archivo : '.$txt.'sel.php listo';
   
    $archivo = fopen($dir.$txt."sel.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, '<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" /> ');
//<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");




fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th>");
  $s="$";
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }

  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
 fwrite($archivo, '<tr><form action="'.$txt.'upd3.php" method="POST">');
   fwrite($archivo,  " \r\n");
 
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']);?> '></tr>");
  fwrite($archivo,  " \r\n");

  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td>");  
     fwrite($archivo,  " \r\n");
   $uno++;
   }
   
 /*  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");*/
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<td><div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<td><div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type == 7)//fechas
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div></td>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<td><div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<td><div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<td><div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div></td>  \r\n");
 
  if($valor->type == 253)//cadena
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

   fwrite($archivo,  " \r\n");
      }
      
fwrite($archivo, "</form> \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   

fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."upd2.php?".$valor->name."=<?php echo $".$valor->name."; ?>><?php echo $".$valor->name."; ?> actualizar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."del2.php?".$valor->name."=<?php echo $".$valor->name."; ?>><?php echo $".$valor->name."; ?> borrar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------sel2
//echo  'Archivo : '.$txt.'sel2.php listo';
   
    $archivo = fopen($dir.$txt."sel2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" /> ');
//<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");




fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------sel3
//echo  'Archivo : '.$txt.'sel3.php listo';
   
    $archivo = fopen($dir.$txt."sel3.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" /> ');
//<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th>");
  $s="$";
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }

  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
 fwrite($archivo, '<tr><form action="'.$txt.'upd3.php" method="POST">');
   fwrite($archivo,  " \r\n");
 
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']);?> '></tr>");
  fwrite($archivo,  " \r\n");

  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td>");  
     fwrite($archivo,  " \r\n");
   $uno++;
   }
   
 /*  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");*/
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<td><div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<td><div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type == 7)//fechas
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div></td>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<td><div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<td><div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<td><div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div></td>  \r\n");
 
  if($valor->type == 253)//cadena
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

   fwrite($archivo,  " \r\n");
      }
      
fwrite($archivo, "</form> \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   

fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------sel4
//echo  'Archivo : '.$txt.'sel4.php listo';
   
    $archivo = fopen($dir.$txt."sel4.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" /> ');
//<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."upd2.php?".$valor->name."=<?php echo $".$valor->name."; ?>><?php echo $".$valor->name."; ?> actualizar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------sel5
//echo  'Archivo : '.$txt.'sel5.php listo';
   
    $archivo = fopen($dir.$txt."sel5.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" /> ');
//<link rel="stylesheet" type="text/css" media="screen" href="../dat/css/style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."del2.php?".$valor->name."=<?php echo $".$valor->name."; ?>><?php echo $".$valor->name."; ?> borrar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo, "<a href='../usuarios.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------ser

//echo  'Archivo : '.$txt.'ser.php listo';
   
    $archivo = fopen($dir.$txt."ser.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Buscar" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="styles.css" />
');

fwrite($archivo, '
<script src="jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "'.$txt.'ser2.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})

</script>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");   
fwrite($archivo, " <?php  \r\n");
fwrite($archivo, "$"."$bus = utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '
<h2>busca por <strong class="cur">Nombre</strong></h2>
<form action="'.$txt.'ser.php" method="POST">
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $'.$bus.'; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>
 <p><a href="../usuarios.php?'.$primary.'='.$c.'$'.$primary.$c.'; ?>">Regresar</a></p> ');
	
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------ser2

//echo  'Archivo : '.$txt.'ser2.php listo';
   
    $archivo = fopen($dir.$txt."ser2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

$c="'";
fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, '$html="";');
fwrite($archivo, " \r\n");
fwrite($archivo, '$busca= $_REQUEST["txtbusca"];');
fwrite($archivo, " \r\n");
fwrite($archivo, '$html.="<h2><strong class='.$c.'cur'.$c.'>Resultados</h2>";');
fwrite($archivo, " \r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$bus.' LIKE '.$c.'".$busca."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");
$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac3."\r\n");

fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row

foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
     fwrite($archivo, "$"."html.= '<p><a href=".$txt."sel3.php?".$valor->name."=".$c.$p."$".$valor->name.$p.$c.">".$c.$p."$".$valor->name.$p.$c."</a></p></b>';");
     fwrite($archivo, " \r\n");
   } 
fwrite($archivo, " } \r\n");

fwrite($archivo, '$html.="</b>";');
fwrite($archivo, " \r\n");
fwrite($archivo, 'echo $html;');
fwrite($archivo, "\r\n");
fwrite($archivo, " } \r\n");
fwrite($archivo, 'else
echo 
"Is not found";');
fwrite($archivo, "\r\n");
$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------copy
echo "</br>";

copy('jquery-3.6.0.min.js', $dir.'/jquery-3.6.0.min.js');

$dir3 = "php/".$txt."/tablecloth";
if (!file_exists($dir3)) 

mkdir($dir3, 0777, true);
copy('tablecloth/tablecloth.css','php/'.$txt.'/tablecloth/tablecloth.css');
copy('tablecloth/tablecloth.js','php/'.$txt.'/tablecloth/tablecloth.js');
copy('tablecloth/tr_back.gif','php/'.$txt.'/tablecloth/tr_back.gif');


//------------------------------------------------------------------------------ ZIP 

/* primero creamos la función que hace la magia
 * esta funcion recorre carpetas y subcarpetas
 * añadiendo todo archivo que encuentre a su paso
 * recibe el directorio y el zip a utilizar 
 */
function agregar_zip($dir, $zip) {
  //verificamos si $dir es un directorio
  if (is_dir($dir)) {
    //abrimos el directorio y lo asignamos a $da
    if ($da = opendir($dir)) {
      //leemos del directorio hasta que termine
      while (($archivo = readdir($da)) !== false) {
        /*Si es un directorio imprimimos la ruta
         * y llamamos recursivamente esta función
         * para que verifique dentro del nuevo directorio
         * por mas directorios o archivos
         */
        if (is_dir($dir . $archivo) && $archivo != "." && $archivo != "..") {
          echo "<strong>Creando directorio: $dir$archivo</strong><br/>";
          agregar_zip($dir . $archivo . "/", $zip);
 
          /*si encuentra un archivo imprimimos la ruta donde se encuentra
           * y agregamos el archivo al zip junto con su ruta 
           */
        } elseif (is_file($dir . $archivo) && $archivo != "." && $archivo != "..") {
          echo "Agregando archivo: $dir$archivo <br/>";
          $zip->addFile($dir . $archivo, $dir . $archivo);
        }
      }
      //cerramos el directorio abierto en el momento
      closedir($da);
    }
  }
}
 
//fin de la función
//creamos una instancia de ZipArchive
$zip = new ZipArchive();
 
/*directorio a comprimir
 * la barra inclinada al final es importante
 * la ruta debe ser relativa no absoluta
 */
$dir = $dir;
 
//ruta donde guardar los archivos zip, ya debe existir
$rutaFinal = "php/";
 
if(!file_exists($rutaFinal)){
  mkdir($rutaFinal);
}
 
$archivoZip = $txt.".zip";
 
if ($zip->open($archivoZip, ZIPARCHIVE::CREATE) === true) {
  agregar_zip($dir, $zip);
  $zip->close();
 
  //Muevo el archivo a una ruta
  //donde no se mezcle los zip con los demas archivos
  rename($archivoZip, "$rutaFinal/$archivoZip");
 
  //Hasta aqui el archivo zip ya esta creado
  //Verifico si el archivo ha sido creado
  if (file_exists($rutaFinal. "/" . $archivoZip)) {
    echo "Proceso Finalizado!! <br/><br/>
                Descargar: <a href='$rutaFinal/$archivoZip'>$archivoZip</a>";
  } else {
    echo "Error, archivo zip no ha sido creado!!";
  }
}
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------indice begin

$consulta = "SELECT * FROM ".$txt;
$resultado=mysqli_query($db_connection, $consulta);
while ($row =mysqli_fetch_array($resultado)){   
 $dato=$row[$primary];
 $dato2=$row[$bus];
}


echo "<br><a href='php/".$txt."/index.php'>Ver INDEX</a>";


//------------------------------------------------------------------------------indice end

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>