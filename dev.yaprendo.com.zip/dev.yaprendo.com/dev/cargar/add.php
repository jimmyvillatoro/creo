<?php
include '../../dat/cdb/db.php';

$IdU = $_REQUEST['IdU'];
$Sesion = $_REQUEST['Sesion'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());
$dt= $date.' '. $time;

$txt="Reseller"; 
$consulta = "SELECT * FROM ".$txt;
$resultado=mysqli_query($db_connection, $consulta);

$info_campo = mysqli_fetch_fields($resultado);
$fila = mysqli_fetch_array($resultado);
$field_cnt = $resultado->field_count;

//REQUEST
   foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     echo $recibe;
   } 
   
echo "</br>";
echo "</br>";

// INSERT INTO  
$cadena1="";
$sql = "INSERT INTO ".$txt."(";   
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.", ";
   } 
   $myString = substr($cadena1, 0, -2);
  $sql.= $myString.")";
  $c="'";
  $p=".";
  $sql.=" VALUES (";
     foreach ($info_campo as $valor) {
      $cadena2.=' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
   $myString = substr($cadena2, 0, -2);
   $sql.=$myString.");";
   $insert_value =$sql;
 
   echo  $sql;

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>