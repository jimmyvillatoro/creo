<?php

class F 
{
protected $B = 0;

function s(){
include '../../dat/cdb/db.php';
 $txt =  $_POST['txt'];

$consulta = "SELECT * FROM ".$txt;
$resultado = mysqli_query($db_connection, $consulta);
$info_campo = mysqli_fetch_fields($resultado);
$fila = mysqli_fetch_array($resultado);

$field_cnt = $resultado->field_count;
$two=$field_cnt-2;

//ROW
echo '$resultado=mysqli_query($db_connection, "'.$consulta.'  WHERE IdU = ".$IdU." ");';
echo "</br>";
echo "</br>";
echo 'while ($row =mysqli_fetch_array($resultado)) {';
echo "</br>";
echo "</br>";
   foreach ($info_campo as $valor) {
     $row= "$".$valor->name."= $"."row['".$valor->name."'];";
    echo $row; 
    echo "</br>";
   }
   echo "</br>";
echo "</br>";
echo '}';   
echo "</br>";
echo "</br>";


echo "<table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=".$two." style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr>";
 foreach ($info_campo as $valor) {
   echo "<th>".$valor->name."</th>";
   }
  echo " </tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr>";
  foreach ($info_campo as $valor) {
   echo "<th><?php echo $".$valor->name."; ?></th>";
      }
   echo "</tr></table></br></br>";

mysqli_free_result($resultado);
mysqli_close($db_connection);
}

function a(){
  include '../../dat/cdb/db.php';
  $txt =  $_POST['txt'];
  
$consulta = "SELECT * FROM ".$txt;
$resultado = mysqli_query($db_connection, $consulta);
$info_campo = mysqli_fetch_fields($resultado);
$fila = mysqli_fetch_array($resultado);

$field_cnt = $resultado->field_count;
$two=$field_cnt-2;
echo "<h3>Actualizar</h3>
    <form action='upd.php' method='POST'>";
 foreach ($info_campo as $valor) {
   echo "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' value='<?php echo $".$valor->name."; ?>' required>
                </div> ";
   }
   echo "<div>
             <button type='submit' class='btn btn-success'>actualiza</button>
             </div>
             </form>";
             
        //ROW
   foreach ($info_campo as $valor) {
     $row= "$".$valor->name."= $"."row['".$valor->name."'];";
    echo $row; 
    echo "</br>";
   }
   
echo "</br>";
echo "</br>";
//REQUEST
   foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     echo $recibe;
     echo "</br>";
   } 
          echo "</br>";
          echo "</br>";
//UPDATE
$cadena1="";
 $c="'";
 $p=".";
$sql = "UPDATE ".$txt." SET ";   
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.'='.' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
   $myString = substr($cadena1, 0, -2);
  $sql.= $myString." ";
  
$sql.=' WHERE REGISTRO = CAMPO "; ';

   $update_value = $sql;
 
   echo  $sql;     
             
             
mysqli_free_result($resultado);
mysqli_close($db_connection);
}


function r(){
  include '../../dat/cdb/db.php';
$txt =  $_POST['txt'];
$consulta = "SELECT * FROM ".$txt;
$resultado = mysqli_query($db_connection, $consulta);
$info_campo = mysqli_fetch_fields($resultado);
$fila = mysqli_fetch_array($resultado);

$field_cnt = $resultado->field_count;
$two=$field_cnt-2;
echo "<h3>Registrarte</h3>
    <form action='add.php' method='POST'>";
 foreach ($info_campo as $valor) {
   echo "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required>
                </div> ";
   }
   echo "<div>
             <button type='submit' class='btn btn-success'>subscribe</button>
             </div>
             </form>";

//REQUEST
   foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     echo $recibe;
     echo "</br>";
   } 
   
echo "</br>";
echo "</br>";

// INSERT INTO  
$cadena1="";
$sql = "INSERT INTO ".$txt."(";   
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.", ";
   } 
   $myString = substr($cadena1, 0, -2);
  $sql.= $myString.")";
  $c="'";
  $p=".";
  $sql.=" VALUES (";
     foreach ($info_campo as $valor) {
      $cadena2.=' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
   $myString = substr($cadena2, 0, -2);
   $sql.=$myString.");";
   $insert_value =$sql;
 
   echo  $sql;
echo "</br>";
echo "</br>";

mysqli_free_result($resultado);
mysqli_close($db_connection);
}

function b($txt1, $txt2){
include '../../dat/cdb/db.php';
$txt =  $_POST['txt'];
$consulta = "SELECT * FROM ".$txt." WHERE ".$txt1." LIKE '%".$txt2."%'";
$resultado = mysqli_query($db_connection, $consulta);
$info_campo = mysqli_fetch_fields($resultado);
$fila = mysqli_fetch_array($resultado);

$field_cnt = $resultado->field_count;
$two=$field_cnt-2;
echo "<table class='default'>
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=".$two." style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr>";
 foreach ($info_campo as $valor) {
   echo "<th>".$valor->name."</th>";
   }
  echo " </tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr>";
  foreach ($info_campo as $valor) {
   echo "<th>".$fila[$valor->name]."</th>";
      }
   echo "</tr></table>";
mysqli_free_result($resultado);
mysqli_close($db_connection);
}



}
?>