<?php

  $estudiante = $_POST["estudiante"];
	$fecha = $_POST["fecha"];
	$tipo = $_POST["tipo"];
	$descripcion = $_POST ["descripcion"];
	$directorio = "archivos/pse/";

	if (!file_exists($directorio)) 
      {
        mkdir($directorio, 0777, true);
      }

	$archivo = $directorio . basename($_FILES["file"]["name"]);

	$tipoArchivo = strtolower(pathinfo($archivo, PATHINFO_EXTENSION));

        if (move_uploaded_file($_FILES["file"] ["tmp_name"], $archivo)) {
          echo "archivo subido con exito";

        } else {
          echo "error en la subida del archivo";
        }

    $adjunto = $archivo;

    $sql = "INSERT INTO tabladelabasededatos (estudiante, fecha, tipo, descripcion, adjunto) values ('$estudiante', '$fecha', '$tipo', '$descripcion', '$adjunto')";

    $consulta = mysqli_query($conexion, $sql);

    if ($consulta==false) {
        echo "Error en la consulta";

        } else {
          echo "<br><br>Datos almacenados exitosamente<br><br>";
               }

    mysqli_close($conexion);
    echo "<a href ='" .$adjunto . "'>Descargar archivo</a>";




	?>
<html> 

<script>
 function cambiar(){
    var pdrs = document.getElementById('file-upload').files[0].name;
    document.getElementById('info').innerHTML = pdrs;
}
   
    
</script>


<body> 
<form action="pse_guardar.php" method="POST" enctype="multipart/form-data">

		<input type="text" id="estudiante" name="estudiante" value =" <?php echo $e_id ?>" readonly><br>

		<input type="date" id="fecha" name="fecha" required><br>

		<select name = "tipo">
			<option>Selecciona</option>
			<option>Excusa ausencia</option>
			<option>Ausencia futura</option>
			<option>Salida en jornada</option>
			<option>Excusa uniforme</option>
			<option>Llegada tarde</option>
		</select><br>

		<input type="text" id="descripcion" name="descripcion" placeholder="Descripcion" required><br>

		<input type="file" name="file" id="file" > <br>

		<input type="submit" name="" value="Almacenar">

	</form>




 
</body> 
</html>