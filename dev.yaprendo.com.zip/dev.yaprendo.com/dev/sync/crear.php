<?php 
$tabla = utf8_decode($_GET['tabla']);
$sql = utf8_decode($_GET['sql']);
$servidor  ="localhost"; 
$usuario   ="yaprendo_test";
$clave     ="us1317mx$";
$basedatos ="yaprendo_pymes";


$db_connection = mysqli_connect($servidor, $usuario, $clave, $basedatos) or die(mysql_error());
if (!$db_connection) {
	die("No se ha podido conectar a la base de datos");
}else
	echo mysqli_connect_error($db_connection);



date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 

$Nombre= $tabla;
$Crea= $sql;
$Fecha= $dt;
 
 
$insert_value ="INSERT INTO Tablas( Nombre, Crea, Fecha) VALUES (  '".$Nombre."',  '".$Crea."',  '".$Fecha."')";
$retry_value = mysqli_query($db_connection,$insert_value);
mysqli_free_result($retry_value);

/* marca error

// obtenemos una lista de las bases de datos del servidor
$db = mysql_list_dbs();
// vemos cuantas BD hay
$num_bd = mysql_num_rows($db);
//comprobamos si la BD que quermos crear exite ya
$existe = "NO" ;
for ($i=0; $i<$num_bd; $i++) {
if (mysql_dbname($db, $i) == $basedatos) {
$existe = "SI" ;
break;
}
}

// si no existe la creamos
if ($existe == "NO") {
if (! mysql_create_db($basedatos, $link)) {
echo "<h2 align='center'>ERROR 1: Imposible crear base de datos</h2>";
} }
*/	

// Se verifica si la tabla ha sido creado
if ($db_connection->query($sql) === TRUE) {
    echo "la tabla ".$tabla." ha sido creado";
} else {
    echo "Hubo un error al crear la tabla ".$tabla.": " . $conn->error;
}

mysqli_close($db_connection);
?>
