-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 06-07-2021 a las 23:27:23
-- Versión del servidor: 10.4.6-MariaDB
-- Versión de PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `yaprendo_pymes`
--
CREATE DATABASE IF NOT EXISTS `yaprendo_pymes` DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci;
USE `yaprendo_pymes`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

DROP TABLE IF EXISTS `articulos`;
CREATE TABLE IF NOT EXISTS `articulos` (
  `idart` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `articulo` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `ubicacion` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `costo` decimal(11,2) NOT NULL,
  `venta` decimal(11,2) NOT NULL,
  `cantidad` float NOT NULL,
  `descripcion` text COLLATE latin1_spanish_ci NOT NULL,
  `caducidad` datetime NOT NULL,
  `max` int(11) NOT NULL,
  `min` int(11) NOT NULL,
  `foto` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idpro` int(11) NOT NULL,
  `idcat` int(11) NOT NULL,
  PRIMARY KEY (`idart`),
  KEY `idpro` (`idpro`),
  KEY `idcat` (`idcat`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `idcat` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `descripcion` text COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  PRIMARY KEY (`idcat`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `idcli` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `rfc` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `foto` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  PRIMARY KEY (`idcli`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--

DROP TABLE IF EXISTS `detalle`;
CREATE TABLE IF NOT EXISTS `detalle` (
  `Iddet` int(11) NOT NULL AUTO_INCREMENT,
  `Cantidad` float DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  `Descuento` float DEFAULT NULL,
  `Importe` float DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `Idobj` int(11) NOT NULL,
  `Idmov` int(11) NOT NULL,
  PRIMARY KEY (`Iddet`),
  KEY `Idobj` (`Idobj`),
  KEY `Idmov` (`Idmov`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `detalle`
--

INSERT INTO `detalle` (`Iddet`, `Cantidad`, `Precio`, `Descuento`, `Importe`, `Fecha`, `Idobj`, `Idmov`) VALUES
(2, 5, 0.43, 0, 2.15, '2021-07-06 17:56:56', 2, 1),
(3, 2, 0.43, 0, 0.86, '2021-07-06 18:08:33', 2, 2),
(4, 1, 1.23, 0, 1.23, '2021-07-06 18:08:55', 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

DROP TABLE IF EXISTS `empresas`;
CREATE TABLE IF NOT EXISTS `empresas` (
  `idemp` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `logo` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `rfc` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `iva` decimal(4,2) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`idemp`, `nombre`, `direccion`, `telefono`, `correo`, `logo`, `rfc`, `iva`, `estado`) VALUES
(1, 'celulandia', 'conocida', '96122329', 'celulandia@telcel.com', '1', '1234', '1.16', 1),
(7, 'Movistar', 'conocida', '96111111111', 'movistar@gmail.com', '1', 'Viar17', '1.16', 1),
(6, 'Telcel', 'conocida', '96122329', 'telcel@telcel.com', '1', 'Tel771015', '1.16', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entidades`
--

DROP TABLE IF EXISTS `entidades`;
CREATE TABLE IF NOT EXISTS `entidades` (
  `Ident` int(11) NOT NULL AUTO_INCREMENT,
  `Empresa` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Direccion` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Rfc` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Pass` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Foto` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` datetime NOT NULL,
  `Estado` tinyint(4) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Ident2` int(11) NOT NULL,
  PRIMARY KEY (`Ident`),
  KEY `Ident2` (`Ident2`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `entidades`
--

INSERT INTO `entidades` (`Ident`, `Empresa`, `Nombres`, `Apellidos`, `Direccion`, `Rfc`, `Movil`, `Correo`, `Pass`, `Foto`, `Fecha`, `Estado`, `Tipo`, `Ident2`) VALUES
(1, 'Empresas', 'Jimmy', 'Villatoro', 'Ave cupape 912', 'Viaj771014j83', '9611772089', 'empresas@gmail.com', 'us1317mx@', 'No', '2021-07-05 07:56:00', 1, 1, 1),
(2, 'Usuarios', 'Jimmy', 'Villatoro', 'Ave cupape', 'Viarj', '9611772089', 'jimmyvillatoro77@gmail.com', 'us1317mx@', 'No', '2021-07-04 19:46:00', 1, 1, 2),
(3, 'Clientes', 'Jimmy', 'Villatoro', 'Ave cupape', 'Viarj', '9611772089', 'clientes@gmail.com', 'us1317mx@', 'No', '2021-07-04 19:46:00', 1, 1, 3),
(4, 'Proveedores', 'Jimmy', 'Villatoro', 'Ave cupape', 'Viarj', '9611772089', 'proveedores@gmail.com', 'us1317mx@', 'No', '2021-07-04 19:46:00', 1, 1, 4),
(5, 'Prospectos', 'Jimmy', 'Villatoro', 'Ave cupape', 'Viarj', '9611772089', 'prospectos@gmail.com', 'us1317mx@', 'No', '2021-07-04 19:46:00', 1, 1, 5),
(6, 'pepitas', 'juan', 'lopez', 'conocida', 'Viaj771014j83', '9611772089', 'pepitas@pepitas.com', '1234', 'NO', '2021-07-06 09:46:46', 0, 5, 5),
(7, 'Almacen', 'Jimmy', 'Saldaña', 'conocida', 'no', '11111', 'jairsaldana@gmail.com', 'us1317mx@', 'No', '2021-07-06 10:24:34', 1, 2, 2),
(8, 'Nosotros', 'Mauricio', 'Zaldivar', 'AV tezontle 845', 'no', '11111', 'nosotros@nosotros.com', '1234', 'No', '2021-07-06 11:57:38', 1, 4, 4),
(9, 'Negocio Propio', 'Mauricio', 'Zaldivar', 'AV tezontle 845', 'Cliente1234', '9611772089', 'frank3@seniorcode.com', '1234', 'NO', '2021-07-06 16:24:45', 0, 5, 5),
(10, 'Jim', 'Jair', 'SaldaÃ±a', 'Conocido', 'Viaj771014j83', '9611772089', 'cliente@gmail.com', '1234', 'No', '2021-07-06 18:06:33', 1, 3, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientos`
--

DROP TABLE IF EXISTS `movimientos`;
CREATE TABLE IF NOT EXISTS `movimientos` (
  `Idmov` int(11) NOT NULL AUTO_INCREMENT,
  `Folio` int(11) DEFAULT NULL,
  `Fecha` datetime NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Subtotal` float DEFAULT NULL,
  `Descuento` float DEFAULT NULL,
  `Iva` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `Estado` int(11) NOT NULL,
  `Mensaje` varchar(250) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Remitente` int(11) DEFAULT NULL,
  `Destinatario` int(11) DEFAULT NULL,
  `Ident` int(11) NOT NULL,
  PRIMARY KEY (`Idmov`),
  KEY `Ident` (`Ident`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `movimientos`
--

INSERT INTO `movimientos` (`Idmov`, `Folio`, `Fecha`, `Tipo`, `Subtotal`, `Descuento`, `Iva`, `Total`, `Estado`, `Mensaje`, `Remitente`, `Destinatario`, `Ident`) VALUES
(1, NULL, '2021-07-06 17:53:46', 3, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 5),
(2, NULL, '2021-07-06 18:03:20', 3, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 5),
(3, NULL, '2021-07-06 18:10:37', 3, NULL, NULL, NULL, NULL, 0, ' Tu Mensaje: hey venÃ­ vos', 5, 7, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `objetos`
--

DROP TABLE IF EXISTS `objetos`;
CREATE TABLE IF NOT EXISTS `objetos` (
  `Idobj` int(11) NOT NULL AUTO_INCREMENT,
  `Codigo` int(11) NOT NULL,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Categoria` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Descripcion` text COLLATE latin1_spanish_ci NOT NULL,
  `Cantidad` float NOT NULL,
  `Precio` float NOT NULL,
  `Maximo` int(11) NOT NULL,
  `Minimo` int(11) NOT NULL,
  `Caducidad` datetime NOT NULL,
  `Ubicacion` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Foto` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Enlace` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idobj2` int(11) NOT NULL,
  `Ident` int(11) NOT NULL,
  PRIMARY KEY (`Idobj`),
  KEY `Idobj2` (`Idobj2`,`Ident`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `objetos`
--

INSERT INTO `objetos` (`Idobj`, `Codigo`, `Nombre`, `Categoria`, `Descripcion`, `Cantidad`, `Precio`, `Maximo`, `Minimo`, `Caducidad`, `Ubicacion`, `Foto`, `Enlace`, `Estado`, `Idobj2`, `Ident`) VALUES
(1, 1, 'paleta', 'dulces', ' Descripcion ', 10, 1.23, 10, 3, '2021-07-06 11:58:00', 'mostrador', 'No', 'no', 1, 8, 4),
(2, 2, 'Chicle', 'dulces', ' Descripcion ', 10, 0.43, 10, 3, '2021-07-06 11:58:00', 'mostrador', 'No', 'no', 1, 8, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE IF NOT EXISTS `proveedores` (
  `idpro` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `logo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `rfc` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  PRIMARY KEY (`idpro`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `idusu` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `foto` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  PRIMARY KEY (`idusu`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusu`, `nombres`, `apellidos`, `direccion`, `telefono`, `movil`, `correo`, `pass`, `foto`, `estado`, `idemp`) VALUES
(1, 'Jimmy Virgilio', 'Villatoro Arguelo', 'ave cupape 911 ', '9611772089', '9611772089', 'jimmyvillatoro77@gmail.com', 'aguila', 'No', 0, 1),
(5, 'Jimmy Jair', 'Villatoro SaldaÃ±a', 'conocida', '9616605651', '9616605651', 'jvillatorosaldana@gmail.com', 'polluelo', 'no', 0, 1),
(6, 'Jimmy Jair', 'Villatoro SaldaÃ±a', 'ave cupape 911 ', '9616605651', '9616605651', 'jvillatorosaldana@gmail.com', 'polluelo', 'no', 0, 6);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
