-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 04-07-2021 a las 11:50:52
-- Versión del servidor: 5.7.23-23
-- Versión de PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `yaprendo_pymes`
--
CREATE DATABASE IF NOT EXISTS `yaprendo_pymes` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `yaprendo_pymes`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

DROP TABLE IF EXISTS `articulos`;
CREATE TABLE IF NOT EXISTS `articulos` (
  `idart` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `articulo` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `ubicacion` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `costo` decimal(11,2) NOT NULL,
  `venta` decimal(11,2) NOT NULL,
  `cantidad` float NOT NULL,
  `descripcion` text COLLATE latin1_spanish_ci NOT NULL,
  `caducidad` datetime NOT NULL,
  `max` int(11) NOT NULL,
  `min` int(11) NOT NULL,
  `foto` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idcat` int(11) NOT NULL,
  `idpro` int(11) NOT NULL,
  PRIMARY KEY (`idart`),
  KEY `idcat` (`idcat`),
  KEY `idpro` (`idpro`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`idart`, `codigo`, `articulo`, `ubicacion`, `costo`, `venta`, `cantidad`, `descripcion`, `caducidad`, `max`, `min`, `foto`, `estado`, `idcat`, `idpro`) VALUES
(1, '00001', 'Samsung A01', 'Mostrador', 2500.00, 3000.00, 3, 'celular nuevo', '2021-06-30 10:28:00', 5, 1, 'no', 1, 2, 0),
(2, '00002', 'gomoto now', 'Mostrador', 2700.00, 3500.00, 6, ' telefonito del mongolito que tiene buen sonido ', '2021-07-04 11:40:00', 10, 1, 'No', 1, 1, 1),
(3, '00003', 'huawei', 'almacen', 5000.00, 10000.00, 3, ' teléfono chino pero muy bueno', '2021-07-04 11:24:00', 5, 1, 'no', 1, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `idcat` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `descripcion` text COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  PRIMARY KEY (`idcat`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`idcat`, `categoria`, `descripcion`, `estado`, `idemp`) VALUES
(1, 'accesorios', ' accesorios para celulares ', 1, 1),
(2, 'dispositivos', '  dispositivo móvil completo para venta de mostrador que no están en almacén', 1, 1),
(4, 'protectores', 'protectores plasticos para alto impacto', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `idcli` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `rfc` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `foto` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  PRIMARY KEY (`idcli`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`idcli`, `nombres`, `apellidos`, `direccion`, `telefono`, `movil`, `correo`, `pass`, `rfc`, `foto`, `estado`, `idemp`) VALUES
(1, 'Mauricio', 'Zaldivar', 'AV tezontle 845', '96122329', '9616605651', 'telcel@telcel.com', 'us1317mx@', 'Celu771015', 'No', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dingresos`
--

DROP TABLE IF EXISTS `dingresos`;
CREATE TABLE IF NOT EXISTS `dingresos` (
  `iddin` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` float NOT NULL,
  `precio` decimal(11,2) NOT NULL,
  `importe` decimal(11,2) NOT NULL,
  `idart` int(11) NOT NULL,
  `iding` int(11) NOT NULL,
  PRIMARY KEY (`iddin`),
  KEY `idart` (`idart`),
  KEY `iding` (`iding`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `dingresos`
--

INSERT INTO `dingresos` (`iddin`, `cantidad`, `precio`, `importe`, `idart`, `iding`) VALUES
(1, 1, 1000.00, 1000.00, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dventas`
--

DROP TABLE IF EXISTS `dventas`;
CREATE TABLE IF NOT EXISTS `dventas` (
  `iddve` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` float NOT NULL,
  `precio` decimal(11,2) NOT NULL,
  `descuento` decimal(11,2) NOT NULL,
  `importe` decimal(11,2) NOT NULL,
  `idart` int(11) NOT NULL,
  `idven` int(11) NOT NULL,
  PRIMARY KEY (`iddve`),
  KEY `idart` (`idart`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

DROP TABLE IF EXISTS `empresas`;
CREATE TABLE IF NOT EXISTS `empresas` (
  `idemp` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `logo` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `rfc` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `iva` decimal(4,2) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`idemp`, `empresa`, `direccion`, `telefono`, `correo`, `logo`, `rfc`, `iva`, `estado`) VALUES
(1, 'celulandia', 'AV tezontle 845', '9616605651', 'jair@gmail.com', 'Si', 'lo hace bien', 1.16, 1),
(6, 'at&t', 'conocida', '96122329', 'atandt@atandt.com', 'No', 'atandt1234', 1.16, 1),
(3, 'Telcel', 'conocida', '96122329', 'telcel@telcel.com', 'No', 'Celu771015', 1.16, 1),
(4, 'Movistar', 'conocida', '96122329', 'movil@movistar.com', 'No', 'Celu771015', 1.16, 1),
(5, 'Unefon', 'conocida', '96122329', 'unefon@telcel.com', 'No', 'une1234', 1.16, 1),
(7, 'usacel', 'conocida', '96122329', 'usacel@gmail.com', 'No', '1234', 1.16, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingresos`
--

DROP TABLE IF EXISTS `ingresos`;
CREATE TABLE IF NOT EXISTS `ingresos` (
  `iding` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `folio` varchar(7) COLLATE latin1_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `descuento` decimal(11,2) NOT NULL,
  `iva` decimal(4,2) NOT NULL,
  `total` decimal(11,2) NOT NULL,
  `estado` int(11) NOT NULL,
  `idusu` int(11) NOT NULL,
  `idpro` int(11) NOT NULL,
  PRIMARY KEY (`iding`),
  KEY `idusu` (`idusu`),
  KEY `idpro` (`idpro`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `ingresos`
--

INSERT INTO `ingresos` (`iding`, `tipo`, `folio`, `fecha`, `subtotal`, `descuento`, `iva`, `total`, `estado`, `idusu`, `idpro`) VALUES
(1, 'credito', '0001', '2021-07-03 13:10:00', 1000.00, 0.00, 99.99, 1160.00, 1, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE IF NOT EXISTS `proveedores` (
  `idpro` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `logo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `rfc` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  PRIMARY KEY (`idpro`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`idpro`, `proveedor`, `direccion`, `telefono`, `movil`, `correo`, `pass`, `logo`, `rfc`, `estado`, `idemp`) VALUES
(1, 'Telcel', 'conocida', '96122329', '9616605651', 'telcel@gmail.com', '12345', 'Si', 'si', 1, 1),
(6, 'Unefon', 'conocida', '96122329', '9616605651', 'unefon@gmail.com', '12345', 'No', 'Celu771015', 1, 1),
(4, 'iusasel', 'conocida', '96122329', '9616605651', 'iusa@telcel.com', 'us1317mx@', 'No', 'Celu771015', 1, 0),
(5, 'criket', 'conocida', '96122329', '9616605651', 'criket@telcel.com', 'us1317mx@', 'No', 'Celu771015', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `idusu` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `foto` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  PRIMARY KEY (`idusu`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusu`, `nombres`, `apellidos`, `direccion`, `telefono`, `movil`, `correo`, `pass`, `foto`, `estado`, `idemp`) VALUES
(1, 'Jimmy Virgilio', 'Villatoro Arguello', 'ave cupape 911 entre andador los cocos y calle cipres col albania baja cp 29040', '96122329', '9616605651', 'jimmyvillatoro77@gmail.com', 'aguila', 'No', 0, 1),
(6, 'Jimmy Jair', 'Villatoro Saldaña', 'conocida', '9616605651', '9611772089', 'jvillatorosaldana@gmail.com', 'polluelo', 'No', 1, 1),
(7, 'pepe', 'pecas jolote', 'AV tezontle 845', '96122329', '9616605651', 'pepe@telcel.com', 'us1317mx@', 'No', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

DROP TABLE IF EXISTS `ventas`;
CREATE TABLE IF NOT EXISTS `ventas` (
  `idven` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `folio` varchar(7) COLLATE latin1_spanish_ci DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `impuesto` decimal(4,2) NOT NULL,
  `total` decimal(11,2) NOT NULL,
  `letras` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `idusu` int(11) NOT NULL,
  `idcli` int(11) NOT NULL,
  PRIMARY KEY (`idven`),
  KEY `idusu` (`idusu`),
  KEY `idcli` (`idcli`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
