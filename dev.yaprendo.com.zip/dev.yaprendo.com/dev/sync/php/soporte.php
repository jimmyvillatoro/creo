<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Soporte</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description: soporte" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

					<h1>automata de <span>codigo PHP</span></h1>

					<p>versión 2.17</p>

			</div>

			

			<div id="page" class="round">

			

		<div id="menu" class="round">

			<ul>

<li><a href="index.php" title="" class="round">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>



<li><a href="contacto.php" title="" class="round">Contactame</a></li>

<li><a href="soporte.php" title="" class="round active">Soporte</a></li>

			</ul>		

				</div>



				

				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

					<h3>Índice</h3>

			<ul>

<li><a href="index.php" title="" class="round">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Contactame</a></li>

<li><a href="soporte.php" title="" class="round active">Soporte</a></li>

			</ul>				

						

					

					<!-- End Sidebar -->				

					</div>

		

				<div id="content" class="round">

					

				<div id="splash" align="center">

<img src="dat/ima/tipoj.jpg" alt="" width="200" height="300" class="round" align="center" />

				</div>



				

						<h3>Contacto</h3>

						<ul>

			<li>Personal de Soporte</li>

   <li>jimmyvillatoro77@gmail.com</li>

						</ul>

							<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>	

	

<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>

	



	

</html>

