<?php 
//8 julio


$servidor  =utf8_decode($_GET['server']); 
$usuario   =utf8_decode($_GET['user']);
$clave     =utf8_decode($_GET['pass']);
$basedatos =utf8_decode($_GET['db']);
$txt=$_GET['tabla'];

$usu1=utf8_decode($_GET['usu']);
$ses1=utf8_decode($_GET['ses']);
$txt2=$_GET['tabla2'];
$campo=utf8_decode($_GET['campo']);

date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;


/*
$db_connection2 = mysqli_connect('localhost', 'yaprendo_test', 'us1317mx$', 'yaprendo_ProyectoDan') or die(mysql_error());
if (!$db_connection2) {
	die("Se ha podido conectar a la base de datos");
}else
	echo mysqli_connect_error($db_connection2);

$insert_value2 ="INSERT INTO Servidores( Servidor, Usuario, Clave, Basedatos, Tabla, Fecha) VALUES (  '".$servidor."',  '".$usuario."',  '".$clave."',  '".$basedatos."',  '".$txt."',  '".$dt."')";
$retry_value2 = mysqli_query($db_connection2,$insert_value2);
mysqli_free_result($retry_value2);

*/
$Servidor= $servidor;
$Usuario= $usuario;
$Clave  =$clave  ;
$Basedatos= $basedatos;
$Tabla= $txt;
$Fecha= $dt;

$db_connection = mysqli_connect($servidor, $usuario, $clave, $basedatos) or die(mysql_error());
if (!$db_connection) {
	die("Se ha podido conectar a la base de datos");
}else
	echo mysqli_connect_error($db_connection);


$consulta = "SELECT * FROM ".$txt;
$resultado=mysqli_query($db_connection, $consulta);

$info_campo = mysqli_fetch_fields($resultado);
$fila = mysqli_fetch_array($resultado);
$field_cnt = $resultado->field_count;


// SQL 
$cadena1="";
$primary="";
$secundary="";
$terciary="";
$bus="";
$ban=0;

$sql = "INSERT INTO ".$txt."(";   

foreach ($info_campo as $valor) {
  

if( $valor->flags==49667){
$primary=$valor->name;
$ban=1;
}
if($valor->flags==53257 && $ban==2){
$terciary=$valor->name;
$ban=3;}
if($valor->flags==53257){
$secundary=$valor->name;
$ban=2;}

if( $valor->flags!=49667){
$cadena1.=$valor->name.", ";
if($ban==1){
 $bus=$valor->name;
 $ban=4;
}
}
   
   }

if(strlen($secundary)<=0)
$secundary=$primary;
if(strlen($terciary)<=0)
$terciary=$secundary;

//INSERT
  $myString = substr($cadena1, 0, -2);
  $sql.= $myString.")";
  $c="'";
  $p=".";
  $s="$";
  $sql.=" VALUES (";
     foreach ($info_campo as $valor) {
if( $valor->flags!=49667)
$cadena2.=' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
   $myString = substr($cadena2, 0, -2);
   $sql.=$myString.")";
   $insert_value =$sql;
   
   
//UPDATE
$cadena2="";
$sql2 = "UPDATE ".$txt." SET ";   
   foreach ($info_campo as $valor) {
if( $valor->flags!=49667)
      $cadena2.=$valor->name.'='.' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
  $myString = substr($cadena2, 0, -2);
  $sql2.= $myString." ";
  $sql2.='  WHERE   '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ; ';

//DELETE
$sql3 = 'DELETE FROM '.$txt.' WHERE '.$primary.' LIKE '.$c.'".'.$s.'Idx."'.$c.'"; ';  


$inicio="<?php 
include '../dat/cdb/db.php';";
$request="
$"."$usu1 = $"."_REQUEST['$usu1'];
$"."$ses1 = $"."_REQUEST['$ses1'];
$"."$primary = $"."_REQUEST['$primary'];
$"."$secundary = $"."_REQUEST['$secundary']; 
$"."$terciary = $"."_REQUEST['$terciary'];
";

$get="$"."$usu1 = utf8_decode($"."_GET['$usu1']); 
$"."$ses1 = utf8_decode($"."_GET['$ses1']); 
$"."$primary = utf8_decode($"."_GET['$primary']); 
$"."$secundary = utf8_decode($"."_GET['$secundary']);
$"."$terciary = utf8_decode($"."_GET['$terciary']);\r\n";


$request2='$html="";';
$request2.=" \r\n";
$request2.='$busca= $_REQUEST["txtbusca"];';
$request2.=" \r\n";
$request2.='$html.="<h2><strong class='.$c.'cur'.$c.'>Resultados</h2>";';
$request2.=" \r\n";


$fecha= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';

$result='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$bus.' LIKE '.$c.'".$'.$bus.'."'.$c.'" ); ';
$result2='$resultado=mysqli_query($db_connection, "SELECT '.$primary.'  FROM  '.$txt.'  WHERE '.$bus.' = '.$c.'".$'.$bus.'."'.$c.'" ); ';
$result3='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$primary.' LIKE '.$c.'".'.$s.'Idx."'.$c.'" ); ';
$result4='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$bus.' LIKE '.$c.'%".$busca."%'.$c.'" ); ';
$result5='$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );';

$condicion='if (mysqli_num_rows($resultado)>0) {';
//$go1='header("Location: ../usuarios.php?'.$usu1.'='.$c.'".$'.$usu1.'."'.$c.'&'.$ses1.'='.$c.'".$'.$ses1.'."'.$c.'&'.$primary.'='.$c.'".$'.$primary.'."'.$c.'&'.$secundary.'='.$c.'".$'.$secundary.'."'.$c.'");  ';
$go1=' header("Location: ../usuarios.php?'.$usu1.'=$'.$usu1.'&'.$ses1.'=$'.$ses1.'&'.$primary.'=$'.$primary.'&'.$secundary.'=$'.$secundary.'"); ';

$cierrecondicion='} else {  ';

$insert='$insert_value ="'.$sql.'";';
$retry='$retry_value = mysqli_query($db_connection,$insert_value);}';

$update='$update_value = "'.$sql2.' ';
$retry2='$retry_value = mysqli_query($db_connection,$update_value);';

$delete='$delete_value ="'.$sql3.' ';
$retry3='$retry_value = mysqli_query($db_connection,$delete_value);';


$while=' while ($row =mysqli_fetch_array($resultado))   $'.$primary.' =$row['.$c.$primary.$c.']; ';
$while2="while ($"."row =mysqli_fetch_array($"."resultado)) { ";

$while2end="} \r\n";
$while2end.='$html.="</b>";';
$while2end.=" \r\n";
$while2end.='echo $html;';
$while2end.=" \r\n";
$while2end.="} \r\n";
$while2end.='else
echo 
"Is not found";';
$while2end.=" \r\n";


$go2=' header("Location: ../usuarios.php?'.$usu1.'=$'.$usu1.'&'.$ses1.'=$'.$ses1.'&'.$primary.'=$'.$primary.'&'.$secundary.'=$'.$secundary.'"); ';

$free='mysqli_free_result($retry_value);';
$free2='mysqli_free_result($resultado);';
$close= 'mysqli_close($db_connection);';
$fin="?>";




$cabeza='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finitos" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>'.$txt.'</title> 
 ';

$cabeza2='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>'.$txt.'</title> 
 ';

$cabeza3='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="dat/css/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript" src="dat/js/tablecloth.js"></script>
        <title>'.$txt.'</title> 
<style>
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style> 
 ';

$script='
<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "'.$txt.'ser3.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>
';

$script2='
<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "'.$txt.'ser2.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>
';

$body='</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round"> '; 

$body2="</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>";

$regresar='<a href="../usuarios.php?'.$primary.'=<?php echo $'.$primary.'; ?>&'.$secundary.'=<?php echo $'.$secundary.'; ?>&'.$usu1.'=<?php echo $'.$usu1.'; ?>&'.$ses1.'=<?php echo $'.$ses1.'; ?>">Regresar</a>';

$cola='<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
 ';
 
 $cola2= "</body> </html>";
//-------------------------

$dir = "php/".$txt."/";
if (!file_exists($dir)) 
mkdir($dir, 0777, true);

 //------------------------------------------------------------------------------add 
 
//echo  'Archivo : '.$txt.'add.php listo';
   
$archivo = fopen($dir.$txt."add.php","w+b");
if( $archivo == false ) {
echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, $inicio." \r\n");   
fwrite($archivo, $request." \r\n");   
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   }
fwrite($archivo, $fecha."\r\n");
fwrite($archivo, $result."\r\n");
fwrite($archivo, $condicion."\r\n");
fwrite($archivo, $go1."\r\n");
fwrite($archivo, $cierrecondicion."\r\n");
fwrite($archivo,$insert."\r\n");
fwrite($archivo,"\r\n");
fwrite($archivo, $retry."\r\n");
fwrite($archivo, $result2."\r\n");
fwrite($archivo, $while."\r\n");
fwrite($archivo, $go2."\r\n");
fwrite($archivo, $free."\r\n");
fwrite($archivo,$free2."\r\n");
fwrite($archivo,$close."\r\n");
fwrite($archivo,$fin);

fflush($archivo);
fclose($archivo);
}
//------------------------------------------------------------------------------add2
//echo  'Archivo : '.$txt.'add2.php listo';
   
    $archivo = fopen($dir.$txt."add2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, $cabeza." \r\n");

fwrite($archivo, $inicio." \r\n");  
fwrite($archivo, $get." \r\n");

fwrite($archivo, $result5."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, $while2."\r\n");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo,$free2."\r\n");
fwrite($archivo,$close."\r\n");
fwrite($archivo,$fin);

fwrite($archivo, $body." \r\n");

if(strlen($txt2)>0){

fwrite($archivo, '
 <div> <h2>'.$txt2.'</h2> </div>
<form action="'.$txt.'add2.php" method="GET">
<input type="hidden" name="'.$usu1.'" value="<?php echo utf8_decode($_GET['.$c.$usu1.$c.']); ?>"> 
<input type="hidden" name="'.$ses1.'" value="<?php echo utf8_decode($_GET['.$c.$ses1.$c.']); ?>"> 


<div class="row mt-1" >
<div class="col">'.$txt2.': 
<SELECT NAME="selCombo1" SIZE=1 onchange = "this.form.submit()"> 
<OPTION VALUE="0"> Elige una opción </OPTION>
<?php
include "../dat/cdb/db.php";
$'.$primary.' = $'.'_GET['.$c.$primary.$c.']; 
$'.$secundary.' = $'.'_GET['.$c.$secundary.$c.'];
$selCombo1= utf8_decode($_GET['.$c.'selCombo1'.$c.']);
$resulta=mysqli_query($db_connection, "SELECT '.$secundary.', '.$campo.' FROM  '.$txt2.' ");
if (mysqli_num_rows($resulta)>0)
{			  
while ($row =mysqli_fetch_array($resulta))  { 
$'.$secundary.' =$row['.$c.$secundary.$c.'];
$'.$campo.' =$row['.$c.$campo.$c.'];
?>
<OPTION VALUE="<?php echo $'.$secundary.'; ?>"> <?php echo $'.$campo.'; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo1) > 0){
$resulta=mysqli_query($db_connection, "SELECT '.$secundary.', '.$campo.'  FROM  '.$txt2.'  WHERE '.$secundary.' = '.$c.'".$selCombo1."'.$c.'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$'.$secundary.' =$row['.$c.$secundary.$c.'];
$'.$campo.' =$row['.$c.$campo.$c.'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $'.$secundary.'; ?>"> <?php  echo $'.$campo.'; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>
</form>
 ');
}

fwrite($archivo, '
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
    
fwrite($archivo, '<h3>Registrarte</h3>
<form action="'.$txt.'add.php" method="POST">');
$s="$";

fwrite($archivo,"<input type='hidden' name='".$usu1."' value='<?php echo utf8_decode(".$s."_GET['".$usu1."']); ?>'> \r\n");
fwrite($archivo,"<input type='hidden' name='".$ses1."' value='<?php echo utf8_decode(".$s."_GET['".$ses1."']); ?>'> \r\n");


 foreach ($info_campo as $valor) {

    printf("Nombre:        %s\n", $valor->name);
    printf("Tabla:         %s\n", $valor->table);
    printf("Longitud máx.: %d\n", $valor->max_length);
    printf("Banderas:      %d\n", $valor->flags);
    printf("Tipo:          %d\n", $valor->type);
    fwrite($archivo, " \r\n");
    
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


  if($valor->flags==53257 )
  fwrite($archivo, "<div><input type='hidden' name='".$valor->name."'   value='<?php echo utf8_decode(".$s."_GET['selCombo1']); ?>' > </div>  \r\n");


  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  if( $valor->flags!=49667 && $valor->flags!=53257)
  fwrite($archivo, "<div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  
   if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24 
  if( $valor->flags==49667 || $valor->flags==53257 )
  fwrite($archivo, "<div><input type='hidden' name='".$valor->name."'   value='<?php echo utf8_decode(".$s."_GET['selCombo1']); ?>' > </div>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246  )//DECIMALES 
  fwrite($archivo, "<div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");


  if($valor->type == 7)//fechas
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
   if($valor->type == 10)
  fwrite($archivo, "<div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> ".$valor->name." </textarea> </div>  \r\n");
 

  if($valor->type == 253)//cadena
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");

   }
   
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
   fwrite($archivo, "<div>
             <button type='submit' class='btn btn-success'>Registrate</button>
             </div>
             </form> \r\n");

fwrite($archivo,$regresar."\r\n");

fwrite($archivo,$cola."\r\n");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------upd 
//echo  'Archivo : '.$txt.'upd.php listo';
   
    $archivo = fopen($dir.$txt."upd.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo,$inicio." \r\n");
fwrite($archivo, $request." \r\n");    
  
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 

fwrite($archivo, $fecha." \r\n");
fwrite($archivo, $result5." \r\n");
fwrite($archivo, $condicion."\r\n");
//----------------------------UPDATE--------------------------------------------
fwrite($archivo,$update."\r\n");	    
fwrite($archivo, $retry2."\r\n");
//-----------------------------UPDATE-------------------------------------------
fwrite($archivo, $go1."\r\n");
fwrite($archivo, $free."\r\n");
fwrite($archivo, $cierrecondicion."\r\n");
fwrite($archivo, $go2."}\r\n");
fwrite($archivo,$free2."\r\n");
fwrite($archivo,$close."\r\n");
fwrite($archivo,$fin);

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------upd3 
//echo  'Archivo : '.$txt.'upd.php listo';
   
    $archivo = fopen($dir.$txt."upd3.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo,$inicio." \r\n");
fwrite($archivo, $request." \r\n");    
  
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 

fwrite($archivo, $fecha." \r\n");
fwrite($archivo, $result5." \r\n");
fwrite($archivo, $condicion."\r\n");

//----------------------------UPDATE--------------------------------------------
fwrite($archivo,$update."\r\n");	    
fwrite($archivo, $retry2."\r\n");
//-----------------------------UPDATE-------------------------------------------
fwrite($archivo, $go1."\r\n");
fwrite($archivo, $free."\r\n");
fwrite($archivo, $cierrecondicion."\r\n");
fwrite($archivo, $go2."}\r\n");
fwrite($archivo,$free2."\r\n");
fwrite($archivo,$close."\r\n");
fwrite($archivo,$fin);

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------upd2
//echo  'Archivo : '.$txt.'upd2.php listo';
   
    $archivo = fopen($dir.$txt."upd2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo, $cabeza." \r\n");

fwrite($archivo, $script." \r\n");


fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary= utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "$"."$secundary = utf8_decode($"."_GET['$secundary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");


fwrite($archivo, $body." \r\n");


fwrite($archivo, '
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo, '
<h2>busca por <strong class="cur">'.$bus.'</strong></h2>
<form action="'.$txt.'ser3.php" method="POST">');

fwrite($archivo,"<input type='hidden' name='".$usu1."' value='<?php echo utf8_decode(".$s."_GET['".$usu1."']); ?>'> \r\n");
fwrite($archivo,"<input type='hidden' name='".$ses1."' value='<?php echo utf8_decode(".$s."_GET['".$ses1."']); ?>'> \r\n");
/*fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'> \r\n");
fwrite($archivo,"<input type='hidden' name='".$secundary."' value='<?php echo utf8_decode(".$s."_GET['".$secundary."']); ?>'> \r\n");*/

fwrite($archivo, '
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $'.$bus.'; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div></form>
 ');

/*
//<input type="hidden" name="'.$primary.'" value="<?php echo utf8_decode($_GET['.$c.$primary.$c.']); ?>">
//<input type="hidden" name="'.$secundary.'" value="<?php echo utf8_decode($_GET['.$c.$secundary.$c.']); ?>"> 
//<input type="hidden" name="'.$terciary.'" value="<?php echo utf8_decode($_GET['.$c.$terciary.$c.']); ?>"> 
*/

if(strlen($txt2)>0){
fwrite($archivo, '
 <div> <h2>'.$txt2.'</h2> </div>
<form action="'.$txt.'upd2.php" method="GET">
<input type="hidden" name="'.$usu1.'" value="<?php echo utf8_decode($_GET['.$c.$usu1.$c.']); ?>"> 
<input type="hidden" name="'.$ses1.'" value="<?php echo utf8_decode($_GET['.$c.$ses1.$c.']); ?>"> 
<input type="hidden" name="'.$primary.'" value="<?php echo utf8_decode($_GET['.$c.$primary.$c.']); ?>">

<div class="row mt-1" >
<div class="col">'.$txt2.': 
<SELECT NAME="selCombo1" SIZE=1 onchange = "this.form.submit()"> 
<OPTION VALUE="0"> Elige una opción </OPTION>
<?php
include "../dat/cdb/db.php";
$'.$primary.' = $'.'_GET['.$c.$primary.$c.']; 
$'.$secundary.' = $'.'_GET['.$c.$secundary.$c.'];
$selCombo1= utf8_decode($_GET['.$c.'selCombo1'.$c.']);
$resulta=mysqli_query($db_connection, "SELECT '.$secundary.', '.$campo.' FROM  '.$txt2.' ");
if (mysqli_num_rows($resulta)>0)
{			  
while ($row =mysqli_fetch_array($resulta))  { 
$'.$secundary.' =$row['.$c.$secundary.$c.'];
$'.$campo.' =$row['.$c.$campo.$c.'];
?>
<OPTION VALUE="<?php echo $'.$secundary.'; ?>"> <?php echo $'.$campo.'; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo1) > 0){
$resulta=mysqli_query($db_connection, "SELECT '.$secundary.', '.$campo.'  FROM  '.$txt2.'  WHERE '.$secundary.' = '.$c.'".$selCombo1."'.$c.'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$'.$secundary.' =$row['.$c.$secundary.$c.'];
$'.$campo.' =$row['.$c.$campo.$c.'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $'.$secundary.'; ?>"> <?php  echo $'.$campo.'; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>
</form>
 ');
}

fwrite($archivo, '<h3>Actualiza</h3>
<form action="'.$txt.'upd.php" method="POST">');
$s="$";
fwrite($archivo,"<input type='hidden' name='".$usu1."' value='<?php echo utf8_decode(".$s."_GET['".$usu1."']); ?>'> \r\n");
fwrite($archivo,"<input type='hidden' name='".$ses1."' value='<?php echo utf8_decode(".$s."_GET['".$ses1."']); ?>'> \r\n");
fwrite($archivo,"\r\n");
 foreach ($info_campo as $valor) {

  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  if( $valor->flags!=49667 && $valor->flags!=53257)
  fwrite($archivo, "<div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."'  value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  
  if(strlen($txt2)<=0){
    if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  if( $valor->flags==49667 || $valor->flags==53257 )
  fwrite($archivo, "<div><input type='hidden' name='".$valor->name."'   value='<?php echo utf8_decode(".$s."_GET['".$valor->name."']); ?>' > </div>  \r\n");
  }else{
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
   
  if( $valor->flags==49667  )
  fwrite($archivo, "<div><input type='hidden' name='".$valor->name."'   value='<?php echo utf8_decode(".$s."_GET['".$valor->name."']); ?>' > </div>  \r\n"); 
  if($valor->flags==53257 )
  fwrite($archivo, "<div><input type='hidden' name='".$valor->name."'   value='<?php echo utf8_decode(".$s."_GET['selCombo1']); ?>' > </div>  \r\n");
 
  }
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");

  if($valor->type == 7)//fechas
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div>  \r\n");
 

  if($valor->type == 253)//cadena
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");

    fwrite($archivo,"\r\n");
   }
   fwrite($archivo,"\r\n");
   fwrite($archivo,"<div> <button type='submit' class='btn btn-success'>actualiza</button> </div> </form>");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,$regresar."\r\n");

fwrite($archivo, $cola." \r\n");


fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------del 
//echo  'Archivo : '.$txt.'del.php listo';
   
    $archivo = fopen($dir.$txt."del.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo,$inicio." \r\n");
fwrite($archivo, $request." \r\n");    
  
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 

 $Idx= "$"."Idx= $"."_REQUEST['Idx'];";
 fwrite($archivo,$Idx);       
 fwrite($archivo, "\r\n");      

fwrite($archivo, $fecha." \r\n");	    
fwrite($archivo, $result3." \r\n");
fwrite($archivo, $condicion."\r\n");


//----------------------------DELETE--------------------------------------------

fwrite($archivo,$delete."\r\n");	    
fwrite($archivo, $retry3."\r\n");

//-----------------------------DELETE-------------------------------------------
fwrite($archivo, $go1."\r\n");
fwrite($archivo, $free."\r\n");
fwrite($archivo, $cierrecondicion."\r\n");
fwrite($archivo, $go2."}\r\n");
fwrite($archivo,$free2."\r\n");
fwrite($archivo,$close."\r\n");
fwrite($archivo,$fin);

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------del2
//echo  'Archivo : '.$txt.'del2.php listo';
   
    $archivo = fopen($dir.$txt."del2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, $cabeza." \r\n");


fwrite($archivo, " \r\n");
fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary= utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "$"."$secundary = utf8_decode($"."_GET['$secundary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, $body." \r\n");

fwrite($archivo, '
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


    
fwrite($archivo, '<h3>Borrar</h3>
<form action="'.$txt.'del.php" method="POST">');
$s="$";
fwrite($archivo, " \r\n");
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'> \r\n");
fwrite($archivo,"<input type='hidden' name='".$secundary."' value='<?php echo utf8_decode(".$s."_GET['".$secundary."']); ?>'> \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo,"<div><input type='text' name='Idx' class='form-control' placeholder='Id a Borrar' class='form-input' value='<?php echo  $".$primary."; ?>' required></div> ");
fwrite($archivo, " \r\n");                
fwrite($archivo,"<div> <button type='submit' class='btn btn-success'>Borrar</button> </div> 
</form>");
fwrite($archivo, " \r\n");
fwrite($archivo,$regresar."\r\n");


fwrite($archivo, $cola." \r\n");


fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------sel0
//echo  'Archivo : '.$txt.'sel0.php listo';
   
    $archivo = fopen($dir.$txt."sel0.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, $cabeza2." \r\n");


fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$bus.' LIKE '.$c.'".$'.$bus.'."'.$c.'" );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');

fwrite($archivo, " \r\n");
fwrite($archivo, $body2." \r\n");    

fwrite($archivo, '<h3>Seleccionar datos</h3>');



fwrite($archivo,  "<table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=".$field_cnt." style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr>");
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
 fwrite($archivo,  "</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<th><?php echo $".$valor->name."; ?></th>");
   fwrite($archivo,  " \r\n");
      }
fwrite($archivo, "</tr></table></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,$regresar."\r\n");

fwrite($archivo,$cola2);

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------sel
//echo  'Archivo : '.$txt.'sel.php listo';
   
    $archivo = fopen($dir.$txt."sel.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
        


fwrite($archivo, $cabeza3." \r\n");


fwrite($archivo, " \r\n");
fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary= utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "$"."$secundary = utf8_decode($"."_GET['$secundary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");



fwrite($archivo,$body." \r\n");

fwrite($archivo, '
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");

fwrite($archivo,$regresar."\r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th>");
  $s="$";
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }

  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
 fwrite($archivo, '<tr><form action="'.$txt.'upd3.php" method="POST">');
   fwrite($archivo,  " \r\n");
 
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'> \r\n");
fwrite($archivo,"<input type='hidden' name='".$secundary."' value='<?php echo utf8_decode(".$s."_GET['".$secundary."']); ?>'> \r\n");
  fwrite($archivo,  " \r\n");

  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td>");  
     fwrite($archivo,  " \r\n");
   $uno++;
   }
   
 /*  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");*/
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<td><div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<td><div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type == 7)//fechas
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div></td>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<td><div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<td><div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<td><div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div></td>  \r\n");
 
  if($valor->type == 253)//cadena
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

   fwrite($archivo,  " \r\n");
      }
      
fwrite($archivo, "</form> \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   

fwrite($archivo, "</tr></table>	</div>
</div></br></br>");

fwrite($archivo,$regresar."\r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."upd2.php?".$valor->name."=<?php echo $".$valor->name."; ?>&".$primary."=<?php echo $".$primary."; ?>&".$secundary."=<?php echo $".$secundary."; ?>><?php echo $".$valor->name."; ?> actualizar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '<a href="../usuarios.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'&'.$secundary.'='.$c.'".$'.$secundary.'."'.$c.'">Regresar</a>
"');



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."del2.php?".$valor->name."=<?php echo $".$valor->name."; ?>&".$primary."=<?php echo $".$primary."; ?>&".$secundary."=<?php echo $".$secundary."; ?>><?php echo $".$valor->name."; ?> borrar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");

fwrite($archivo,$regresar."\r\n");
				
fwrite($archivo, $cola." \r\n");


fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------sel2
//echo  'Archivo : '.$txt.'sel2.php listo';
   
    $archivo = fopen($dir.$txt."sel2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo, $cabeza3." \r\n");


fwrite($archivo, " \r\n");
fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary= utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "$"."$secundary = utf8_decode($"."_GET['$secundary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");


fwrite($archivo, $body." \r\n");


   fwrite($archivo, '
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");




fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");

fwrite($archivo,$regresar."\r\n");

fwrite($archivo, $cola." \r\n");


fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------sel3
//echo  'Archivo : '.$txt.'sel3.php listo';
   
    $archivo = fopen($dir.$txt."sel3.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo, $cabeza3." \r\n");


fwrite($archivo, " \r\n");
fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary= utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "$"."$secundary = utf8_decode($"."_GET['$secundary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");


fwrite($archivo, $body." \r\n");



   fwrite($archivo, '
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");




fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th>");
  $s="$";
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }

  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
 fwrite($archivo, '<tr><form action="'.$txt.'upd3.php" method="POST">');
   fwrite($archivo,  " \r\n");
 
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'> \r\n");
fwrite($archivo,"<input type='hidden' name='".$secundary."' value='<?php echo utf8_decode(".$s."_GET['".$secundary."']); ?>'> \r\n");
  fwrite($archivo,  " \r\n");

  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td>");  
     fwrite($archivo,  " \r\n");
   $uno++;
   }
   
 /*  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");*/
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<td><div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<td><div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type == 7)//fechas
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div></td>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<td><div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<td><div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<td><div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div></td>  \r\n");
 
  if($valor->type == 253)//cadena
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

   fwrite($archivo,  " \r\n");
      }
      
fwrite($archivo, "</form> \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   

fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo,$regresar."\r\n");


fwrite($archivo, $cola." \r\n");
			


fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------sel4
//echo  'Archivo : '.$txt.'sel4.php listo';
   
    $archivo = fopen($dir.$txt."sel4.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo, $cabeza3." \r\n");

fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary= utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "$"."$secundary = utf8_decode($"."_GET['$secundary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, $body." \r\n");
 

   fwrite($archivo, '
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");




fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."upd2.php?".$valor->name."=<?php echo $".$valor->name."; ?>&".$primary."=<?php echo $".$primary."; ?>&".$secundary."=<?php echo $".$secundary."; ?>><?php echo $".$valor->name."; ?> actualizar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,$regresar."\r\n");
				

fwrite($archivo, $cola." \r\n");



fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------sel5
//echo  'Archivo : '.$txt.'sel5.php listo';
   
    $archivo = fopen($dir.$txt."sel5.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo, $cabeza3." \r\n");


fwrite($archivo, " \r\n");
fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary= utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "$"."$secundary = utf8_decode($"."_GET['$secundary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");


fwrite($archivo, $body." \r\n");


   fwrite($archivo, '
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");




fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."del2.php?".$valor->name."=<?php echo $".$valor->name."; ?>&".$primary."=<?php echo $".$primary."; ?>&".$secundary."=<?php echo $".$secundary."; ?>><?php echo $".$valor->name."; ?> borrar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo,$regresar."\r\n");

fwrite($archivo, $cola." \r\n");


fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------ser

//echo  'Archivo : '.$txt.'ser.php listo';
   
    $archivo = fopen($dir.$txt."ser.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
        

fwrite($archivo, $cabeza." \r\n");

fwrite($archivo, $script2." \r\n");


fwrite($archivo, " \r\n");
fwrite($archivo, "<?php
include '../dat/cdb/db.php'; \r\n");
fwrite($archivo, "$"."$primary= utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "$"."$secundary = utf8_decode($"."_GET['$secundary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");   
fwrite($archivo, " <?php  \r\n");
fwrite($archivo, "$"."$bus = utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, $body." \r\n");
  


fwrite($archivo, ' 
<div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '
<h2>busca por <strong class="cur">'.$bus.'</strong></h2>
<form action="'.$txt.'ser.php" method="POST">');

/*fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'> \r\n");
fwrite($archivo,"<input type='hidden' name='".$secundary."' value='<?php echo utf8_decode(".$s."_GET['".$secundary."']); ?>'> \r\n");*/

fwrite($archivo, '
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $'.$bus.'; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form> ');
	
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,$regresar."\r\n");
				


fwrite($archivo, $cola." \r\n");



fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------ser2

//echo  'Archivo : '.$txt.'ser2.php listo';
   
    $archivo = fopen($dir.$txt."ser2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo,$inicio." \r\n");
fwrite($archivo, $request." \r\n");
fwrite($archivo,$request2." \r\n");
fwrite($archivo,$result4." \r\n");
fwrite($archivo, $condicion."\r\n");
fwrite($archivo, $while2."\r\n");

$ban2=0;
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
      if( $valor->flags==49667){
     fwrite($archivo, "$"."html.= '<p><a href=".$txt."sel2.php?".$valor->name."=".$c.$p."$".$valor->name.$p.$c.">".$c.$p."$".$valor->name.$p.$c."</a></p></b>';");
     }
     fwrite($archivo, "$"."html.= '<p>".$c.$p."$".$valor->name.$p.$c."</p></b>';");
     fwrite($archivo, " \r\n");
   } 
   
fwrite($archivo, $while2end."\r\n");  
fwrite($archivo,$free2."\r\n");
fwrite($archivo,$close."\r\n");
fwrite($archivo,$fin);

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------ser3

//echo  'Archivo : '.$txt.'ser3.php listo';
   
    $archivo = fopen($dir.$txt."ser3.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo,$inicio." \r\n");
fwrite($archivo, $request." \r\n");
fwrite($archivo,$request2." \r\n");
fwrite($archivo,$result4." \r\n");
fwrite($archivo, $condicion."\r\n");
fwrite($archivo, $while2."\r\n");

//Row

$ban2=0;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
     if( $valor->flags==49667){
     fwrite($archivo, "$"."html.= '<p><a href=".$txt."upd2.php?".$valor->name."=".$c.$p."$".$valor->name.$p.$c.">".$c.$p."$".$valor->name.$p.$c."</a></p></b>';");
     }
     fwrite($archivo, "$"."html.= '<p>".$c.$p."$".$valor->name.$p.$c."</p></b>';");
     fwrite($archivo, " \r\n");
     

   } 
  
   
fwrite($archivo, $while2end."\r\n");  
fwrite($archivo,$free2."\r\n");
fwrite($archivo,$close."\r\n");
fwrite($archivo,$fin);

fflush($archivo);
fclose($archivo);
}



//------------------------------------------------------------------------------copy
echo "</br>";
$dir3 = "php/".$txt."/dat/js";
if (!file_exists($dir3)) 
mkdir($dir3, 0777, true);

copy('dat/js/jquery-3.6.0.min.js','php/'.$txt.'/dat/js/jquery-3.6.0.min.js');
copy('dat/js/tablecloth.js','php/'.$txt.'/dat/js/tablecloth.js');

$dir3 = "php/".$txt."/dat/css";
if (!file_exists($dir3)) 
mkdir($dir3, 0777, true);
copy('dat/css/tablecloth.css','php/'.$txt.'/dat/css/tablecloth.css');

$dir3 = "php/".$txt."/dat/img";
if (!file_exists($dir3)) 
mkdir($dir3, 0777, true);
copy('dat/img/tr_back.gif','php/'.$txt.'/dat/img/tr_back.gif');

/*
// -----cambio propiedades
function chmod_R($path, $filemode, $dirmode) {
    if (is_dir($path) ) {
        if (!chmod($path, $dirmode)) {
            $dirmode_str=decoct($dirmode);
            print "Failed applying filemode '$dirmode_str' on directory '$path'\n";
            print "  `-> the directory '$path' will be skipped from recursive chmod\n";
            return;
        }
        $dh = opendir($path);
        while (($file = readdir($dh)) !== false) {
            if($file != '.' && $file != '..') {  // skip self and parent pointing directories
                $fullpath = $path.'/'.$file;
                chmod_R($fullpath, $filemode,$dirmode);
            }
        }
        closedir($dh);
    } else {
        if (is_link($path)) {
            print "link '$path' is skipped\n";
            return;
        }
        if (!chmod($path, $filemode)) {
            $filemode_str=decoct($filemode);
            print "Failed applying filemode '$filemode_str' on file '$path'\n";
            return;
        }
    }
}

chmod_R($dir3,'0755','0666');
*/
//------------------------------------------------------------------------------ ZIP 


function agregar_zip($dir, $zip) {
 
  if (is_dir($dir)) {
   if ($da = opendir($dir)) {
     while (($archivo = readdir($da)) !== false) {
       if (is_dir($dir . $archivo) && $archivo != "." && $archivo != "..") {
          echo "<strong>Creando directorio: $dir$archivo</strong><br/>";
          agregar_zip($dir . $archivo . "/", $zip);
         } elseif (is_file($dir . $archivo) && $archivo != "." && $archivo != "..") {
          echo "Agregando archivo: $dir$archivo <br/>";
          $zip->addFile($dir . $archivo, $dir . $archivo);
        }
      }
      closedir($da);
    }
  }
}
 

$zip = new ZipArchive();
$dir = $dir;
$rutaFinal = "php/";
 
if(!file_exists($rutaFinal)){
  mkdir($rutaFinal);
}
 
$archivoZip = $txt.".zip";
 
if ($zip->open($archivoZip, ZIPARCHIVE::CREATE) === true) {
  agregar_zip($dir, $zip);
  $zip->close();

  rename($archivoZip, "$rutaFinal/$archivoZip");

  if (file_exists($rutaFinal. "/" . $archivoZip)) {
    echo "Proceso Finalizado!! <br/><br/>
                Descargar: <a href='$rutaFinal/$archivoZip'>$archivoZip</a>";
  } else {
    echo "Error, archivo zip no ha sido creado!!";
  }
}


mysqli_free_result($resultado);
mysqli_close($db_connection);
?>