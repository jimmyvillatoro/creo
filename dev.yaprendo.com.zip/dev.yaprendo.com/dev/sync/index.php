<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>Indice - Automatas</title>
	<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
<style>
    .div-1 {
        background-color: #EBEBEB;
    }
    
    .div-2 {
    	background-color: #ABBAEA;
    }
    
    .div-3 {
    	background-color: #FBD603;
    }
    .div-4 {
    	background-color: #B8E558;
    }
    
     #products-table
{
     width: 200px;
    height: 400px;
    overflow:scroll;
}
</style>



<?php
	
include 'dat/cdb/db.php';

$IdU = utf8_decode($_GET['IdU']);
$Sesion = utf8_decode($_GET['Sesion']);
$txt = utf8_decode($_GET['txt']);

$resultado=mysqli_query($db_connection, "SELECT IdU, Nombres, Apellidos, Fecha FROM Usuarios  WHERE IdU = '".$IdU."' ");

while ($row =mysqli_fetch_array($resultado)) {
     $IdUx=$row[IdU];  
   	 $Nombres=$row[Nombres];
   	 $Apellidos=$row[Apellidos];
   	 $Fecha=$row[Fecha];
  
   }

/*if ($IdUx!=$IdU || $Fecha != $Sesion) {
    header("Location: sesion.php");
    die();
}
*/

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

</head>
<body>
<div class="div-1" style="width:1200px; height:6⁰0px; overflow:auto;">
<h2>Consultar tabla a un servidor</h2>

<form action="db.php" method="GET">
  <div>
<input type="text" class="form-control" name="server" placeholder="Servidor" value="www.yaprendo.com"  required></div>
<div>
<input type="text" class="form-control" name="user" placeholder="Usuario" value="yaprendo_root"  required></div><div>
<input type="password" class="form-control" name="pass" placeholder="Password" value="us1317mx@"  required></div><div>
<input type="text" class="form-control" name="db"  placeholder="Base de Datos" value="yaprendo_pymes"   required></div><div>
<input type="text" class="form-control" name="tabla" placeholder="Nombre de la tabla" value="entidades"  required></div>

  <div>
<input type="text" class="form-control" name="usu" placeholder="identificador de usuario" value="idusu" required></div>
<div>
<input type="text" class="form-control" name="ses" placeholder="identificador de sesion" value="idses" required></div><div>
 <input type="text" class="form-control" name="tabla2" placeholder="Tabla maestra" value="entidades" ></div>
<div>
<input type="text" class="form-control" name="campo" placeholder="campo" value="Nombres" ></div>

<div> 
<button type="submit" class="btn btn-success"> Conectar y Crear Codigo zip</button>
</form>
<h2>Configuración necesaria para el acceso remoto</h2>
<p class="centrado">
<img alt="Configuración necesaria para el acceso remoto" src="dat/img/remoto.png" title="acceso remoto">
</p>
</div>
<div class="div-2" style="width:1200px; height:400px; overflow:auto;">
<h2>Crear Tabla en el Manejador de Base de Datos MYSQL</h2>

<form action="crear.php" method="GET">
<div>
<input type="text" class="form-control" name="tabla" placeholder="Nombre de la tabla" value="TEST" required>
</div>
<div>
<textarea  name="sql" placeholder="sql" rows="15" cols="100">CREATE TABLE TEST (
IdT INT(6) AUTO_INCREMENT PRIMARY KEY,
Nombres VARCHAR(50) NOT NULL,
Apellidos VARCHAR(50) NOT NULL,
Correo_electronico VARCHAR(50),
Celular VARCHAR(10),
Mensaje TEXT,
Fecha_nacimiento DATETIME NOT NULL,
Fecha_registro TIMESTAMP,
Tipo_Usuario FLOAT NOT NULL,
Estado_Acceso TINYINT(1) NOT NULL 
)</textarea>
</div>
<div>
<button type="submit" class="btn btn-success">Crear Tabla</button></div>
</form>
</div>
<div class="div-4" style="width:1200px; height:250px; overflow:auto;">
<h2>Automata de  HTML, PHP, CSS, AJAX, JS</h2>

<form action="automata.php" method="POST">
<input type="text" class="form-control" name="txt" placeholder="Nombre de la tabla" value="entidades" required>
  <div>
<input type="text" class="form-control" name="usu" placeholder="identificador de usuario" value="idusu" required></div>
<div>
<input type="text" class="form-control" name="ses" placeholder="identificador de sesion" value="idses" required></div><div>
 <input type="text" class="form-control" name="tabla2" placeholder="Tabla maestra"  ></div>
<div>
<input type="text" class="form-control" name="campo" placeholder="campo"  ></div>
<button type="submit" class="btn btn-success">Crear Codigo</button>
</form>
</div>
<div class="div-3" style="width:1200px; height:150px; overflow:auto;">
<h2>Automata Landing</h2>

<form action="autoland.php" method="POST">
<input type="text" class="form-control" name="txt" placeholder="Nombre de la tabla" value="Landing" required>
<button type="submit" class="btn btn-success">Crear Codigo</button>
</form>
</div>
<a href='index.php'>Index</a>
</body>
</html>