<?php
include '../dat/cdb/db.php';
$txt=$_REQUEST['txt'];


$consulta = "SELECT * FROM ".$txt;
$resultado=mysqli_query($db_connection, $consulta);

$info_campo = mysqli_fetch_fields($resultado);
$fila = mysqli_fetch_array($resultado);
$field_cnt = $resultado->field_count;


// INSERT INTO  
$cadena1="";
$sql = "INSERT INTO ".$txt."(";   $primary="";
$bus=0;
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.", ";
      if($bus==1)
      $bus=$valor->name;
      
      if($primary==""){
      $primary=$valor->name;
      $bus=1;
      }
   } 
   $myString = substr($cadena1, 0, -2);
  $sql.= $myString.")";
  $c="'";
  $p=".";
  $sql.=" VALUES (";
     foreach ($info_campo as $valor) {
      $cadena2.=' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
   $myString = substr($cadena2, 0, -2);
   $sql.=$myString.")";
   $insert_value =$sql;
   
   
$dir = "php/".$txt."/";
if (!file_exists($dir)) 
mkdir($dir, 0777, true);


 //------------------------------------------------------------------------------add 
 
//echo  'Archivo : '.$txt.'add.php listo';
   
$archivo = fopen($dir.$txt."add.php","w+b");
if( $archivo == false ) {
echo "Error al crear el archivo";
    }
    else
    {
        

fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include 'db.php'; \r\n");
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, "\r\n");  
$c="'";
$frac1= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac1."\r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$bus.' LIKE '.$c.'".$'.$bus.'."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");


$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac3."\r\n");
$frac4='header("Location: index.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'");  ';

fwrite($archivo, " \r\n");
fwrite($archivo, $frac4."\r\n");
$frac5='} else {  ';
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, $frac5."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '$insert_value ="');
fwrite($archivo, $sql);
$frac6='";';
fwrite($archivo, $frac6."\r\n");
fwrite($archivo,"\r\n");
fwrite($archivo, "\r\n");
fwrite($archivo,'$retry_value = mysqli_query($db_connection,$insert_value);');
fwrite($archivo, "\r\n");
fwrite($archivo,"\r\n");

$frac7='$resultado=mysqli_query($db_connection, "SELECT '.$primary.'  FROM  '.$txt.'  WHERE '.$bus.' = '.$c.'".$'.$bus.'."'.$c.'" ); ';

fwrite($archivo, $frac7."\r\n");
fwrite($archivo, " \r\n");

$frac8=' while ($row =mysqli_fetch_array($resultado))   $'.$primary.' =$row['.$primary.' ]; ';
fwrite($archivo, $frac8."\r\n");
fwrite($archivo, " \r\n");

$frac9=' header("Location: index.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'"); ';

fwrite($archivo, $frac9."\r\n");
fwrite($archivo, " \r\n");


$frac10='mysqli_free_result($retry_value);';

fwrite($archivo, $frac10."\r\n");
fwrite($archivo, "}\r\n");

$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}
//------------------------------------------------------------------------------add2
//echo  'Archivo : '.$txt.'add2.php listo';
   
    $archivo = fopen($dir.$txt."add2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title>
<meta name="keywords" content="">
<meta name="description: formulario de registro" content="">
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="styles.css" />');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
   fwrite($archivo, '</head>
<!-- body -->
<body>
        <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
    
fwrite($archivo, '<h3>Registrarte</h3>
<form action="'.$txt.'add.php" method="POST">');
$s="$";

fwrite($archivo,"<input type='hidden' name=".$primary." value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'>");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


 foreach ($info_campo as $valor) {

    printf("Nombre:        %s\n", $valor->name);
    printf("Tabla:         %s\n", $valor->table);
    printf("Longitud máx.: %d\n", $valor->max_length);
    printf("Banderas:      %d\n", $valor->flags);
    printf("Tipo:          %d\n", $valor->type);
    fwrite($archivo, " \r\n");
    
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

//if($valor->flags==2 || $valor->flags==8 || $valor->flags==512 )
//fwrite($archivo, "<div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required>  </div>  \r\n");
//else
//fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required>  </div>  \r\n");
//min='1' max='5'

  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246  )//DECIMALES 
  fwrite($archivo, "<div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");


  if($valor->type == 7)//fechas
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
   if($valor->type == 10)
  fwrite($archivo, "<div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> ".$valor->name." </textarea> </div>  \r\n");
 

  if($valor->type == 253)//cadena
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' required> </div>  \r\n");


  
   }
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
   fwrite($archivo, "<div>
             <button type='submit' class='btn btn-success'>Registrate</button>
             </div>
             </form> \r\n");
fwrite($archivo, "<a href='index.php'>Regresar</a>
");
fwrite($archivo,"\r\n");

fwrite($archivo, "</body>
</html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------upd 
//echo  'Archivo : '.$txt.'upd.php listo';
   
    $archivo = fopen($dir.$txt."upd.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include 'db.php'; \r\n");
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, "\r\n");  
$c="'";
$frac1= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac1."\r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");
$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, $frac3."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '$update_value ="');
//----------------------------UPDATE--------------------------------------------
$cadena1="";
 $c="'";
 $p=".";
$sql = "UPDATE ".$txt." SET ";   
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.'='.' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
  $myString = substr($cadena1, 0, -2);
  $sql.= $myString." ";
  $sql.='  WHERE   '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ; ';
fwrite($archivo, $sql);
fwrite($archivo, "\r\n");
fwrite($archivo,'$retry_value = mysqli_query($db_connection,$update_value );');
fwrite($archivo, "\r\n");
//-----------------------------UPDATE-------------------------------------------
$frac9=' header("Location: index.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'"); ';
fwrite($archivo, $frac9."\r\n");
$frac10='mysqli_free_result($retry_value);';
fwrite($archivo, $frac10."\r\n");
$frac5='} else {  ';
fwrite($archivo, $frac5."\r\n");
$frac4='header("Location: index.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'");  ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac4."\r\n");
fwrite($archivo, "}\r\n");
$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------upd3 
//echo  'Archivo : '.$txt.'upd.php listo';
   
    $archivo = fopen($dir.$txt."upd3.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include 'db.php'; \r\n");
       //REQUEST
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, "\r\n");  
$c="'";
$frac1= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac1."\r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");
$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, $frac3."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '$update_value ="');
//----------------------------UPDATE--------------------------------------------
$cadena1="";
 $c="'";
 $p=".";
$sql = "UPDATE ".$txt." SET ";   
   foreach ($info_campo as $valor) {
      $cadena1.=$valor->name.'='.' '.$c.'"'.$p.'$'.$valor->name.$p.'"'.$c.', ';
   } 
  $myString = substr($cadena1, 0, -2);
  $sql.= $myString." ";
  $sql.='  WHERE   '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" ; ';
fwrite($archivo, $sql);
fwrite($archivo, "\r\n");
fwrite($archivo,'$retry_value = mysqli_query($db_connection,$update_value );');
fwrite($archivo, "\r\n");
//-----------------------------UPDATE-------------------------------------------
$frac9=' header("Location: '.$txt.'sel.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'"); ';
fwrite($archivo, $frac9."\r\n");
$frac10='mysqli_free_result($retry_value);';
fwrite($archivo, $frac10."\r\n");
$frac5='} else {  ';
fwrite($archivo, $frac5."\r\n");
$frac4='header("Location: '.$txt.'sel.php?'.$primary.'='.$c.'".$'.$primary.'."'.$c.'");  ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac4."\r\n");
fwrite($archivo, "}\r\n");
$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------upd2
//echo  'Archivo : '.$txt.'upd2.php listo';
   
    $archivo = fopen($dir.$txt."upd2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de actualizacion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="styles.css" />
');

fwrite($archivo, " \r\n");
fwrite($archivo, "<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$primary = utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$primary.' = '.$c.'".$'.$primary.'."'.$c.'" );');
fwrite($archivo, " \r\n");
fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
    
fwrite($archivo, '<h3>Actualiza</h3>
<form action="'.$txt.'upd.php" method="POST">');
$s="$";
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']);?> '>");
fwrite($archivo,"\r\n");
 foreach ($info_campo as $valor) {
   /*fwrite($archivo,"<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' class='form-input' value='<?php echo $".$valor->name."; ?>' required>  </div> ");*/
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");



  if($valor->type == 7)//fechas
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div>  \r\n");
 

  if($valor->type == 253)//cadena
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div>  \r\n");

    fwrite($archivo,"\r\n");
   }
   fwrite($archivo,"\r\n");
   fwrite($archivo,"<div> <button type='submit' class='btn btn-success'>actualiza</button> </div> </form>");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo, "<a href='index.php'>Regresar</a>");

fwrite($archivo, "</body>
</html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------del 
//echo  'Archivo : '.$txt.'del.php listo';
   
    $archivo = fopen($dir.$txt."del.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include 'db.php'; \r\n");
       //REQUEST
 $Idx= "$"."Idx= $"."_REQUEST['Idx'];";
 fwrite($archivo,$Idx);       
 fwrite($archivo, "\r\n");        
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."= $"."_REQUEST['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, "\r\n");  
$c="'"; $s="$";
$frac1= ' date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac1."\r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$primary.' LIKE '.$c.'".'.$s.'Idx."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");
$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, $frac3."\r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '$delete_value ="');
//----------------------------DELETE--------------------------------------------
$cadena1="";
 $c="'";
 $p=".";
$sql = 'DELETE FROM '.$txt.' WHERE '.$primary.' LIKE '.$c.'".'.$s.'Idx."'.$c.'"; ';   
fwrite($archivo, $sql);
fwrite($archivo, "\r\n");
fwrite($archivo,'$retry_value = mysqli_query($db_connection,$delete_value );');
fwrite($archivo, "\r\n");
//-----------------------------DELETE-------------------------------------------
$frac9=' header("Location: index.php?'.$primary.'='.$c.'".'.$s.'Idx."'.$c.'"); ';
fwrite($archivo, $frac9."\r\n");
$frac10='mysqli_free_result($retry_value);';
fwrite($archivo, $frac10."\r\n");
$frac5='} else {  ';
fwrite($archivo, $frac5."\r\n");
$frac4='header("Location: index.php?'.$primary.'='.$c.'".'.$s.'Idx."'.$c.'");  ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac4."\r\n");
fwrite($archivo, "}\r\n");
$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------del2
//echo  'Archivo : '.$txt.'del2.php listo';
   
    $archivo = fopen($dir.$txt."del2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de borrado" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="styles.css" />
');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    

fwrite($archivo, " <?php  \r\n");
fwrite($archivo, "$"."$primary = utf8_decode($"."_GET['$primary']); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> <!-- body --> <body> <div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
    
fwrite($archivo, '<h3>Borrar</h3>
<form action="'.$txt.'del.php" method="POST">');
$s="$";
fwrite($archivo, " \r\n");
/*fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']); ?>'>");*/
fwrite($archivo, " \r\n");
fwrite($archivo,"<div><input type='text' name='Idx' class='form-control' placeholder='Id a Borrar' class='form-input' value='<?php echo  $".$primary."; ?>' required></div> ");
fwrite($archivo, " \r\n");                
fwrite($archivo,"<div> <button type='submit' class='btn btn-success'>Borrar</button> </div> 
</form>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, "<a href='index.php'>Regresar</a>");

fwrite($archivo, "</body>
</html>");

fflush($archivo);
fclose($archivo);
}
/*
//------------------------------------------------------------------------------sel
//echo  'Archivo : '.$txt.'sel.php listo';
   
    $archivo = fopen($dir.$txt."sel.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
//<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">

');

fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' WHERE '.$bus.' LIKE '.$c.'".$'.$bus.'."'.$c.'" );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");
fwrite($archivo, " \r\n");
//Row
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
fwrite($archivo, " } \r\n");
fwrite($archivo, " mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '<h3>Seleccionar datos</h3>');



fwrite($archivo,  "<table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=".$field_cnt." style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr>");
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
 fwrite($archivo,  "</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<th><?php echo $".$valor->name."; ?></th>");
   fwrite($archivo,  " \r\n");
      }
fwrite($archivo, "</tr></table></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo, "<a href='index.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}

*/
//------------------------------------------------------------------------------sel
//echo  'Archivo : '.$txt.'sel.php listo';
   
    $archivo = fopen($dir.$txt."sel.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
//<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");




fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th>");
  $s="$";
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }

  fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
 fwrite($archivo, '<tr><form action="'.$txt.'upd3.php" method="POST">');
   fwrite($archivo,  " \r\n");
 
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']);?> '></tr>");
  fwrite($archivo,  " \r\n");

  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td>");  
     fwrite($archivo,  " \r\n");
   $uno++;
   }
   
 /*  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");*/
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<td><div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<td><div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type == 7)//fechas
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div></td>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<td><div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<td><div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<td><div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div></td>  \r\n");
 
  if($valor->type == 253)//cadena
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

   fwrite($archivo,  " \r\n");
      }
      
fwrite($archivo, "</form> \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   

fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."upd2.php?".$valor->name."=<?php echo $".$valor->name."; ?>><?php echo $".$valor->name."; ?> actualizar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."del2.php?".$valor->name."=<?php echo $".$valor->name."; ?>><?php echo $".$valor->name."; ?> borrar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo, "<a href='index.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------sel2
//echo  'Archivo : '.$txt.'sel2.php listo';
   
    $archivo = fopen($dir.$txt."sel2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
//<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");




fwrite($archivo, "<a href='index.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------sel3
//echo  'Archivo : '.$txt.'sel3.php listo';
   
    $archivo = fopen($dir.$txt."sel3.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
//<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th>");
  $s="$";
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }

  fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
 fwrite($archivo, '<tr><form action="'.$txt.'upd3.php" method="POST">');
   fwrite($archivo,  " \r\n");
 
fwrite($archivo,"<input type='hidden' name='".$primary."' value='<?php echo utf8_decode(".$s."_GET['".$primary."']);?> '></tr>");
  fwrite($archivo,  " \r\n");

  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td>");  
     fwrite($archivo,  " \r\n");
   $uno++;
   }
   
 /*  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");*/
   
  if($valor->type == 1  || $valor->type == 2 || $valor->type == 3 ||$valor->type == 8 || $valor->type == 9 )//numeros int 24
  fwrite($archivo, "<td><div><input type='number' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  
  if($valor->type == 0  || $valor->type == 4 || $valor->type == 5 || $valor->type == 6 || $valor->type == 246 )//DECIMALES 
  fwrite($archivo, "<td><div><input type='TEXT' name='".$valor->name."'   class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type == 7)//fechas
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>'  class='form-input' required> </div></td>  \r\n");
  if($valor->type == 10)
  fwrite($archivo, "<td><div><input type='date' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 11)
  fwrite($archivo, "<td><div><input type='time' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 12)
  fwrite($archivo, "<td><div><input type='datetime-local' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

  if($valor->type==249 || $valor->type==250 || $valor->type==251 || $valor->type==252)//blob
  fwrite($archivo, "<td><div><textarea id='".$valor->name."' name='".$valor->name."' rows='10' cols='100'> <?php echo $".$valor->name."; ?> </textarea> </div></td>  \r\n");
 
  if($valor->type == 253)//cadena
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");
  if($valor->type == 254)
  fwrite($archivo, "<td><div><input type='text' name='".$valor->name."'  class='form-control' placeholder='".$valor->name."' value='<?php echo $".$valor->name."; ?>' class='form-input' required> </div></td>  \r\n");

   fwrite($archivo,  " \r\n");
      }
      
fwrite($archivo, "</form> \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   

fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo, "<a href='index.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------sel4
//echo  'Archivo : '.$txt.'sel4.php listo';
   
    $archivo = fopen($dir.$txt."sel4.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
//<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");



fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."upd2.php?".$valor->name."=<?php echo $".$valor->name."; ?>><?php echo $".$valor->name."; ?> actualizar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");



fwrite($archivo, "<a href='index.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------sel5
//echo  'Archivo : '.$txt.'sel5.php listo';
   
    $archivo = fopen($dir.$txt."sel5.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
//<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Seleccion" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
<!-- end -->

<style>

body{
	margin:0;
	padding:0;
	background:#f1f1f1;
	font:70% Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
}
a{
	text-decoration:none;
	color:#057fac;
}
a:hover{
	text-decoration:none;
	color:#999;
}
h1{
	font-size:140%;
	margin:0 20px;
	line-height:80px;	
}
h2{
	font-size:120%;
}
#container{
	margin:0 auto;
	width:2800px;
	background:#fff;
	padding-bottom:20px;
}
#content{margin:0 20px;}
p.sig{	
	margin:0 auto;
	width:2800px;
	padding:1em 0;
}
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.$txt.'</h2> 
</div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo,  "<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th>");
  
 foreach ($info_campo as $valor) {
  fwrite($archivo,  "<th>".$valor->name."</th>");
  fwrite($archivo,  " \r\n");
   }
   
  fwrite($archivo, "
<?php
include 'db.php'; \r\n");
fwrite($archivo, "$"."$bus= utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, '$resultado=mysqli_query($db_connection, "SELECT * FROM '.$txt.' " );');
fwrite($archivo, "
while ($"."row =mysqli_fetch_array($"."resultado)) 
{ ");

//Row
fwrite($archivo, " \r\n");
$uno=1;
foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
   } 
 fwrite($archivo,  " ?>\r\n"); 
 fwrite($archivo,  "</tr><tr>");
  foreach ($info_campo as $valor) {
   if($uno==1){
   fwrite($archivo, "<td><a href=".$txt."del2.php?".$valor->name."=<?php echo $".$valor->name."; ?>><?php echo $".$valor->name."; ?> borrar</a></td>");  
   $uno++;
   }
   fwrite($archivo,  "<td><?php echo $".$valor->name."; ?></td>");
   fwrite($archivo,  " \r\n");
      }
      
   fwrite($archivo, " \r\n");
fwrite($archivo, " <?php } mysqli_free_result($"."resultado);\r\n");
fwrite($archivo, "mysqli_close($"."db_connection); \r\n");
fwrite($archivo, '?> 
');   
      
fwrite($archivo, "</tr></table>	</div>
</div></br></br>");



fwrite($archivo, "<a href='index.php'>Regresar</a>");

fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------ser

//echo  'Archivo : '.$txt.'ser.php listo';
   
    $archivo = fopen($dir.$txt."ser.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html> 
<html lang="en"> 
<head> 
<!-- basic --> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!-- mobile metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title> 
<meta name="keywords" content=""> 
<meta name="description: formulario de Buscar" content=""> 
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="styles.css" />
');

fwrite($archivo, '
<script src="jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "'.$txt.'ser2.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})

</script>
');

fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");   
fwrite($archivo, " <?php  \r\n");
fwrite($archivo, "$"."$bus = utf8_decode($"."_GET['$bus']); \r\n");
fwrite($archivo, "?> \r\n");

fwrite($archivo, '</head> 
<!-- body --> 
<body> 
<div> <h2>'.$txt.'</h2> </div>'); 
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");
fwrite($archivo, '
<h2>busca por <strong class="cur">Nombre</strong></h2>
<form action="'.$txt.'ser.php" method="POST">
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $'.$bus.'; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>
 <p><a href="index.php?'.$primary.'='.$c.'$'.$primary.$c.'; ?>">Regresar</a></p> ');
	
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");


fwrite($archivo, "</body> </html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------ser2

//echo  'Archivo : '.$txt.'ser2.php listo';
   
    $archivo = fopen($dir.$txt."ser2.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

$c="'";
fwrite($archivo, "<?php \r\n");
fwrite($archivo, "include 'db.php'; \r\n");
fwrite($archivo, '$html="";');
fwrite($archivo, " \r\n");
fwrite($archivo, '$busca= $_REQUEST["txtbusca"];');
fwrite($archivo, " \r\n");
fwrite($archivo, '$html.="<h2><strong class='.$c.'cur'.$c.'>Resultados</h2>";');
fwrite($archivo, " \r\n");
$frac2='$resultado=mysqli_query($db_connection, "'.$consulta.' WHERE '.$bus.' LIKE '.$c.'".$busca."'.$c.'" ); ';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac2."\r\n");
$frac3='if (mysqli_num_rows($resultado)>0) {';
fwrite($archivo, " \r\n");
fwrite($archivo, $frac3."\r\n");

fwrite($archivo, "while ($"."row =mysqli_fetch_array($"."resultado)) { ");
fwrite($archivo, " \r\n");
//Row

foreach ($info_campo as $valor) {
     $recibe= "$".$valor->name."=$"."row['".$valor->name."'];";
     fwrite($archivo,$recibe."\r\n");
     fwrite($archivo, "$"."html.= '<p><a href=".$txt."sel3.php?".$valor->name."=".$c.$p."$".$valor->name.$p.$c.">".$c.$p."$".$valor->name.$p.$c."</a></p></b>';");
     fwrite($archivo, " \r\n");
   } 
fwrite($archivo, " } \r\n");

fwrite($archivo, '$html.="</b>";');
fwrite($archivo, " \r\n");
fwrite($archivo, 'echo $html;');
fwrite($archivo, "\r\n");
fwrite($archivo, " } \r\n");
fwrite($archivo, 'else
echo 
"Is not found";');
fwrite($archivo, "\r\n");
$frac11='mysqli_free_result($resultado);';
fwrite($archivo,$frac11."\r\n");
$frac12= 'mysqli_close($db_connection);';
fwrite($archivo,$frac12."\r\n");
fwrite($archivo,"?>");

fflush($archivo);
fclose($archivo);
}


//------------------------------------------------------------------------------db

//echo  'Archivo : db.php listo';
   
    $archivo = fopen($dir."db.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo, "<?php \r\n");
fwrite($archivo, '
$servidor  ="localhost"; 
$usuario   ="yaprendo_test";  
$clave     ="us1317mx$";
$basedatos ="yaprendo_ProyectoDan";
$db_connection = mysqli_connect($servidor, $usuario, $clave, $basedatos) or die(mysql_error());
if (!$db_connection) {
	die("No se ha podido conectar a la base de datos");
}else
	echo mysqli_connect_error($db_connection);
');
fwrite($archivo,"?>\r\n");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------index

//echo  'Archivo : index.php listo';

   
    $archivo = fopen($dir."index.php","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {
fwrite($archivo, '<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");

fwrite($archivo,'<title>'.$txt.'</title>
<meta name="keywords" content="">
<meta name="description: index" content="">
<meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
<link rel="stylesheet" type="text/css" media="screen" href="style.css" />');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");    
   fwrite($archivo, '</head>
<!-- body -->
<body>'); 
fwrite($archivo, '
<!-- header -->
<header> 
  <!-- header inner -->

  <div class="head-top">
    <div class="container">
       <div class="row">
      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
          <div class="email"> <a href="#">Correo : jimmyvillatoro77@gmail.com</a> </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
         <div class="icon"> <i> <a href="#"><img src="icon/facebook.png"></a></i> <i> <a href="#"><img src="icon/twitter.png"></a></i> <i> <a href="linkedin.com/in/jimmy-villatoro-ab5292180"><img src="icon/linkedin.png"></a></i> <i> <a href="jimmyvillatoro77@gmail.com"><img src="icon/google+.png"></a></i> </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
          <div class="contact"> <a href="#">Contacto :  +521 961 177 2089</a> </div>
        </div>
      </div>
    </div>
    </div>
    <div class="container">
    <div class="row">
      <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
        <div class="menu-area">
          <div class="limit-box">
            <nav class="main-menu">
              <ul class="menu-area-main">
                <li class="active"> <a href="index.php">INICIO</a> </li>
                <li> <a href="https://desarrollawebs.kyte.site/">SERVICIOS</a> </li>
                <li> <a href="https://www.desarrollawebs.com/">ACERCA DE NOSOTROS</a> </li>
                <li> <a href="https://yaprendo.com/about_us.html">EQUIPO</a> </li>
                <li> <a href="https://yaprendo.com/contact_us.html">CONTACTANOS</a> </li>
                <li> <a href="#"><img src="images/search_icon.png" alt="#" /></a> </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
   <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">

        <div class="full">

          <div class="center-desk">
            <div class="logo"> <a href="index.html"><img src="images/logo.png" alt="#"></a> </div>
          </div>
        </div>
      </div>    
      <div class="about-bg">
  <div class="container">
    <div class="row">
       <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="abouttitle">
         <h2>Acerca de Nosotros</h2>
       </div>
       </div>
    </div>
  </div>
</div>
<!--state abouts -->
 <figure><img src="images/recepcion1024x700.jpg" alt="img"/></figure>
<div class="abouts"> <dir class="abouts-bg">
  <div class="container">
    <div class="row">
      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
        <div class="abouts-us">
          <h3>Acerda de<strong class="cur"> Nosotros</strong></h3>
          <p>Somos un grupo de desarrolladores que, de forma individual y colectiva, fijo los objetivos y tomo las decisiones estratégicas acerca de las metas, los medios, la administración y el control en la creación de proyectos en PHP y asume la responsabilidad tanto comercial como legal frente a terceros. Brindando de forma inmediata los archivos PHP, CSS, y JS para AGREGAR, ACTUALIZAR, SELECCIONAR, BUSCAR Y BORRAR. 
          </p>
          
          <p>Partiendo de cualquier tabla que usted nos presente, nuestro equipo de autómatas finitos crea los archivos y los comprime para descargarlos en tiempo real.</p>
          
          <p>La mayor parte del trabajo monótono de cada página está hecha y funciona desde el momento de su creación, y lo puede comprobar con los enlaces aquí en la ventana flotante.</p>
          
          <p>Sabemos que no todos los campos son necesarios en cada página pero colocamos todos, con la finalidad que usted solo utilice los que va a necesitar suprimiendo los que no.</p>
          
          <p>También creamos no solo la interfaz del usuario cuando pide los datos hacia la tabla, sino que con el comando POST enviamos los datos al archivo PHP que genera la consulta para las acciones en la base de datos, así que usted solo tendrá que adecuar a sus necesidades de diseño y lógica lo demás ya está hecho.</p>
          
          <p>Nos sentimos muy satisfechos, conociendo el desarrollo de software web sabemos lo tedioso y complicado que esto suele ser y según nosotros una tabla con estas acciones tarda mínimo 8 horas de desarrollo, pero nuestros autómatas lo hacen en menos de un segundo.</p>
          
           <p>Le recuerdo que solo esta página de índex tiene diseño, que involucra imágenes, menús y pie de página porque es informativa, y promocional pero las páginas de desarrollo para su tabla por cuestiones de acelerar el desarrollo que usted hará no incorpora diseño solo lo elemental para que se le facilite integrar los archivos a su proyecto.  Es un placer poder servirle.</p>
 </div>
      </div>
      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
        <div class="abouts-us">
         
        </div>
      </div>
    </div>
  </div>
  </dir> 
</div>
      
  <!-- end header inner --> 
</header>
<!-- end header --> ');
fwrite($archivo, " \r\n");
fwrite($archivo, " \r\n");   
$consulta = "SELECT * FROM ".$txt;
$resultado=mysqli_query($db_connection, $consulta);

while ($row =mysqli_fetch_array($resultado)){   
 $dato=$row[$primary];
 $dato2=$row[$bus];
}
fwrite($archivo, " \r\n");
fwrite($archivo,' </br>
<div class="vfpop">
<h3>'.$txt.'</h3>
<h3>Index</h3>
<a href="'.$txt.'add2.php?'.$primary.'='.$dato.'">Ver '.$txt.'Add2 AGREGAR</a></br>
<a href="'.$txt.'upd2.php?'.$primary.'='.$dato.'" >Ver '.$txt.'upd2 ACTUALIZAR</a></br>
<a href="'.$txt.'del2.php?'.$primary.'='.$dato.'" >Ver '.$txt.'del2 BORRAR</a></br>
<a href="'.$txt.'sel.php?'.$bus.'='.$dato2.'" >Ver '.$txt.'sel SELECCIONAR TOTAL</a></br>
<a href="'.$txt.'sel2.php?'.$bus.'='.$dato2.'" >Ver '.$txt.'sel SELECCIONAR ver</a></br>
<a href="'.$txt.'sel3.php?'.$bus.'='.$dato2.'" >Ver '.$txt.'sel SELECCIONAR editar</a></br>
<a href="'.$txt.'sel4.php?'.$bus.'='.$dato2.'" >Ver '.$txt.'sel SELECCIONAR actualizar</a></br>
<a href="'.$txt.'sel5.php?'.$bus.'='.$dato2.'" >Ver '.$txt.'sel SELECCIONAR borrar</a></br>
<a href="'.$txt.'ser.php?'.$bus.'='.$dato2.'" >Ver '.$txt.'ser BUSCAR</a></br> ');
fwrite($archivo, "  \r\n");
fwrite($archivo, "  \r\n");

fwrite($archivo,'<a href="../'.$txt.'.zip" download="../'.$txt.'.zip">Descargar en ZIP</a></br>');
fwrite($archivo, "  \r\n");
fwrite($archivo, "  \r\n");
fwrite($archivo, "<a href='index.php'>Inicio</a></div>");
fwrite($archivo, "  \r\n");
fwrite($archivo,' <footer>
 <div class="footer">
  <div class="container">
    <div class="row">
     <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
      <div class="Contact">
        
        <h3>Contactanos</h3>
        <ul class="contant_icon">
        <li> <a href="#"><img src="icon/location.png"></a></li> 
        <li> <a href="+52 1 961 177 2089"><img src="icon/tellephone.png"></a></li>
        <li> <a href="jimmyvillatoro77@gmail.com"><img src="icon/email.png"></a></li>
      
       </ul>
      </div>
     </div>
     <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
      <div class="Social">
        <h3>Enlaces</h3>
        <ul class="socil_link">
           <li><a href="#"><img src="icon/fb.png"></a></li>
      
        
        <li><a href="#"><img src="icon/tw.png"></a></li>
        <li> <a href="#"><img src="icon/lin.png"></a></li>
                <li> <a href="#"><img src="icon/insta.png"></a></li>
                </ul>
      </div>
      
     </div> 
     <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
      <div class="newsletter">
        <h3>Noticias por Correo</h3>
        <input class="new" placeholder="Ingrega tu Correo" type="Enter your email" >
        <button class="subscribe">subscribete</button>
      </div>
      
     </div>   
    </div>
  </div>
 </div>
 <div class="copyright">
  <div class="container">
    <p>Copyright 2021 Todos los derechos reservados para <a href="www.desarrollawebs.com"> Codigo Automata en PHP</a></p>
  </div>
 </div>
</footer>');
fwrite($archivo, "  \r\n");
fwrite($archivo, "  \r\n");
fwrite($archivo, "</body>
</html>");

fflush($archivo);
fclose($archivo);
}

//------------------------------------------------------------------------------style

//echo  'Archivo : db.php listo';
   
    $archivo = fopen($dir."style.css","w+b");
    if( $archivo == false ) {
      echo "Error al crear el archivo";
    }
    else
    {

fwrite($archivo, " \r\n");
fwrite($archivo, '
/*
project: css landingpage
author: Jimmy Villatoro
*/
body {
	color: #666666;
	font-size: 14px;
	font-family: "poppins", sans-serif;
	line-height: 1.80857;
	font-weight: normal;
	overflow-x: hidden;
}


a {
	color: #1f1f1f;
	text-decoration: none !important;
	outline: none !important;
	-webkit-transition: all .3s ease-in-out;
	-moz-transition: all .3s ease-in-out;
	-ms-transition: all .3s ease-in-out;
	-o-transition: all .3s ease-in-out;
	transition: all .3s ease-in-out;
}
h1, h2, h3, h4, h5, h6 {
	letter-spacing: 0;
	font-weight: normal;
	position: relative;
	padding: 0 0 10px 0;
	font-weight: normal;
	line-height: normal;
	color: #111111;
	margin: 0
}
h1 {
	font-size: 24px
}
h2 {
	font-size: 22px
}
h3 {
	font-size: 18px
}
h4 {
	font-size: 16px
}
h5 {
	font-size: 14px
}
h6 {
	font-size: 13px
}
*, *::after, *::before {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}
h1 a, h2 a, h3 a, h4 a, h5 a, h6 a {
	color: #212121;
	text-decoration: none!important;
	opacity: 1
}
button:focus {
	outline: none;
}
ul, li, ol {
	margin: 0px;
	padding: 0px;
	list-style: none;
}
p {
	margin: 0px;
	font-weight: 300;
	font-size: 15px;
	line-height: 24px;
}
a {
	color: #222222;
	text-decoration: none;
	outline: none !important;
}
a, .btn {
	text-decoration: none !important;
	outline: none !important;
	-webkit-transition: all .3s ease-in-out;
	-moz-transition: all .3s ease-in-out;
	-ms-transition: all .3s ease-in-out;
	-o-transition: all .3s ease-in-out;
	transition: all .3s ease-in-out;
}
img {
	max-width: 100%;
	height: auto;
}
/*----------------------------
    scroll to top area
----------------------------*/

.scrollup {
	float: right;
	position: absolute;
	color: #fff;
	right: 20px;
	padding: 0px 5px;
	text-transform: uppercase;
	font-weight: 600;
	background: #38c8a8;
	position: fixed;
	bottom: 20px;
	z-index: 99;
	text-align: center;
	color: #fff;
	cursor: pointer;
	border-radius: 0px;
	opacity: 0;
	backface-visibility: hidden;
	-webkit-backface-visibility: hidden;
	transform: scale(1);
	-moz-transform: scale(1);
	-o-transform: scale(1);
	-webkit-transform: scale(1);
	transition: .2s all ease;
	-moz-transition: .2s all ease;
	-o-transition: .2s all ease;
	-webkit-transition: .2s all ease;
	width: 50px;
	height: 50px;
	border-radius: 100%;
	line-height: 48px;
	font-size: 16px;
}
.scrollup.b-show_scrollBut {
	opacity: 1;
	visibility: visible;
}
.top_awro {
	background: #ee4a79 none repeat scroll 0 0;
	cursor: pointer;
	padding: 6px 8px;
	position: fixed;
	bottom: 59px;
	right: 20px;
	display: none;
	height: 45px;
	width: 45px;
	border-radius: 50%;
	text-align: center;
	line-height: 30px;
	transition: all 0.5s ease;
}
.sale_pro {
	background: #f25252 !important;
}
.margin_top_50 {
	margin-top: 50px;
}
.margin_bottom_30_all {
	margin-bottom: 30px;
}
.text_align_center {
	text-align: center;
}
/*---------------------------------------------------------------------
    header area
---------------------------------------------------------------------*/


.head-top {
	background: #ad2100;
	padding: 6px 0px;
}
.head-top .email a {
	color: #fff;
}
.head-top .email a:hover {
	text-decoration: none;
	color: #fff;
}
.head-top .icon {
	text-align: center;
	padding-top: 6px;
}
.head-top .icon i a {
	padding: 0px 3px;
}
.head-top .contact {
	text-align: right;
}
.head-top .contact a {
	color: #fff;
}
.head-top .contact a:hover {
	text-decoration: none;
	color: #fff;
}
.logo_section {
	background: #fff;
	min-height: 122px;
	text-align: center;
	line-height: 120px;
}
.logo {
	float: left;
}
nav.main-menu {
	float: right;
	margin-left: 0;
}
.menu-area-main li:hover a, .menu-area-main li:focus a {
	color: #b23011;
}
.menu-area-main li.active a {
	color: #b23011;
}
.right_cart_section {
	float: right;
	width: auto;
}
.right_cart_section ul {
	float: left;
	min-height: auto;
	margin: 0;
	padding: 12px 0 0;
}
.right_cart_section .cart_icons {
	padding: 18px 0 0;
}
 .main-menu ul > li nth:child(5) a {
padding-right: 0px;
}
.right_cart_section ul li {
	float: left;
	font-size: 17px;
	font-weight: 400;
	color: #fff;
	margin-right: 30px;
}
.right_cart_section ul.cart_update li {
	font-size: 13px;
	color: #ccc;
	line-height: normal;
	margin: 0;
	font-weight: 300;
}
.right_cart_section ul.cart_update li span {
	font-size: 18px;
	font-weight: 300;
	color: #fff;
	line-height: 21px;
}
.right_cart_section ul li i {
	margin-right: 10px;
	margin-top: 5px;
	float: left;
	color: #fff;
	font-size: 21px;
}
.right_cart_section ul li a {
	color: #fff;
}


/*-- end header middle --*/

.top-bar-info {
	background: #111111;
	padding: 5px 0px;
}
.top-menu-left {
	float: left;
}
.top-menu-left li {
	position: relative;
	display: inline-block;
	margin-right: 11px;
	padding-right: 12px;
}
.top-menu-left li::before {
	content: "";
	position: absolute;
	right: 0;
	top: 9px;
	height: 10px;
	border-right: 1px dotted #999;
}
.top-menu-left li:last-child::before {
	display: none;
}
.top-menu-left li:last-child {
	padding: 0px;
	margin: 0px;
}
.top-menu-left li a {
	color: #ffffff;
	font-size: 12px;
	text-transform: uppercase;
	text-decoration: none;
}
.top-menu-left li a:hover {
	color: #38c8a8;
}
.right-dropdown-language {
	float: right;
	margin-left: 12px;
}
.dropdown-bar .dropdown-link {
	position: absolute;
	z-index: 1009;
	top: 40px;
	left: 0;
	right: auto;
	min-width: 50px;
	padding: 15px;
	background: #ffffff;
	list-style: none;
	border: 2px solid #38c8a8;
	opacity: 0;
	visibility: hidden;
	-webkit-box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	-webkit-transition: opacity 0.2s ease 0s, visibility 0.2s linear 0s;
	-o-transition: opacity 0.2s ease 0s, visibility 0.2s linear 0s;
	transition: opacity 0.2s ease 0s, visibility 0.2s linear 0s;
	text-align: left;
}
.dropdown-bar:hover .dropdown-link {
	opacity: 1;
	visibility: visible;
	top: 25px;
}
.dropdown-bar.right-dropdown-language>a::after {
	font-family: "FontAwesome";
	content: "\f107";
	text-decoration: none;
	padding-left: 4px;
	color: #ffffff;
}
.right-dropdown-language>a {
	line-height: 10px;
	padding: 5px 5px;
	cursor: pointer;
}
.dropdown-bar .dropdown-link li a {
	color: #111111;
	display: block;
	font-size: 12px;
	line-height: 15px;
	padding: 5px 0;
}
.dropdown-bar .dropdown-link li a:hover {
	color: #38c8a8;
}
.dropdown-bar .dropdown-link li a img {
	margin-right: 7px;
}
.dropdown-bar .dropdown-link li.active {
	font-weight: bold;
}
.right-dropdown-language .dropdown-link {
	min-width: 100px;
	padding: 7px 10px;
	color: #111111;
}
.dropdown-bar {
	position: relative;
	padding: 0 5px;
	font-size: 13px;
}
.dropdown-bar .dropdown-link.right-sd {
	left: auto;
	right: 0;
}
.right-dropdown-currency {
	float: right;
	margin-left: 12px;
}
.dropdown-bar.right-dropdown-currency>a::after {
	font-family: "FontAwesome";
	content: "\f107";
	text-decoration: none;
	padding-left: 4px;
	color: #ffffff;
}
.right-dropdown-currency>a {
	line-height: 10px;
	padding: 5px 5px;
	cursor: pointer;
	color: #ffffff;
}
.right-dropdown-currency .dropdown-link {
	min-width: 100px;
	padding: 7px 10px;
	color: #111111;
}
.right-dropdown-currency .dropdown-link {
	min-width: 55px;
	padding: 7px 10px;
}
.right-dropdown-currency .dropdown-link li a span.symbol {
	margin-right: 7px;
}
#login-modal .modal-content {
	border-radius: 0px;
}
#login-modal .modal-content .modal-header {
	background: #38c8a8;
	border-radius: 0;
}
#login-modal .modal-content .modal-body .form-group input {
	background: #ffffff;
	border: 1px solid #c8c8c8;
	border-radius: 0px;
}
#login-modal .modal-content .modal-body .form-group input:focus {
	border: 1px solid #c8c8c8 !important;
}
#login-modal .modal-content form {
	margin-bottom: 10px;
}
.modal-title {
	padding: 0px;
	color: #ffffff;
	font-size: 18px;
	text-transform: uppercase;
}
.btn-template-outlined {
	background: #111111;
	color: #ffffff;
	border: none;
	border-radius: 0px;
}
.btn-template-outlined i {
	padding-right: 10px;
}
.text-muted {
	padding: 10px 0px;
}
.slogan-line {
	float: right;
	color: #ffffff;
	font-size: 13px;
}
.middle-area {
	padding: 30px 0px;
}
.header-search {
	padding: 3px 0px;
}
.header-search form {
	position: relative;
	-webkit-box-shadow: 0px 1px 10px -1px rgba(0, 0, 0, 0.2);
	box-shadow: 0px 1px 10px -1px rgba(0, 0, 0, 0.2);
}
.header-search .btn-group.bootstrap-select {
	position: absolute;
	left: 0px;
	top: 0px;
}
.header-search input {
	width: 100%;
	min-height: 45px;
	border-radius: 0px;
	border: none;
	padding-left: 15px;
	border: 1px solid #e0e7ed;
}
.header-search form .search-btn {
	position: absolute;
	right: 0;
	top: 0;
	border: 0;
	color: #fff;
	font-size: 20px;
	padding: 4px 15px;
	border-radius: 0px;
	background-color: #38c8a8;
	cursor: pointer;
}
.header-search form .search-btn:hover {
	background: #111111;
}
.cart-box {
	float: right;
	margin-left: 10px;
	position: relative;
}
.cart-content-box {
	position: absolute;
	z-index: 1009;
	top: 40px;
	left: auto;
	right: 0;
	min-width: 250px;
	max-width: 250px;
	padding: 15px;
	background: #ffffff;
	list-style: none;
	border: 2px solid #38c8a8;
	opacity: 0;
	visibility: hidden;
	-webkit-box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	text-align: left;
	-webkit-transform: scaleY(0);
	transform: scaleY(0);
	-webkit-transform-origin: 0 0 0;
	transform-origin: 0 0 0;
	-webkit-transition: all 0.3s ease 0s;
	transition: all 0.3s ease 0s;
	transition: all 0.3s ease 0s;
}
.cart-box:hover .cart-content-box {
	opacity: 1;
	visibility: visible;
	top: 100%;
	-webkit-transform: scaleY(1);
	transform: scaleY(1);
}
.inner-cart {
	background: #38c8a8;
	border-radius: 2px;
	padding: 0px;
	color: #ffffff;
	position: relative;
	width: 40px;
	height: 40px;
	text-align: center;
}
.cart-box .inner-cart:hover {
	color: #ffffff;
}
.line-cart {
	float: left;
	line-height: 40px;
	margin-right: 9px;
}
.cart-box a {
	display: inline-block;
}
.cart-box a:hover {
	color: #38c8a8;
}
.cart-box a span.icon {
	background: #38c8a8;
	width: 30px;
	height: 40px;
	display: inline-block;
	line-height: 40px;
	text-align: center;
	color: #ffffff;
	position: relative;
	border-radius: 2px;
}
.cart-box a .p-up {
	position: absolute;
	right: -8px;
	top: -8px;
	line-height: initial;
	background: #38c8a8;
	padding: 3px;
	border-radius: 50%;
	width: 17px;
	height: 17px;
	font-size: 12px;
	text-align: center;
	line-height: 10px;
}
.wish-box {
	float: right;
}
.wish-box a {
	display: inline-block;
}
.wish-box a:hover {
	color: #38c8a8;
}
.wish-box a span.icon {
	background: #38c8a8;
	width: 40px;
	height: 40px;
	display: inline-block;
	line-height: 40px;
	text-align: center;
	color: #ffffff;
	position: relative;
	border-radius: 2px;
}
.wish-box a span.icon:hover {
	background: #111111;
}
.cart-content-right {
	padding: 5px 0px;
}
.cart-content-box .items {
	text-align: center;
}
.product-media {
	width: 60px;
	float: left;
	position: relative;
}
.cart-content-box .items:hover .product-media::before {
	transform: scale(1);
	-webkit-transform: scale(1);
	-moz-transform: scale(1);
	-ms-transform: scale(1);
	-o-transform: scale(1);
}
.product-media::before {
	position: absolute;
	content: "";
	z-index: 2;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background-color: #38c8a8;
	opacity: 0.4;
	transform: scale(0);
	-webkit-transform: scale(0);
	-moz-transform: scale(0);
	-ms-transform: scale(0);
	-o-transform: scale(0);
	transition: all 0.5s ease;
	-webkit-transition: all 0.5s ease;
	-moz-transition: all 0.5s ease;
	-o-transition: all 0.5s ease;
}
.cart-content-box .items .item .remove {
	position: absolute;
	right: 0px;
	top: 0px;
	background: #38c8a8;
	color: #ffffff;
	width: 20px;
	height: 20px;
	line-height: 18px;
	border-radius: 2px;
}
.cart-content-box .items .item {
	margin-bottom: 10px;
	padding-bottom: 10px;
	border-bottom: 1px solid #e0e7ed;
	position: relative;
}
.cart-content-box .items .item .product-info {
	padding-top: 10px;
	padding-left: 71px;
	text-align: left;
}
.cart-content-box .items .item .remove:hover {
	background: #111111;
}
.subtotal {
	text-align: left;
	text-transform: capitalize;
	color: #38c8a8;
	font-weight: 500;
	margin-bottom: 15px;
}
.subtotal span {
	font-weight: bold;
	color: #111111;
	padding-left: 15px;
	float: right;
}
.actions .btn-process {
	padding: 5px 16px;
	color: #ffffff;
	font-family: "Roboto", sans-serif;
	font-size: 14px;
	border-radius: 2px;
	overflow: hidden;
}
.actions .btn-process:hover {
	color: #ffffff;
}
.line-cart {
	position: relative;
}
.wish-box a span.icon span {
	position: absolute;
	right: -8px;
	top: -8px;
	line-height: initial;
	background: #38c8a8;
	padding: 3px;
	border-radius: 50%;
	width: 17px;
	height: 17px;
	font-size: 12px;
}
.main-menu {
	text-align: center;
}
.main-menu ul {
	margin: 0;
	list-style-type: none;
}
.main-menu ul>li {
	display: inline-block;
	position: relative;
}
.main-menu ul > li a {
	padding: 54px 36px 0 36px;
	line-height: 20px;
	font-size: 16px;
	display: block;
	font-weight: 500;
	color: #616361;
	text-transform: uppercase;
}
.main-menu ul li:last-child a {
	padding-right: 0;
}
.sub-down li {
	background: #ffffff;
}
.main-menu ul>li .sub-down li a {
	color: #114c7d;
	font-size: 15px;
	text-transform: capitalize;
	font-weight: 300;
	padding: 12px 5px;
	position: relative;
	border-bottom: solid #eee 1px;
}
.main-menu ul>li .sub-down li a::before {
}
.main-menu ul>li .sub-down li a:hover {
	color: #111111;
}
.main-menu ul>li .sub-down li a:hover::before {
}
.main-menu ul li:first-child {
	margin-left: 0;
}
.main-menu ul>li>ul {
	opacity: 0;
	position: absolute;
	text-align: left;
	top: 100%;
	-webkit-transform: scaleY(0);
	transform: scaleY(0);
	-webkit-transform-origin: 0 0 0;
	transform-origin: 0 0 0;
	-webkit-transition: all 0.3s ease 0s;
	transition: all 0.3s ease 0s;
	visibility: hidden;
	width: 240px;
	z-index: 999;
	background: #fff;
	-webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, .175);
	box-shadow: 0 6px 12px rgba(0, 0, 0, .175);
}
.main-menu>ul>li:hover>ul {
	-webkit-transform: scaleY(1);
	transform: scaleY(1);
	visibility: visible;
	opacity: 1;
}
.main-menu ul>li>ul>li {
	margin: 0px;
	position: relative;
	display: block;
}
.main-menu ul>li>ul>li:hover>ul {
	-webkit-transform: scaleY(1);
	transform: scaleY(1);
	visibility: visible;
	opacity: 1;
	left: 100%;
	top: 10px;
}
.main-menu ul>li>ul>li>a {
	background: none !important;
}
.mean-container .mean-nav {
	margin-top: 0px;
	position: absolute;
	top: 100%;
}
.main-menu ul>li {
	position: inherit;
	display: inline-block;
	vertical-align: middle;
}
.main-menu ul>li:nth-child (6) {
padding-right: 0px;
}
.nav>li {
	position: inherit;
	display: inline-block;
	vertical-align: middle;
}
.megamenu .sub-down {
	max-width: 1140px;
	width: 100%;
	left: 0;
	margin: 0 auto;
	right: 0;
	padding: 15px 0px;
}
.sub-full {
}
.simple-down {
	padding: 15px;
}
.megamenu-categories {
	padding: 10px 0px;
}
.sub-full.megamenu-categories li {
	display: block;
}
.megamenu .sub-full.megamenu-categories ol li a {
	padding: 5px 0px;
	font-size: 15px !important;
	font-weight: 500;
}
.sub-full.megamenu-categories ol li .category-title {
	padding: 15px 0px;
	font-size: 16px;
	font-weight: 600;
	text-transform: uppercase;
}
.sub-full.megamenu-categories ol li .category-box a {
	padding: 5px 0px;
}
.menu-add {
	padding: 30px 15px;
}
.menu-add img {
	width: 100%;
}
.main-w img {
	width: 100%;
}
.women-box {
	position: relative;
}
.women-box::before {
	content: "";
	position: absolute;
	background: rgba(0, 0, 0, 0.3);
	width: 100%;
	height: 100%;
}
.banner-up-text {
	position: absolute;
	bottom: 10px;
	left: 0px;
	right: 0px;
	text-align: center;
}
.text-a {
	color: #fff;
	text-transform: uppercase;
	font-size: 40px;
	line-height: 40px;
	font-weight: 700;
}
.text-b {
	color: #fff;
	font-size: 28px;
	text-transform: uppercase;
	line-height: 30px;
	padding: 20px 0px;
}
.text-c {
	color: #ffffff;
	font-size: 31px;
	font-weight: 300;
	text-transform: uppercase;
	line-height: 30px;
	padding-bottom: 20px;
}
.megamenu .sub-full.megamenu-categories .women-box .banner-up-text a {
	background: #111111;
	color: #ffffff !important;
	display: inline-block;
	padding: 10px 16px;
	border-radius: 2px;
	overflow: hidden;
	font-size: 16px;
}
.sticky-wrapper .sticky-wrapper-header {
	z-index: 20 !important;
	background: #ffffff;
}
.is-sticky .sticky-wrapper-header .middle-area {
	padding: 10px 0px
}
.sticky-wrapper:not(.is-sticky) {
	height: auto !important;
}
.hover-btn {
	display: inline-block;
	vertical-align: middle;
	-webkit-transform: perspective(1px) translateZ(0);
	transform: perspective(1px) translateZ(0);
	box-shadow: 0 0 1px rgba(0, 0, 0, 0);
	position: relative;
	background: #111111;
	-webkit-transition-property: color;
	transition-property: color;
	-webkit-transition-duration: 0.3s;
	transition-duration: 0.3s;
}
.hover-btn::before {
	content: "";
	position: absolute;
	z-index: -1;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	background: #38c8a8;
	-webkit-transform: scaleX(0);
	transform: scaleX(0);
	-webkit-transform-origin: 50%;
	transform-origin: 50%;
	-webkit-transition-property: transform;
	transition-property: transform;
	-webkit-transition-duration: 0.3s;
	transition-duration: 0.3s;
	-webkit-transition-timing-function: ease-out;
	transition-timing-function: ease-out;
	display: block !important;
}
.hover-btn:hover::before, .hover-btn:focus::before, .hover-btn:active::before {
	-webkit-transform: scaleX(1);
	transform: scaleX(1);
}
.hover-btn:hover, .hover-btn:focus, .hover-btn:active {
	color: white;
	box-shadow: none;
}
.btn-secondary.focus, .btn-secondary:focus {
	box-shadow: none;
}
.img-responsive {
	max-width: 100%;
}
.padding_right_15_inner {
	padding-right: 15px;
}
.padding_left_15_inner {
	padding-left: 15px;
}
.dark_bg {
	background: #114c7d;
}
/*---------------------------------------------------------------------
    top banner area
---------------------------------------------------------------------*/

.top-banner-slider {
	overflow: hidden;
	clear: both;
	height: 600px;
}
.top-banner-slider .heroslider {
	margin: 0px;
	padding: 0px;
	border: none;
	position: relative;
	border-radius: 0;
}
.swiper-overlay {
	height: 100%;
	position: relative;
}
.swiper-overlay {
	background: rgba(0, 0, 0, 0.5);
	content: "";
	width: 100%;
	height: 100%;
	left: 0px;
	top: 0px;
}
.heroslider .container {
	position: relative;
	height: 100%;
	padding-left: 0;
	padding-right: 0;
	z-index: 5;
}
.swiper-container {
	width: 100%;
	height: 100%;
}
.heroslider .slider-01 {
	width: 100%;
	background-image: url(../images/slider-01.jpg);
	background-size: cover;
	background-position: center;
}
.heroslider .slider-02 {
	width: 100%;
	background-image: url(../images/slider-02.jpg);
	background-size: cover;
	background-position: center;
}
.heroslider .slider-03 {
	width: 100%;
	background-image: url(../images/slider-03.jpg);
	background-size: cover;
	background-position: center;
}
.heroslider .slides li {
	height: 600px;
}
.top-banner-slider .heroslider .slides li::before {
	content: "";
	position: absolute;
	background: rgba(0, 0, 0, 0.4);
	height: 100%;
	width: 100%;
	left: 0px;
	top: 0px;
}
.top-banner-slider .flex_caption3 {
	position: absolute;
	z-index: 30;
	left: 0;
	right: 0;
	bottom: 50px;
	margin: 0 -15px;
	display: flex;
}
a.slide_banner {
	position: relative;
	display: inline-block;
	margin: 0 12px 0 15px;
}
.slide1_banner1 {
	width: 570px;
}
.slide1_banner2 {
	width: 270px;
}
.slide1_banner3 {
	width: 270px;
}
.top-banner-slider .flex_caption1 {
	text-align: center;
	position: absolute;
	z-index: 30;
	left: 0;
	right: 0;
	margin: 0 auto;
	top: 31%;
	max-width: 720px;
	width: 100%;
	text-transform: uppercase;
	color: #333;
}
.top-banner-slider .flex_caption1 .title1 {
	font-size: 36px;
	font-weight: 300;
	color: #ffffff;
}
.top-banner-slider .flex_caption1 .title2 {
	font-size: 60px;
	font-weight: 900;
	color: #ffffff;
}
.top-banner-slider .flex_caption2 {
	text-align: center;
}
.top-banner-slider .flex_caption2 {
	position: absolute;
	z-index: 30;
	left: 0;
	top: 20%;
	display: table;
	width: 177px;
	height: 177px;
	background-color: #242424;
}
.top-banner-slider .flex_caption2 .middle {
	display: table-cell;
	vertical-align: middle;
	text-transform: uppercase;
	text-align: center;
	font-weight: 700;
	line-height: 31px;
	font-size: 26px;
	color: #fff;
	transition: all 0.1s ease-in-out;
	-webkit-transition: all 0.1s ease-in-out;
}
.top-banner-slider .flex_caption2 .middle:hover {
	background: #38c8a8;
}
.top-banner-slider .flex_caption2 span {
	display: block;
	font-weight: 100;
	line-height: 36px;
	font-size: 34px;
}
a.slide_banner::before {
	content: "";
	position: absolute;
	left: 0;
	top: 0;
	right: 0;
	bottom: 0;
	opacity: 0;
	border: 2px solid #ffffff;
	transition: all 0.1s ease-in-out;
	-webkit-transition: all 0.1s ease-in-out;
}
a.slide_banner:hover::before {
	left: -7px;
	top: -7px;
	right: -7px;
	bottom: -7px;
	opacity: 1;
}
.flex-control-nav {
	background: #38c8a8;
	bottom: 0px;
	position: relative;
}
.flex-control-nav li {
	line-height: 10px;
}
.flex-control-paging li a {
	background: rgba(255, 255, 255, 1);
	border: 2px solid #ffffff;
}
.flex-control-paging li a.flex-active {
	border: 2px solid #ffffff;
}
.flex-direction-nav a {
	background: #111111;
	text-align: center;
}
.heroslider:hover .flex-direction-nav .flex-prev:hover {
	background: #38c8a8;
}
.heroslider:hover .flex-direction-nav .flex-next:hover {
	background: #38c8a8;
}
.flex-direction-nav a::before {
	color: #ffffff;
}
.top-banner-slider .swiper-pagination {
	padding: 10px 0px;
}
.heroslider .swiper-pagination {
	bottom: 0px;
	background: #38c8a8;
}
.heroslider .swiper-pagination .swiper-pagination-bullet-active {
	background: #fff;
}
.heroslider .swiper-pagination::before {
	content: "";
	width: 22px;
	height: 22px;
	position: absolute;
	left: -10px;
	top: 4px;
	z-index: -1;
	background: #e12d4f;
	-webkit-transform: rotate(45deg);
	transform: rotate(45deg);
}
.heroslider .swiper-pagination::after {
	content: "";
	width: 22px;
	height: 22px;
	position: absolute;
	right: -10px;
	top: 4px;
	z-index: -1;
	background: #e12d4f;
	-webkit-transform: rotate(45deg);
	transform: rotate(45deg);
}
.heroslider .swiper-pagination.swiper-pagination-bullets-dynamic {
	overflow: visible;
	width: 110px !important;
}
.heroslider .swiper-pagination .swiper-pagination-bullet {
	opacity: 1;
}
input[type="checkbox"].styled:checked+label:after, input[type="radio"].styled:checked+label:after {
	font-family: "FontAwesome";
	content: "\f00c";
}
input[type="checkbox"] .styled:checked+label::before, input[type="radio"] .styled:checked+label::before {
	color: #fff;
}
input[type="checkbox"] .styled:checked+label::after, input[type="radio"] .styled:checked+label::after {
	color: #fff;
}
/*---------------------------------------------------------------------
    layout new css 
---------------------------------------------------------------------*/

.contact_form {
	background: #114c7d;
	padding: 45px;
}
.carousel-control-next {
	left: 0px;
	bottom: 109px;
}
.carousel-control-prev {
	bottom: 68px;
	bottom: 0;
}
.full-slider_cont {
	background-color: #fff;
	padding-top: 50px;
}
.full-slider_cont h1 {
	font-size: 65px;
	line-height: 72px;
	color: #110707;
}
.dark_brown {
	color: #ad2100;
	font-weight: bold;
}
.full-slider_cont p {
	font-weight: 400;
	font-size: 17px;
	line-height: 34px;
	color: #262424;
	padding: 19px 0px 70px 0px;
}
.Currency {
	background-color: #fff;
	padding: 90px 0px;
}
.Currency .titlepage {
	text-align: center;
	padding-bottom: 65px;
}
.Currency .titlepage h2 {
	font-weight: 500;
	line-height: 72px;
	font-size: 40px;
	color: #080404;
}
.cur {
	color: #ad2100;
	font-weight: 500;
}
.Currency .three-box {
	border-top: #ff0000 solid 2px;
	text-align: center;
}
.Currency .three-box figure {
	margin: 0px;
}
.Currency .three-box figure img {
	width: 100%;
}
.Currency .three-box .Bitcoin {
	position: relative;
	margin-top: -60px !important;
	text-align: center;
	box-shadow: #ddd 0px 1px 1px 1px;
	background-color: #fff;
	padding: 0px 20px 26px 20px;
	margin: 0 auto;
	width: 310px;
}
.Currency .three-box .Bitcoin i img {
	margin-top: -36px;
}
.Currency .three-box .Bitcoin p {
	padding-top: 20px;
	font-size: 15px;
	line-height: 23px;
	color: #3e3c3c;
}
.Currency .three-box .Bitcoin h3 {
	font-size: 27px;
	line-height: 32px;
	font-weight: 500;
	padding-top: 10px;
}
.Currency .three-box .read-more {
	padding: 11px 20px;
	background-color: #000;
	color: #fff;
	display: inline-block;
	margin-top: 26px;
	font-weight: 400;
	font-size: 17px;
	line-height: 20px;
}
.Currency .three-box .read-more:hover {
	background-color: #ad2100;
}
.abouts {
	display: flow-root;
	background: #fff;
}
.abouts .abouts-bg .abouts-us h3 {
	font-size: 40px;
	line-height: 72px;
	font-weight: 500;
	margin-bottom: 0px;
	padding: 40px 0px;
	text-transform: uppercase;
}
.abouts-us p {
	line-height: 29px;
	font-size: 16px;
	font-weight: 400;
	color: #000;
	padding-top: 0px;
	padding: 30px 0px;
}
.abouts .abouts-bg .abouts-us figure {
	margin: 0px;
}
.abouts .abouts-bg .abouts-us figure img {
	width: 100%;
}
.abouts .abouts-bg {
	margin: 0;
	padding-left: 0;
}
.service {
	background-color: #fff;
	padding-top: 90px;
}
.service .STRONG {
	background-color: #100505;
	text-align: center;
	padding: 40px 40px;
}
.service .STRONG h3 {
	font-size: 25px;
	line-height: 30px;
	color: #fff;
	padding-top: 40px;
}
.service .STRONG p {
	font-size: 16px;
	line-height: 25px;
	color: #fff;
}
.service .world {
	background-color: #ad2100;
	text-align: center;
	padding: 40px 40px;
	margin-top: 30px;
}
.service .world h3 {
	font-size: 25px;
	line-height: 30px;
	color: #fff;
	padding-top: 40px;
}
.service .world p {
	font-size: 16px;
	line-height: 25px;
	color: #fff;
}
.service .service-box h2 {
	font-weight: 500;
	line-height: 35px;
	font-size: 40px;
	color: #080404;
	padding-bottom: 20px;
	text-transform: uppercase;
}
.cur {
	color: #ad2100;
	font-weight: 500;
}
.service .service-box p {
	color: #8f8f8f;
}
.service .service-box figure {
	margin: 0;
}
.service-box figure {
	box-shadow: 0 0 40px -17px rgba(0,0,0,.5);
	float: left;
	width: 100%;
	margin-top: 25px !important;
	text-align: center;
	padding: 50px;
}
.experts {
	padding-top: 90px;
}
.experts .titlepage2 {
	padding-bottom: 32px;
}
.experts .titlepage2 h2 {
	font-weight: 500;
	line-height: 50px;
	font-size: 40px;
	color: #080404;
	text-transform: uppercase;
	padding-bottom: 0px;
}
.experts .experts-box {
	background-color: #060402;
}
.experts .experts-box {
	padding-top: 50px;
	padding-bottom: 35px;
}
.experts .experts-box .experts-threebox {
	text-align: center;
}
.experts .experts-box .experts-threebox figure {
	margin: 0px;
}
.experts .experts-box .experts-threebox figure img {
	width: 100%;
}
.experts .experts-box .experts-threebox h3 {
	font-size: 20px;
	line-height: 25px;
	text-transform: uppercase;
	color: #fff;
	padding: 35px 0px 0px 0px;
}
.experts .experts-box .experts-threebox p {
	padding-bottom: 30px;
	padding-top: 10px;
	color: #818080;
	font-size: 16px;
	line-height: 25px;
}
.experts .experts-box .experts-threebox .icon i a {
	padding: 0px 3px;
}
.Request {
	background-color: #fff;
	padding-top: 90px;
	padding-bottom: 90px;
}
.Request .titlepage3 {
	padding-bottom: 50px;
}
.Request .titlepage3 h2 {
	font-size: 40px;
	line-height: 50px;
	color: #100b0b;
	padding-bottom: 0px;
}
.form-control {
	border: #b1b0b0 solid 2px;
	margin-bottom: 30px;
	border-radius: inherit;
	padding: 16px 19px;
	color: #cfcece;
}
.form-control:focus, .form-control:hover {
	border: #b1b0b0 solid 2px !important;
}
.textarea {
	margin-bottom: 30px;
	padding: 71px 19px;
	color: #655f5f !important;
	width: 100%;
	border: #b1b0b0 solid 2px;
	border-radius: inherit;
}
.send-btn {
	margin-left: 15px;
	font-size: 16px;
	border: #000000 solid 2px;
	padding: 16px 70px;
	background-color: #000000;
	color: #fff;
}
.send-btn:hover {
	background-color: #ff0000;
	border: #ff0000 solid 2px;
	color: #fff;
}
.Request-box {
	position: relative;
}
.Request .Request-box figure {
	margin: 0;
	position: relative;
}
.Request .Request-box figure img {
	width: 100%;
}
.Request-box .Register {
	position: absolute;
	top: 0;
	text-align: center;
	padding: 118px 55px;
}
.Request .Request-box .Register h3 {
	font-size: 32px;
	line-height: 43px;
	color: #fff;
	font-weight: bold;
	text-transform: uppercase;
}
.Request .Request-box .Register p {
	line-height: 26px;
	font-size: 17px;
	color: #fff;
}
.Request .Request-box .Register a {
	background-color: #fff;
	border: #fff solid 1px;
	padding: 10px 35px;
	display: inline-block;
	margin-top: 20px;
	color: #ff0000;
}
.Request .Request-box .Register a:hover {
	background-color: #ff0000;
	color: #fff;
	border: #ff0000 solid 1px;
}
.footer {
	background-color: #2b2a2a;
	padding: 80px 0px;
}
.footer .Contact h3 {
	color: #fff;
	font-size: 17px;
	line-height: 30px;
	display: block;
	padding-bottom: 25px;
	text-transform: uppercase;
}
.footer .Contact i a {
	border: #fff solid 1px;
	padding: 3% 11%;
	display: inline-block;
}
.footer .Social h3 {
	color: #fff;
	font-size: 17px;
	line-height: 30px;
	display: block;
	padding-bottom: 25px;
	text-transform: uppercase;
}
ul.contant_icon {
	list-style: none;
	margin: 0;
	padding: 0;
	width: 100%;
	float: left;
}
ul.contant_icon li {
	float: left;
	width: 33.33%;
	height: 70px;
	border: solid #fff 1px;
	margin: 0 -1px 0 0;
	text-align: center;
	display: flex;
	justify-content: center;
	align-items: center;
}
ul.socil_link {
	list-style: none;
	margin: 0;
	padding: 0;
	width: 100%;
	float: left;
}
ul.socil_link li {
	float: left;
	padding-right: 22%;
	height: 70px;
	margin: 0 -1px 0 0;
	text-align: center;
	display: flex;
	justify-content: center;
	align-items: center;
}
ul.socil_link li:last-child {
	padding-right: 0;
}
.footer .newsletter h3 {
	color: #fff;
	font-size: 17px;
	line-height: 30px;
	display: block;
	padding-bottom: 25px;
	text-transform: uppercase;
}
.footer .newsletter .new {
	padding: 25px 40px;
	padding: 21px 26px;
	border-radius: 10px;
	border: #fff solid 1px;
	width: 67%;
}
.footer .newsletter .subscribe {
	padding: 21px 48px;
	margin-left: -28px;
	border: #f00 solid 1px;
	background: #f00;
	border-radius: 10px;
	color: #fff;
	text-transform: uppercase;
}
.copyright {
	background-color: #ad2100;
	padding: 10px 0px;
}
.copyright p {
	color: #fff;
	font-size: 16px;
	text-align: center;
}
/*---------------------------------------------------------------------
    ener page css
---------------------------------------------------------------------*/



.about-bg {
	background-color: #ad2100;
	margin-bottom: 90px;
}
.about-bg .abouttitle h2 {
	color: #fff;
	text-transform: uppercase;
	font-size: 40px;
	line-height: 45px;
	padding: 40px 0;
	font-weight: 500;
	text-align: center;
}
.Currency-bg {
	background-color: #ad2100;
}
.Currency-bg .abouttitle h2 {
	color: #fff;
	text-transform: uppercase;
	font-size: 40px;
	line-height: 45px;
	padding: 40px 0;
	font-weight: 500;
	text-align: center;
}
.Request-bg {
	background-color: #ad2100;
}
.Request-bg .abouttitle h2 {
	color: #fff;
	text-transform: uppercase;
	font-size: 40px;
	line-height: 45px;
	padding: 40px 0;
	font-weight: 500;
	text-align: center;
}
.Team-bg {
	background-color: #ad2100;
}
.Team-bg .abouttitle h2 {
	color: #fff;
	text-transform: uppercase;
	font-size: 40px;
	line-height: 45px;
	padding: 40px 0;
	font-weight: 500;
	text-align: center;
}
/** slider arrow **/


#myCarousel .carousel-control-prev, #myCarousel .carousel-control-next {
	width: 62px;
	height: 60px;
	background: #fffdfd;
	opacity: 1;
	font-size: 30px;
	color: #000;
}
#myCarousel .carousel-control-prev:hover, #myCarousel .carousel-control-next:hover, #myCarousel .carousel-control-prev:focus, #myCarousel .carousel-control-next:focus {
	background: #110d0c;
	color: #fff;
}
#myCarousel a.carousel-control-prev {
	position: absolute;
	left: 82px;
	bottom: 10px;
	top: inherit;
}
#myCarousel a.carousel-control-next {
	position: absolute;
	left: 10px;
	top: inherit;
	bottom: 10px;
}
/*---------------------------------------------------------------------
    popup begin css
---------------------------------------------------------------------*/

.vfpop {
	background: none repeat scroll 0 0 #FFA200;
	border: 1px solid #DDDDDD;
	border-radius: 6px 6px 6px 6px;
	top: 157px;
	left: auto;
	margin-left: 74px;
	padding: 10px 0 0;
	position: fixed;
	text-align: center;
	width: 290px;
	z-index: 15;
}
 
.btn {
background-color: #FF0000; /* Green */
border: 1px solid white;
color: white;
padding: 15px 32px;
border-radius: 6px 6px 6px 6px; 
text-align: center;
text-decoration: none;
display: inline-block;
font-size: 16px;
}

.btn:hover {
	background-color: rgb(65, 199, 70); /* Green Claro */
	box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
	opacity: 0.5;
	color: white;
}


/*---------------------------------------------------------------------
    end popup css
---------------------------------------------------------------------*/
');

fwrite($archivo,"\r\n");

fflush($archivo);
fclose($archivo);
}



//------------------------------------------------------------------------------copy
echo "</br>";
$dir2 = "php/".$txt."/icon";
if (!file_exists($dir2)) 
mkdir($dir2, 0777, true);

copy('jquery-3.6.0.min.js', $dir.'/jquery-3.6.0.min.js');
copy('icon/email.png','php/'.$txt.'/icon/email.png');
copy('icon/facebook.png','php/'.$txt.'/icon/facebook.png');
copy('icon/fb.png','php/'.$txt.'/icon/fb.png');
copy('icon/google+.png','php/'.$txt.'/icon/google+.png');
copy('icon/insta.png','php/'.$txt.'/icon/insta.png');
copy('icon/instagram.png','php/'.$txt.'/icon/instagram.png');
copy('icon/lin.png','php/'.$txt.'/icon/lin.png');
copy('icon/linkedin.png','php/'.$txt.'/icon/linkedin.png');
copy('icon/location.png','php/'.$txt.'/icon/location.png');
copy('icon/strong.png','php/'.$txt.'/icon/strong.png');
copy('icon/tellephone.png','php/'.$txt.'/icon/tellephone.png');
copy('icon/tw.png','php/'.$txt.'/icon/tw.png');
copy('icon/twitter.png','php/'.$txt.'/icon/twitter.png');
copy('icon/world.png','php/'.$txt.'/icon/world.png');

$dir3 = "php/".$txt."/images";
if (!file_exists($dir3)) 
mkdir($dir3, 0777, true);
copy('images/logo.png','php/'.$txt.'/images/logo.png');
copy('images/recepcion1024x700.jpg','php/'.$txt.'/images/recepcion1024x700.jpg');
copy('images/search_icon.png','php/'.$txt.'/images/search_icon.png');

$dir3 = "php/".$txt."/tablecloth";
if (!file_exists($dir3)) 

mkdir($dir3, 0777, true);
copy('tablecloth/tablecloth.css','php/'.$txt.'/tablecloth/tablecloth.css');
copy('tablecloth/tablecloth.js','php/'.$txt.'/tablecloth/tablecloth.js');
copy('tablecloth/tr_back.gif','php/'.$txt.'/tablecloth/tr_back.gif');


//------------------------------------------------------------------------------ ZIP 

/* primero creamos la función que hace la magia
 * esta funcion recorre carpetas y subcarpetas
 * añadiendo todo archivo que encuentre a su paso
 * recibe el directorio y el zip a utilizar 
 */
function agregar_zip($dir, $zip) {
  //verificamos si $dir es un directorio
  if (is_dir($dir)) {
    //abrimos el directorio y lo asignamos a $da
    if ($da = opendir($dir)) {
      //leemos del directorio hasta que termine
      while (($archivo = readdir($da)) !== false) {
        /*Si es un directorio imprimimos la ruta
         * y llamamos recursivamente esta función
         * para que verifique dentro del nuevo directorio
         * por mas directorios o archivos
         */
        if (is_dir($dir . $archivo) && $archivo != "." && $archivo != "..") {
          echo "<strong>Creando directorio: $dir$archivo</strong><br/>";
          agregar_zip($dir . $archivo . "/", $zip);
 
          /*si encuentra un archivo imprimimos la ruta donde se encuentra
           * y agregamos el archivo al zip junto con su ruta 
           */
        } elseif (is_file($dir . $archivo) && $archivo != "." && $archivo != "..") {
          echo "Agregando archivo: $dir$archivo <br/>";
          $zip->addFile($dir . $archivo, $dir . $archivo);
        }
      }
      //cerramos el directorio abierto en el momento
      closedir($da);
    }
  }
}
 
//fin de la función
//creamos una instancia de ZipArchive
$zip = new ZipArchive();
 
/*directorio a comprimir
 * la barra inclinada al final es importante
 * la ruta debe ser relativa no absoluta
 */
$dir = $dir;
 
//ruta donde guardar los archivos zip, ya debe existir
$rutaFinal = "php/";
 
if(!file_exists($rutaFinal)){
  mkdir($rutaFinal);
}
 
$archivoZip = $txt.".zip";
 
if ($zip->open($archivoZip, ZIPARCHIVE::CREATE) === true) {
  agregar_zip($dir, $zip);
  $zip->close();
 
  //Muevo el archivo a una ruta
  //donde no se mezcle los zip con los demas archivos
  rename($archivoZip, "$rutaFinal/$archivoZip");
 
  //Hasta aqui el archivo zip ya esta creado
  //Verifico si el archivo ha sido creado
  if (file_exists($rutaFinal. "/" . $archivoZip)) {
    echo "Proceso Finalizado!! <br/><br/>
                Descargar: <a href='$rutaFinal/$archivoZip'>$archivoZip</a>";
  } else {
    echo "Error, archivo zip no ha sido creado!!";
  }
}
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------indice begin

$consulta = "SELECT * FROM ".$txt;
$resultado=mysqli_query($db_connection, $consulta);
while ($row =mysqli_fetch_array($resultado)){   
 $dato=$row[$primary];
 $dato2=$row[$bus];
}


echo "<br><a href='php/".$txt."/index.php'>Ver INDEX</a>";

  

//------------------------------------------------------------------------------indice end

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>