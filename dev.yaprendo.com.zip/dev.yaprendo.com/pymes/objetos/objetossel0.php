<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>objetos</title> 
  

<?php
include 'db.php'; 
$Codigo= utf8_decode($_GET['Codigo']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM objetos WHERE Codigo LIKE '".$Codigo."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$idobj=$row['idobj'];
$Codigo=$row['Codigo'];
$Nombre=$row['Nombre'];
$Categoria=$row['Categoria'];
$Descripcion=$row['Descripcion'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Maximo=$row['Maximo'];
$Minimo=$row['Minimo'];
$Caducidad=$row['Caducidad'];
$Ubicacion=$row['Ubicacion'];
$Foto=$row['Foto'];
$Enlace=$row['Enlace'];
$Estado=$row['Estado'];
$Idobj2=$row['Idobj2'];
$Ident=$row['Ident'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.objetos.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=16 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>idobj</th> 
<th>Codigo</th> 
<th>Nombre</th> 
<th>Categoria</th> 
<th>Descripcion</th> 
<th>Cantidad</th> 
<th>Precio</th> 
<th>Maximo</th> 
<th>Minimo</th> 
<th>Caducidad</th> 
<th>Ubicacion</th> 
<th>Foto</th> 
<th>Enlace</th> 
<th>Estado</th> 
<th>Idobj2</th> 
<th>Ident</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $idobj; ?></th> 
<th><?php echo $Codigo; ?></th> 
<th><?php echo $Nombre; ?></th> 
<th><?php echo $Categoria; ?></th> 
<th><?php echo $Descripcion; ?></th> 
<th><?php echo $Cantidad; ?></th> 
<th><?php echo $Precio; ?></th> 
<th><?php echo $Maximo; ?></th> 
<th><?php echo $Minimo; ?></th> 
<th><?php echo $Caducidad; ?></th> 
<th><?php echo $Ubicacion; ?></th> 
<th><?php echo $Foto; ?></th> 
<th><?php echo $Enlace; ?></th> 
<th><?php echo $Estado; ?></th> 
<th><?php echo $Idobj2; ?></th> 
<th><?php echo $Ident; ?></th> 
</tr></table></br></br> 
 
<a href="../usuarios.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
</body> </html>