<?php 
session_start();
include('header.php');
$loginError = '';
if (!empty($_POST['Correo']) && !empty($_POST['Pass'])) {
	include ('Chat.php');
	$chat = new Chat();
	$user = $chat->loginUsers($_POST['Correo'], $_POST['Pass']);	
	if(!empty($user)) {
		$_SESSION['Correo'] = $user[0]['Correo'];
		$_SESSION['Ident'] = $user[0]['Ident'];
		$chat->updateUserOnline($user[0]['Ident'], 1);
		$lastInsertId = $chat->insertUserLoginDetails($user[0]['Ident']);
		$_SESSION['login_details_id'] = $lastInsertId;
		header("Location:index.php");
	} else {
		$loginError = "Usuario y Contraseña invalida";
	}
}

?>
<title>Chat</title>
<?php include('container.php');?>
<div class="container">		
	<h2>Chat en vivo</h1>		
	<div class="row">
		<div class="col-sm-4">
			<h4>Chat Login:</h4>		
			<form method="post">
				<div class="form-group">
				<?php if ($loginError ) { ?>
					<div class="alert alert-warning"><?php echo $loginError; ?></div>
				<?php } ?>
				</div>
				<div class="form-group">
					<label for="Correo">Usuario:</label>
					<input type="Correo" class="form-control" name="Correo" required>
				</div>
				<div class="form-group">
					<label for="Pass">Contraseña:</label>
					<input type="password" class="form-control" name="Pass" required>
				</div>  
				<button type="submit" name="login" class="btn btn-info">Iniciar Sesion</button>
			</form>
			<br>
		</div>
		
	</div>
</div>	
<?php include('footer.php');?>






