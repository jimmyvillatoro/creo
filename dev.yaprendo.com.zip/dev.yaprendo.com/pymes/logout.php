<?php 
session_start();
include ('Chat.php');
$chat = new Chat();
$chat->updateUserOnline($_SESSION['Ident'], 0);
$_SESSION['Correo'] = "";
$_SESSION['Ident']  = "";
$_SESSION['login_details_id']= "";
header("Location:index.php");
?>






