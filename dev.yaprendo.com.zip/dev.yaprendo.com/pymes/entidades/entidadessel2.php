<?php
session_start(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript" src="tablecloth/tablecloth.js"></script>
        <title>entidades</title> 
<style>
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style> 
  
 
<?php
include '../dat/cdb/db.php';
$idusu = utf8_decode($_GET['idusu']); 
$Ident = utf8_decode($_GET['Ident']); 

if($_SESSION['Ident']!=$idusu)
{
 echo '<a href="sesion.php" title="" class="round">Inicie sesion</a>';
  header('Location: sesion.php?idses='.$_SESSION['Ident'].'');
  exit;
}

$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos FROM entidades WHERE Ident = '".$idusu."' ");
while ($row =mysqli_fetch_array($resultado)) {
   	$nombres=$row['Nombres'];
   	$nombres.=" ".$row['Apellidos'];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

 
 <?php  
$Empresa = utf8_decode($_GET['Empresa']); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../usuarios.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Regresar</a></li>
</ul>
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

        <div> <h2>entidades</h2> </div> 
 
<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr><th>Ident</th> 
<th>Empresa</th> 
<th>Nombres</th> 
<th>Apellidos</th> 
<th>Movil</th> 
<th>Correo</th> 
<th>Pass</th> 
<th>Fecha</th> 
<th>Estado</th> 


<?php
include '../dat/cdb/db.php'; 
$Empresa= utf8_decode($_GET['Empresa']); 
$recursiva=$_SESSION['Ident']-1;
$resultado=mysqli_query($db_connection, "SELECT * FROM entidades WHERE Ident2 = '".$recursiva."' " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Ident=$row['Ident'];
$Empresa=$row['Empresa'];
$Nombres=$row['Nombres'];
$Apellidos=$row['Apellidos'];
$Direccion=$row['Direccion'];
$Rfc=$row['Rfc'];
$Movil=$row['Movil'];
$Correo=$row['Correo'];
$Pass=$row['Pass'];
$Foto=$row['Foto'];
$Fecha=$row['Fecha'];
$Estado=$row['Estado'];
$Tipo=$row['Tipo'];
$Ident2=$row['Ident2'];
 ?>
</tr><tr><td><?php echo $Ident; ?></td> 
<td><?php echo $Empresa; ?></td> 
<td><?php echo $Nombres; ?></td> 
<td><?php echo $Apellidos; ?></td> 
<td><?php echo $Movil; ?></td> 
<td><?php echo $Correo; ?></td> 
<td><?php echo $Pass; ?></td> 
<td><?php echo $Fecha; ?></td> 
<td><?php echo $Estado; ?></td> 

 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?Ident=<?php echo $Ident; ?>&Ident2=<?php echo $Ident2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
