<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>entidades</title> 
  

<?php
include 'db.php'; 
$Empresa= utf8_decode($_GET['Empresa']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM entidades WHERE Empresa LIKE '".$Empresa."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Ident=$row['Ident'];
$Empresa=$row['Empresa'];
$Nombres=$row['Nombres'];
$Apellidos=$row['Apellidos'];
$Direccion=$row['Direccion'];
$Rfc=$row['Rfc'];
$Movil=$row['Movil'];
$Correo=$row['Correo'];
$Pass=$row['Pass'];
$Foto=$row['Foto'];
$Fecha=$row['Fecha'];
$Estado=$row['Estado'];
$Tipo=$row['Tipo'];
$Ident2=$row['Ident2'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.entidades.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=14 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>Ident</th> 
<th>Empresa</th> 
<th>Nombres</th> 
<th>Apellidos</th> 
<th>Direccion</th> 
<th>Rfc</th> 
<th>Movil</th> 
<th>Correo</th> 
<th>Pass</th> 
<th>Foto</th> 
<th>Fecha</th> 
<th>Estado</th> 
<th>Tipo</th> 
<th>Ident2</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $Ident; ?></th> 
<th><?php echo $Empresa; ?></th> 
<th><?php echo $Nombres; ?></th> 
<th><?php echo $Apellidos; ?></th> 
<th><?php echo $Direccion; ?></th> 
<th><?php echo $Rfc; ?></th> 
<th><?php echo $Movil; ?></th> 
<th><?php echo $Correo; ?></th> 
<th><?php echo $Pass; ?></th> 
<th><?php echo $Foto; ?></th> 
<th><?php echo $Fecha; ?></th> 
<th><?php echo $Estado; ?></th> 
<th><?php echo $Tipo; ?></th> 
<th><?php echo $Ident2; ?></th> 
</tr></table></br></br> 
 
<a href="../usuarios.php?Ident=<?php echo $Ident; ?>&Ident2=<?php echo $Ident2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
</body> </html>