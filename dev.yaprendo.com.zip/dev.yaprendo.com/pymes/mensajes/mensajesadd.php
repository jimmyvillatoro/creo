<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$Idmov = $_REQUEST['Idmov'];
$Ident = $_REQUEST['Ident']; 
$Mensaje= $_REQUEST['Mensaje'];
$Destinatario= $_REQUEST['Destinatario'];

 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT Estado FROM movimientos WHERE Idmov = '".$Idmov."'" ); 
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado))
$Estado =$row['Estado']; 
if($Estado==0)
$update_value = "UPDATE movimientos SET  Fecha= '".$dt."', Tipo=5, Estado=1, Mensaje= '".$Mensaje."', Destinatario= '".$Destinatario."', Ident= '".$Ident."'   WHERE   Idmov = '".$Idmov."'" ;  
if($Estado==1)
$update_value = "UPDATE movimientos SET  Fecha= '".$dt."', Tipo=5, Estado=2, Mensaje= '".$Mensaje."', Destinatario= '".$Destinatario."', Ident= '".$Ident."'   WHERE   Idmov = '".$Idmov."'" ;  

$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Idmov=$Idmov&Ident=$Ident"); 
 
} else { 
    
$insert_value ="INSERT INTO movimientos( Fecha, Tipo, Estado, Mensaje, Remitente, Destinatario, Ident) VALUES ( '".$dt."',  5,  0, '".$Mensaje."', '".$idusu."',  '".$Destinatario."',  2)";
$retry_value = mysqli_query($db_connection,$insert_value);

$resultado=mysqli_query($db_connection, "SELECT Idmov  FROM  movimientos  WHERE Fecha LIKE '".$dt."'" ); 
while ($row =mysqli_fetch_array($resultado))
$Idmov =$row['Idmov']; 
header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Idmov=$Idmov&Ident=$Ident"); 
 
mysqli_free_result($retry_value);    
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>