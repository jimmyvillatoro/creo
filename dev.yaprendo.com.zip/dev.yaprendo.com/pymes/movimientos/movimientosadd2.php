<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finitos" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>movimientos</title> 
  
<?php 
include '../dat/cdb/db.php'; 
$idusu = utf8_decode($_GET['idusu']); 
$Ident = utf8_decode($_GET['Ident']); 
$Idmov = utf8_decode($_GET['Idmov']); 
$Ident = utf8_decode($_GET['Ident']);
$Ident = utf8_decode($_GET['Ident']);
 
$resultado=mysqli_query($db_connection, "SELECT * FROM movimientos WHERE Idmov = '".$Idmov."'" );
 
while ($row =mysqli_fetch_array($resultado)) { 
 
$Idmov=$row['Idmov'];
$Folio=$row['Folio'];
$Fecha=$row['Fecha'];
$Tipo=$row['Tipo'];
$Subtotal=$row['Subtotal'];
$Descuento=$row['Descuento'];
$Total=$row['Total'];
$Estado=$row['Estado'];
$Mensaje=$row['Mensaje'];
$Destinatario=$row['Destinatario'];
$Ident=$row['Ident'];
 } 
mysqli_free_result($resultado);
mysqli_close($db_connection);
?></head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

 <div> <h2>entidades</h2> </div>
<form action="movimientosadd2.php" method="GET">
<input type="hidden" name="idusu" value="<?php echo utf8_decode($_GET['idusu']); ?>"> 
<input type="hidden" name="idses" value="<?php echo utf8_decode($_GET['idses']); ?>"> 



<div class="row mt-1" >
<div class="col">entidades: 
<SELECT NAME="selCombo1" SIZE=1 onchange = "this.form.submit()"> 
<OPTION VALUE="0"> Elige una opción </OPTION>
<?php
include "../dat/cdb/db.php";
$idobj = $_GET['idobj']; 
$Idobj2 = $_GET['Idobj2'];
$selCombo1= utf8_decode($_GET['selCombo1']);
$resulta=mysqli_query($db_connection, "SELECT Ident, Empresa FROM  entidades WHERE Ident >=3 && Ident <=4 ");
if (mysqli_num_rows($resulta)>0)
{			  
while ($row =mysqli_fetch_array($resulta))  { 
$Ident =$row['Ident'];
$Empresa =$row['Empresa'];
?>
<OPTION VALUE="<?php echo $Ident; ?>"> <?php echo $Empresa; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo1) > 0){
$resulta=mysqli_query($db_connection, "SELECT Ident, Empresa  FROM  entidades  WHERE Ident = '".$selCombo1."' ");
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$Ident =$row['Ident'];
$Empresa =$row['Empresa'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $Ident; ?>"> <?php  echo $Empresa; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>
</form>
 
        <div> <h2>movimientos</h2> </div> 
 
<h3>Registrarte</h3>
<form action="movimientosadd.php" method="POST"><input type='hidden' name='idusu' value='<?php echo utf8_decode($_GET['idusu']); ?>'> 
<input type='hidden' name='idses' value='<?php echo utf8_decode($_GET['idses']); ?>'> 
 
 
 
<div><input type='hidden' name='Idmov'   value='<?php echo utf8_decode($_GET['selCombo1']); ?>' > </div>  
 
 
 
<div><input type='number' name='Folio'  class='form-control' placeholder='Folio' class='form-input' required> </div>  
 
 
 
<div><input type='datetime-local' name='Fecha'  class='form-control' placeholder='Fecha' class='form-input' required> </div>  
 
 
 
<div><input type='number' name='Tipo'  class='form-control' placeholder='Tipo' class='form-input' required> </div>  
 
 
 
<div><input type='TEXT' name='Subtotal'   class='form-control' placeholder='Subtotal' class='form-input' required> </div>  
 
 
 
<div><input type='TEXT' name='Descuento'   class='form-control' placeholder='Descuento' class='form-input' required> </div>  
 
 <div><input type='TEXT' name='Iva'   class='form-control' placeholder='Iva' class='form-input' required> </div>
 
<div><input type='TEXT' name='Total'   class='form-control' placeholder='Total' class='form-input' required> </div>  
 
 
 
<div><input type='number' name='Estado'  class='form-control' placeholder='Estado' class='form-input' required> </div>  
 
 
 
<div><input type='text' name='Mensaje'  class='form-control' placeholder='Mensaje' class='form-input' required> </div>  
 
 
 
<div><input type='number' name='Destinatario'  class='form-control' placeholder='Destinatario' class='form-input' required> </div>  
 
 
 
<div><input type='hidden' name='Ident'   value='<?php echo utf8_decode($_GET['selCombo1']); ?>' > </div>  
<div><input type='hidden' name='Ident'   value='<?php echo utf8_decode($_GET['selCombo1']); ?>' > </div>  
 
 
<div>
             <button type='submit' class='btn btn-success'>Registrate</button>
             </div>
             </form> 
<a href="../usuarios.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
 
