<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$Idmov = $_REQUEST['Idmov'];
$Ident = $_REQUEST['Ident']; 
$Ident = $_REQUEST['Ident'];
 
$Idmov= $_REQUEST['Idmov'];
$Folio= $_REQUEST['Folio'];
$Fecha= $_REQUEST['Fecha'];
$Tipo= $_REQUEST['Tipo'];
$Subtotal= $_REQUEST['Subtotal'];
$Descuento= $_REQUEST['Descuento'];
$Iva= $_REQUEST['Iva'];
$Total= $_REQUEST['Total'];
$Estado= $_REQUEST['Estado'];
$Mensaje= $_REQUEST['Mensaje'];
$Destinatario= $_REQUEST['Destinatario'];
$Ident= $_REQUEST['Ident'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM movimientos WHERE Folio LIKE '".$Folio."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Idmov=$Idmov&Ident=$Ident"); 
} else {  
$insert_value ="INSERT INTO movimientos(Folio, Fecha, Tipo, Subtotal, Descuento, Iva, Total, Estado, Mensaje, Destinatario, Ident) VALUES ( '".$Folio."',  '".$Fecha."',  '".$Tipo."',  '".$Subtotal."',  '".$Descuento."', '".$Iva."', '".$Total."',  '".$Estado."',  '".$Mensaje."',  '".$Destinatario."',  '".$Ident."')";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT Idmov  FROM  movimientos  WHERE Folio = '".$Folio."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $Idmov =$row['Idmov']; 
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Idmov=$Idmov&Ident=$Ident"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>