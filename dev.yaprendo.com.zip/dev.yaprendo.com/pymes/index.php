<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>PyME</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: indice" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>pymes.<span>yaprendo.com</span></h1>
				<p>sistema de ventas</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
<li><a href="index.php" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Contactame</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
					</ul>	
				</div>
				
				<div id="splash" align="center">
					<img src="dat/ima/facturacion.jpg" alt="" width="860" height="500" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="index.php" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Contactame</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>	

					
					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					
			<h1>Que es pymes en línea?</h1>
								   
			<p><strong>La mejor plataforma de administración,</strong> control y organización para sistemas pymes. Por medio de tecnología web que se conecta de nuestros servidores a tú empresa, bajo protocolos seguros. <em> Cuenta con CRM.</em> que Monitoriza a los usuarios para comprobar el desempeño en el proceso de servicio, además el control de procesos de ventas. 
<code>Tú tienes el talento</code>, nosotros las herramientas.</p>
<p>
    

<h3 align="center">
 <a href="landing/landing3.php"><img src="dat/ima/online.png" alt="" width="300" height="100"  class="round"/></a>
</h3>

	<div id="splash" align="center"> <img src="dat/ima/demo.png" alt="" width="760" height="450" class="round" /></div>
	<div id="splash" align="center"> <img src="dat/ima/blog1.png" alt="" width="760" height="500" class="round" /></div>
	
	
					
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>
	

	
</html>
