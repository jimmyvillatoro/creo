<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript" src="tablecloth/tablecloth.js"></script>
        <title>detalle</title> 
<style>
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style> 
  
 
<?php
include '../dat/cdb/db.php'; 
$Iddet= utf8_decode($_GET['Iddet']); 
$Idmov = utf8_decode($_GET['Idmov']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle WHERE Iddet = '".$Iddet."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$Iddet=$row['Iddet'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Descuento=$row['Descuento'];
$Importe=$row['Importe'];
$Fecha=$row['Fecha'];
$Idobj=$row['Idobj'];
$Idmov=$row['Idmov'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

        <div> <h2>detalle</h2> </div> 
 
<div id='container'>
	<h1>Selección de Registros</h1>
	
	<div id='content'><table>
  <tr><th>Iddet</th> 
<th>Cantidad</th> 
<th>Precio</th> 
<th>Descuento</th> 
<th>Importe</th> 
<th>Fecha</th> 
<th>Idobj</th> 
<th>Idmov</th> 

<?php
include '../dat/cdb/db.php'; 
$Cantidad= utf8_decode($_GET['Cantidad']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Iddet=$row['Iddet'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Descuento=$row['Descuento'];
$Importe=$row['Importe'];
$Fecha=$row['Fecha'];
$Idobj=$row['Idobj'];
$Idmov=$row['Idmov'];
 ?>
</tr><tr><td><?php echo $Iddet; ?></td> 
<td><?php echo $Cantidad; ?></td> 
<td><?php echo $Precio; ?></td> 
<td><?php echo $Descuento; ?></td> 
<td><?php echo $Importe; ?></td> 
<td><?php echo $Fecha; ?></td> 
<td><?php echo $Idobj; ?></td> 
<td><?php echo $Idmov; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th><th>Iddet</th> 
<th>Cantidad</th> 
<th>Precio</th> 
<th>Descuento</th> 
<th>Importe</th> 
<th>Fecha</th> 
<th>Idobj</th> 
<th>Idmov</th> 

<?php
include '../dat/cdb/db.php'; 
$Cantidad= utf8_decode($_GET['Cantidad']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Iddet=$row['Iddet'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Descuento=$row['Descuento'];
$Importe=$row['Importe'];
$Fecha=$row['Fecha'];
$Idobj=$row['Idobj'];
$Idmov=$row['Idmov'];
 ?>
</tr><tr><tr><form action="detalleupd3.php" method="POST"> 
<input type='hidden' name='Iddet' value='<?php echo utf8_decode($_GET['Iddet']); ?>'> 
<input type='hidden' name='Idmov' value='<?php echo utf8_decode($_GET['Idmov']); ?>'> 
 
<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td> 
<td><div><input type='number' name='Iddet'  class='form-control' placeholder='Iddet' value='<?php echo $Iddet; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='TEXT' name='Cantidad'   class='form-control' placeholder='Cantidad' value='<?php echo $Cantidad; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='TEXT' name='Precio'   class='form-control' placeholder='Precio' value='<?php echo $Precio; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='TEXT' name='Descuento'   class='form-control' placeholder='Descuento' value='<?php echo $Descuento; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='TEXT' name='Importe'   class='form-control' placeholder='Importe' value='<?php echo $Importe; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='datetime-local' name='Fecha'  class='form-control' placeholder='Fecha' value='<?php echo $Fecha; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='Idobj'  class='form-control' placeholder='Idobj' value='<?php echo $Idobj; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='Idmov'  class='form-control' placeholder='Idmov' value='<?php echo $Idmov; ?>' class='form-input' required> </div></td>  
 
</form> 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<div id='container'>
	<h1>Selección de Registros para actualizar</h1>
	
	<div id='content'><table>
  <tr><th>Actualizar</th><th>Iddet</th> 
<th>Cantidad</th> 
<th>Precio</th> 
<th>Descuento</th> 
<th>Importe</th> 
<th>Fecha</th> 
<th>Idobj</th> 
<th>Idmov</th> 

<?php
include '../dat/cdb/db.php'; 
$Cantidad= utf8_decode($_GET['Cantidad']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Iddet=$row['Iddet'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Descuento=$row['Descuento'];
$Importe=$row['Importe'];
$Fecha=$row['Fecha'];
$Idobj=$row['Idobj'];
$Idmov=$row['Idmov'];
 ?>
</tr><tr><td><a href=detalleupd2.php?Iddet=<?php echo $Iddet; ?>&Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>><?php echo $Iddet; ?> actualizar</a></td><td><?php echo $Iddet; ?></td> 
<td><?php echo $Cantidad; ?></td> 
<td><?php echo $Precio; ?></td> 
<td><?php echo $Descuento; ?></td> 
<td><?php echo $Importe; ?></td> 
<td><?php echo $Fecha; ?></td> 
<td><?php echo $Idobj; ?></td> 
<td><?php echo $Idmov; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br> 
 
<a href="../usuarios.php?Iddet='".$Iddet."'&Idmov='".$Idmov."'">Regresar</a>
"<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th><th>Iddet</th> 
<th>Cantidad</th> 
<th>Precio</th> 
<th>Descuento</th> 
<th>Importe</th> 
<th>Fecha</th> 
<th>Idobj</th> 
<th>Idmov</th> 

<?php
include '../dat/cdb/db.php'; 
$Cantidad= utf8_decode($_GET['Cantidad']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Iddet=$row['Iddet'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Descuento=$row['Descuento'];
$Importe=$row['Importe'];
$Fecha=$row['Fecha'];
$Idobj=$row['Idobj'];
$Idmov=$row['Idmov'];
 ?>
</tr><tr><td><a href=detalledel2.php?Iddet=<?php echo $Iddet; ?>&Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>><?php echo $Iddet; ?> borrar</a></td><td><?php echo $Iddet; ?></td> 
<td><?php echo $Cantidad; ?></td> 
<td><?php echo $Precio; ?></td> 
<td><?php echo $Descuento; ?></td> 
<td><?php echo $Importe; ?></td> 
<td><?php echo $Fecha; ?></td> 
<td><?php echo $Idobj; ?></td> 
<td><?php echo $Idmov; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
