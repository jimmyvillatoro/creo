<?php 
include '../dat/cdb/db.php'; 

$Empresa= $_REQUEST['Empresa'];
$Nombres= $_REQUEST['Nombres'];
$Apellidos= $_REQUEST['Apellidos'];
$Direccion= $_REQUEST['Direccion'];
$Rfc= $_REQUEST['Rfc'];
$Movil= $_REQUEST['Movil'];
$Correo= $_REQUEST['Correo'];
$Pass= $_REQUEST['Pass'];
$Foto="NO";
 
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
 
 
$resultado=mysqli_query($db_connection, "SELECT Correo FROM entidades WHERE Correo LIKE '".$Correo."' "); 
 
if (mysqli_num_rows($resultado)>0) {
header("Location: ../index.php?Ident=".$Ident."'");  
} else {  
 
$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Ident2, Avatar) VALUES ( '".$Empresa."',  '".$Nombres."',  '".$Apellidos."',  '".$Direccion."',  '".$Rfc."',  '".$Movil."',  '".$Correo."',  '".$Pass."',  '".$Foto."',  '".$dt."', 1, 1, 5,'user1.jpg')";

$retry_value = mysqli_query($db_connection,$insert_value);

$resultado=mysqli_query($db_connection, "SELECT Ident, Fecha  FROM  entidades  WHERE Correo = '".$Correo."'" ); 
 while ($row =mysqli_fetch_array($resultado)) {  
$Ident=$row[Ident]; 
$Fecha=$row[Fecha]; 
}
 
 $cuerpo=" #:'".$Ident."'  Nombres:'".$Nombres."' Movil: '".$Movil."'  Correo:'".$Correo."' Password: '".$Pass."' Fecha: '".$Fecha."' ";
mail("jimmyvillatoro77@gmail.com","Prospecto Registrado",$cuerpo,"Dale seguimiento");

 
 header("Location: landing4.php?idusu='".$Ident."'&Ident='".$Ident."'"); 
 
 
mysqli_free_result($retry_value);
}
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>