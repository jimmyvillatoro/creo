<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finitos" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>detalle</title> 
  
 
<?php
include '../dat/cdb/db.php';
$idusu = utf8_decode($_GET['idusu']); 
$Ident = utf8_decode($_GET['Ident']); 
$Iddet= utf8_decode($_GET['Iddet']); 
$Idmov = utf8_decode($_GET['Idmov']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle WHERE Iddet = '".$Iddet."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$Iddet=$row['Iddet'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Descuento=$row['Descuento'];
$Importe=$row['Importe'];
$Fecha=$row['Fecha'];
$Idobj=$row['Idobj'];
$Idmov=$row['Idmov'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

        <div> <h2>detalle</h2> </div> 
 
<h3>Borrar</h3>
<form action="detalledel.php" method="POST"> 
<input type='hidden' name='Iddet' value='<?php echo utf8_decode($_GET['Iddet']); ?>'> 
<input type='hidden' name='Idmov' value='<?php echo utf8_decode($_GET['Idmov']); ?>'> 
 
<div><input type='text' name='Idx' class='form-control' placeholder='Id a Borrar' class='form-input' value='<?php echo  $Iddet; ?>' required></div>  
<div> <button type='submit' class='btn btn-success'>Borrar</button> </div> 
</form> 
<a href="../usuarios.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
