<?php 
session_start(); 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$Ident = $_REQUEST['Ident'];
$Ident2 = $_REQUEST['Ident2']; 
$recursiva=$idusu-1;
 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM entidades WHERE Empresa LIKE '%".$busca."%' && Ident2 = '".$recursiva."' " );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$Ident=$row['Ident'];
$html.= '<p><a href=entidadesupd2.php?idusu='.$idusu.'&Ident='.$Ident.'>'.$Ident.'</a></p></b>';

$Empresa=$row['Empresa'];
$html.= '<p>'.$Empresa.'</p></b>'; 
$Nombres=$row['Nombres'];
$html.= '<p>'.$Nombres.'</p></b>'; 
$Apellidos=$row['Apellidos'];
$html.= '<p>'.$Apellidos.'</p></b>'; 
$Direccion=$row['Direccion'];
$html.= '<p>'.$Direccion.'</p></b>'; 
$Rfc=$row['Rfc'];
$html.= '<p>'.$Rfc.'</p></b>'; 
$Movil=$row['Movil'];
$html.= '<p>'.$Movil.'</p></b>'; 
$Correo=$row['Correo'];
$html.= '<p>'.$Correo.'</p></b>'; 
$Pass=$row['Pass'];
$html.= '<p>'.$Pass.'</p></b>'; 

} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>