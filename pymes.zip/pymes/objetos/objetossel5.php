<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript" src="tablecloth/tablecloth.js"></script>
        <title>objetos</title> 
<style>
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style> 
  
 
<?php
include '../dat/cdb/db.php'; 
$idobj= utf8_decode($_GET['idobj']); 
$Idobj2 = utf8_decode($_GET['Idobj2']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM objetos WHERE idobj = '".$idobj."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$idobj=$row['idobj'];
$Codigo=$row['Codigo'];
$Nombre=$row['Nombre'];
$Categoria=$row['Categoria'];
$Descripcion=$row['Descripcion'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Maximo=$row['Maximo'];
$Minimo=$row['Minimo'];
$Caducidad=$row['Caducidad'];
$Ubicacion=$row['Ubicacion'];
$Foto=$row['Foto'];
$Enlace=$row['Enlace'];
$Estado=$row['Estado'];
$Idobj2=$row['Idobj2'];
$Ident=$row['Ident'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../index.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../usuarios.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round active">Administración</a></li>
<li><a href="../contacto.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>
</div>
<div id="wrapper2" class="round">
<div id="sidebar" class="round">
<h3>Índice</h3>
<ul>
<li><a href="../index.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Inicio</a></li>
<li><a href="../sesion.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Acceso</a></li>
<li><a href="../contactos.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Contáctame</a></li>
<li><a href="../soporte.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Soporte</a></li>
</ul>				
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  

        <div> <h2>objetos</h2> </div> 
 
<div id='container'>
	<h1>Selección de Registros para borrar</h1>
	
	<div id='content'><table>
  <tr><th>Borrar</th><th>idobj</th> 
<th>Codigo</th> 
<th>Nombre</th> 
<th>Categoria</th> 
<th>Descripcion</th> 
<th>Cantidad</th> 
<th>Precio</th> 
<th>Maximo</th> 
<th>Minimo</th> 
<th>Caducidad</th> 
<th>Ubicacion</th> 
<th>Foto</th> 
<th>Enlace</th> 
<th>Estado</th> 
<th>Idobj2</th> 
<th>Ident</th> 

<?php
include '../dat/cdb/db.php'; 
$Codigo= utf8_decode($_GET['Codigo']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM objetos " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$idobj=$row['idobj'];
$Codigo=$row['Codigo'];
$Nombre=$row['Nombre'];
$Categoria=$row['Categoria'];
$Descripcion=$row['Descripcion'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Maximo=$row['Maximo'];
$Minimo=$row['Minimo'];
$Caducidad=$row['Caducidad'];
$Ubicacion=$row['Ubicacion'];
$Foto=$row['Foto'];
$Enlace=$row['Enlace'];
$Estado=$row['Estado'];
$Idobj2=$row['Idobj2'];
$Ident=$row['Ident'];
 ?>
</tr><tr><td><a href=objetosdel2.php?idobj=<?php echo $idobj; ?>&idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>><?php echo $idobj; ?> borrar</a></td><td><?php echo $idobj; ?></td> 
<td><?php echo $Codigo; ?></td> 
<td><?php echo $Nombre; ?></td> 
<td><?php echo $Categoria; ?></td> 
<td><?php echo $Descripcion; ?></td> 
<td><?php echo $Cantidad; ?></td> 
<td><?php echo $Precio; ?></td> 
<td><?php echo $Maximo; ?></td> 
<td><?php echo $Minimo; ?></td> 
<td><?php echo $Caducidad; ?></td> 
<td><?php echo $Ubicacion; ?></td> 
<td><?php echo $Foto; ?></td> 
<td><?php echo $Enlace; ?></td> 
<td><?php echo $Estado; ?></td> 
<td><?php echo $Idobj2; ?></td> 
<td><?php echo $Ident; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="../usuarios.php?idobj=<?php echo $idobj; ?>&Idobj2=<?php echo $Idobj2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
