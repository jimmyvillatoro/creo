<?php 
include '../dat/cdb/db.php'; 
$idusu = $_REQUEST['idusu'];
$Ident = $_REQUEST['Ident'];
$Idobj2 = $_REQUEST['Idobj2'];
 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM objetos WHERE Codigo LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$Idobj=$row['Idobj'];
$Ident=$row['Ident'];
$Idobj2=$row['Idobj2'];
$Codigo=$row['Codigo'];
$html.= '<p><a href=objetosupd2.php?idusu='.$idusu.'&Idobj='.$Idobj.'&selCombo1='.$Ident.'&selCombo2='.$Idobj2.'>'.$Codigo.'</a></p></b>';

$Nombre=$row['Nombre'];
$html.= '<p>'.$Nombre.'</p></b>'; 
$Categoria=$row['Categoria'];
$html.= '<p>'.$Categoria.'</p></b>'; 
$Descripcion=$row['Descripcion'];
$html.= '<p>'.$Descripcion.'</p></b>'; 
$Cantidad=$row['Cantidad'];
$html.= '<p>'.$Cantidad.'</p></b>'; 
$Precio=$row['Precio'];
$html.= '<p>'.$Precio.'</p></b>'; 
$Maximo=$row['Maximo'];
$html.= '<p>'.$Maximo.'</p></b>'; 
$Minimo=$row['Minimo'];
$html.= '<p>'.$Minimo.'</p></b>'; 
$Caducidad=$row['Caducidad'];
$html.= '<p>'.$Caducidad.'</p></b>'; 
$Ubicacion=$row['Ubicacion'];
$html.= '<p>'.$Ubicacion.'</p></b>'; 
$Foto=$row['Foto'];
$html.= '<p>'.$Foto.'</p></b>'; 
$Enlace=$row['Enlace'];
$html.= '<p>'.$Enlace.'</p></b>'; 
$Estado=$row['Estado'];
$html.= '<p>'.$Estado.'</p></b>'; 

$html.= '<p>'.$Idobj2.'</p></b>'; 

$html.= '<p>'.$Ident.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>