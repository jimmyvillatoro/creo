<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$Idobj = $_REQUEST['Idobj'];

$Codigo= $_REQUEST['Codigo'];
$Nombre= $_REQUEST['Nombre'];
$Categoria= $_REQUEST['Categoria'];
$Descripcion= $_REQUEST['Descripcion'];
$Cantidad= $_REQUEST['Cantidad'];
$Precio= $_REQUEST['Precio'];
$Descuento= $_REQUEST['Descuento'];
$Maximo= $_REQUEST['Maximo'];
$Minimo= $_REQUEST['Minimo'];
$Caducidad= $_REQUEST['Caducidad'];
$Ubicacion= $_REQUEST['Ubicacion'];
$Foto= $_REQUEST['Foto'];
$Enlace= $_REQUEST['Enlace'];
$Estado= $_REQUEST['Estado'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM objetos WHERE Idobj = '".$Idobj."'" ); 
if (mysqli_num_rows($resultado)>0) {
$update_value = "UPDATE objetos SET Codigo= '".$Codigo."', Nombre= '".$Nombre."', Categoria= '".$Categoria."', Descripcion= '".$Descripcion."', Cantidad= '".$Cantidad."', Precio= '".$Precio."', Descuento= '".$Descuento."', Maximo= '".$Maximo."', Minimo= '".$Minimo."', Caducidad= '".$Caducidad."', Ubicacion= '".$Ubicacion."', Foto= '".$Foto."', Enlace= '".$Enlace."', Estado= '".$Estado."' WHERE   Idobj = '".$Idobj."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: objetossel3.php?idusu=$idusu&Idobj=$Idobj"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: objetossel3.php?idusu=$idusu&Idobj=$Idobj"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>