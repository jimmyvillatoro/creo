<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$Idmov = $_REQUEST['Idmov'];
$Ident = $_REQUEST['Ident']; 
$Ident = $_REQUEST['Ident'];
 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM movimientos WHERE Folio LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$Idmov=$row['Idmov'];
$html.= '<p><a href=movimientosupd2.php?Idmov='.$Idmov.'>'.$Idmov.'</a></p></b>';$html.= '<p>'.$Idmov.'</p></b>'; 
$Folio=$row['Folio'];
$html.= '<p>'.$Folio.'</p></b>'; 
$Fecha=$row['Fecha'];
$html.= '<p>'.$Fecha.'</p></b>'; 
$Tipo=$row['Tipo'];
$html.= '<p>'.$Tipo.'</p></b>'; 
$Subtotal=$row['Subtotal'];
$html.= '<p>'.$Subtotal.'</p></b>'; 
$Descuento=$row['Descuento'];
$html.= '<p>'.$Descuento.'</p></b>'; 
$Total=$row['Total'];
$html.= '<p>'.$Total.'</p></b>'; 
$Estado=$row['Estado'];
$html.= '<p>'.$Estado.'</p></b>'; 
$Mensaje=$row['Mensaje'];
$html.= '<p>'.$Mensaje.'</p></b>'; 
$Destinatario=$row['Destinatario'];
$html.= '<p>'.$Destinatario.'</p></b>'; 
$Ident=$row['Ident'];
$html.= '<p>'.$Ident.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>