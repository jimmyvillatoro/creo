<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$Idmov = $_REQUEST['Idmov'];
$Ident = $_REQUEST['Ident']; 
$Ident = $_REQUEST['Ident'];
 
$Idmov= $_REQUEST['Idmov'];
$Folio= $_REQUEST['Folio'];
$Fecha= $_REQUEST['Fecha'];
$Tipo= $_REQUEST['Tipo'];
$Subtotal= $_REQUEST['Subtotal'];
$Descuento= $_REQUEST['Descuento'];
$Total= $_REQUEST['Total'];
$Estado= $_REQUEST['Estado'];
$Mensaje= $_REQUEST['Mensaje'];
$Destinatario= $_REQUEST['Destinatario'];
$Ident= $_REQUEST['Ident'];
$Idx= $_REQUEST['Idx'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM movimientos WHERE Idmov LIKE '".$Idx."'" );  
if (mysqli_num_rows($resultado)>0) {
$delete_value ="DELETE FROM movimientos WHERE Idmov LIKE '".$Idx."'";  
$retry_value = mysqli_query($db_connection,$delete_value);
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Idmov=$Idmov&Ident=$Ident"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Idmov=$Idmov&Ident=$Ident"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>