<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>Indice - Funciones</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">

<style>
    .div-1 {
        background-color: #EBEBEB;
    }
    
    .div-2 {
    	background-color: #ABBAEA;
    }
    
    .div-3 {
    	background-color: #FBD603;
    }
    
     #products-table
{
     width: 200px;
    height: 400px;
    overflow:scroll;
}
</style>



 <?php
	
include 'db.php';

$IdU = utf8_decode($_GET['IdU']);
$Sesion = utf8_decode($_GET['Sesion']);
$IdA = utf8_decode($_GET['IdA']);
$IdB = utf8_decode($_GET['IdB']);
$IdR = utf8_decode($_GET['IdR']);

$resultado=mysqli_query($db_connection, "SELECT IdU, Nombres, Apellidos, Fecha FROM Usuarios  WHERE IdU = '".$IdU."' ");

while ($row =mysqli_fetch_array($resultado)) {
     $IdUx=$row[IdU];  
   	 $Nombres=$row[Nombres];
   	 $Apellidos=$row[Apellidos];
   	 $Fecha=$row[Fecha];
  
   }

/*if ($IdUx!=$IdU || $Fecha != $Sesion) {
    header("Location: sesion.php");
    die();
}
*/

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

</head>
<body>
   
   
<div class="div-2" style="width:1200px; height:1200px; overflow:auto;">

<h2>Tabla a<strong class="cur"> Codificar</strong></h2>
 <form action="index.php" method="POST">
<input type="hidden" name="IdU" value="<?php echo utf8_decode($_GET['IdU']); ?>">
<input type="hidden" name="Sesion" value="<?php echo utf8_decode($_GET['Sesion']); ?>">
<input type="text" class="form-control" name="txt" placeholder="Nombre de la tabla"required>
<input type="text" class="form-control" name="txt2" placeholder="Campo a buscar">
<input type="text" class="form-control" name="txt3" placeholder="Registro a buscar" >
<div>
<button type="submit" class="btn btn-success">subscribe</button>
             </div>
             </form>

       

<?php
include 'fun.php';
$txt = utf8_decode($_GET['txt']);
$txt2 = utf8_decode($_GET['txt2']);
$txt3 = utf8_decode($_GET['txt3']);
$x=new F();
$x->s();
$x->r();
$x->a();
$x->b($txt2,$txt3);
?>
</div>
</body>
</html>